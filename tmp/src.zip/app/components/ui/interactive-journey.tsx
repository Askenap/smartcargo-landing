import { useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import { Truck, FileCheck, QrCode, Shield, CheckCircle2, MapPin, Clock, AlertCircle, Package, Building, Flag, Home } from "lucide-react";

interface JourneyStep {
  id: number;
  position: { x: number; y: number }; // Percentage position on map
  title: string;
  description: string;
  artifacts: {
    type: "qr" | "document" | "status" | "location" | "alert";
    label: string;
    icon: typeof QrCode;
  }[];
}

// Journey steps with positions representing actual route Khorgos-Kyrgyzstan
const journeySteps: JourneyStep[] = [
  {
    id: 0,
    position: { x: 15, y: 55 }, // Almaty
    title: "Создание перевозки",
    description: "Перевозчик создает рейс и заполняет документы",
    artifacts: [
      { type: "document", label: "ЦПП создан", icon: FileCheck },
      { type: "status", label: "Статус: Подготовка", icon: Clock }
    ]
  },
  {
    id: 1,
    position: { x: 32, y: 48 }, // Intermediate
    title: "QR-код сгенерирован",
    description: "Система создала уникальный QR для предъявления",
    artifacts: [
      { type: "qr", label: "QR-код активен", icon: QrCode },
      { type: "document", label: "Все документы", icon: FileCheck }
    ]
  },
  {
    id: 2,
    position: { x: 52, y: 42 }, // Near border
    title: "Выезд со склада",
    description: "Грузовик выехал, трекинг активирован",
    artifacts: [
      { type: "location", label: "GPS трекинг", icon: MapPin },
      { type: "status", label: "Статус: В пути", icon: Truck }
    ]
  },
  {
    id: 3,
    position: { x: 72, y: 38 }, // Khorgos border
    title: "КПП Граница",
    description: "Предъявление QR инспектору",
    artifacts: [
      { type: "qr", label: "QR проверен", icon: QrCode },
      { type: "status", label: "Таможня пройдена", icon: Shield },
      { type: "alert", label: "Уведомление отправлено", icon: AlertCircle }
    ]
  },
  {
    id: 4,
    position: { x: 88, y: 60 }, // Bishkek, Kyrgyzstan
    title: "Доставка завершена",
    description: "Груз доставлен, документы закрыты",
    artifacts: [
      { type: "status", label: "Статус: Доставлено", icon: CheckCircle2 },
      { type: "document", label: "Архив документов", icon: Package }
    ]
  }
];

export function InteractiveJourney() {
  const [currentStep, setCurrentStep] = useState(0);

  const handleStepClick = (stepId: number) => {
    setCurrentStep(stepId);
  };

  const handleNext = () => {
    if (currentStep < journeySteps.length - 1) {
      setCurrentStep(currentStep + 1);
    }
  };

  const handlePrev = () => {
    if (currentStep > 0) {
      setCurrentStep(currentStep - 1);
    }
  };

  const currentStepData = journeySteps[currentStep];

  return (
    <div className="relative w-full">
      {/* Map Container */}
      <div className="relative h-[600px] rounded-3xl overflow-hidden shadow-2xl border border-slate-200">
        {/* Realistic map-style background */}
        <div className="absolute inset-0 bg-gradient-to-br from-amber-50 via-green-50 to-blue-100">
          {/* Terrain texture */}
          <div className="absolute inset-0 opacity-30">
            <svg width="100%" height="100%" className="w-full h-full">
              <defs>
                <pattern id="terrain" x="0" y="0" width="100" height="100" patternUnits="userSpaceOnUse">
                  <circle cx="10" cy="10" r="1" fill="#94a3b8" opacity="0.2"/>
                  <circle cx="50" cy="30" r="1" fill="#94a3b8" opacity="0.15"/>
                  <circle cx="80" cy="60" r="1" fill="#94a3b8" opacity="0.25"/>
                  <circle cx="30" cy="80" r="1" fill="#94a3b8" opacity="0.1"/>
                </pattern>
              </defs>
              <rect width="100%" height="100%" fill="url(#terrain)" />
            </svg>
          </div>

          {/* Mountains region (Tian Shan) */}
          <div className="absolute inset-0">
            <svg viewBox="0 0 1200 600" className="w-full h-full" preserveAspectRatio="none">
              {/* Mountain ranges */}
              <path 
                d="M 200,400 L 300,250 L 400,300 L 500,200 L 650,280 L 800,220 L 900,300 L 1000,350 L 1200,400 L 1200,600 L 0,600 Z" 
                fill="#cbd5e1" 
                opacity="0.15"
              />
              <path 
                d="M 150,450 L 250,320 L 350,360 L 450,280 L 600,340 L 750,300 L 850,360 L 1000,400 L 1200,450 L 1200,600 L 0,600 Z" 
                fill="#94a3b8" 
                opacity="0.1"
              />
              
              {/* Grasslands/steppe - lighter areas */}
              <ellipse cx="300" cy="450" rx="200" ry="80" fill="#a3e635" opacity="0.08" />
              <ellipse cx="700" cy="400" rx="250" ry="100" fill="#84cc16" opacity="0.06" />
              
              {/* Rivers/water features */}
              <path 
                d="M 100,300 Q 250,350 400,320 T 700,280" 
                stroke="#60a5fa" 
                strokeWidth="2" 
                fill="none" 
                opacity="0.2"
              />
            </svg>
          </div>

          {/* Cities landmarks */}
          <motion.div
            className="absolute"
            style={{ left: "15%", top: "55%" }}
            initial={{ opacity: 0, scale: 0 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: 0.2 }}
          >
            <div className="flex flex-col items-center">
              <div className="w-8 h-8 bg-blue-500 rounded-lg shadow-lg flex items-center justify-center mb-1">
                <Building className="w-5 h-5 text-white" />
              </div>
              <span className="text-[10px] font-semibold text-slate-700 bg-white/90 px-2 py-0.5 rounded shadow-sm">
                Алматы
              </span>
            </div>
          </motion.div>

          <motion.div
            className="absolute"
            style={{ left: "72%", top: "38%" }}
            initial={{ opacity: 0, scale: 0 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: 0.3 }}
          >
            <div className="flex flex-col items-center">
              <div className="w-8 h-8 bg-orange-500 rounded-lg shadow-lg flex items-center justify-center mb-1">
                <Flag className="w-5 h-5 text-white" />
              </div>
              <span className="text-[10px] font-semibold text-slate-700 bg-white/90 px-2 py-0.5 rounded shadow-sm">
                Хоргос
              </span>
            </div>
          </motion.div>

          <motion.div
            className="absolute"
            style={{ left: "88%", top: "60%" }}
            initial={{ opacity: 0, scale: 0 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: 0.4 }}
          >
            <div className="flex flex-col items-center">
              <div className="w-8 h-8 bg-emerald-500 rounded-lg shadow-lg flex items-center justify-center mb-1">
                <Home className="w-5 h-5 text-white" />
              </div>
              <span className="text-[10px] font-semibold text-slate-700 bg-white/90 px-2 py-0.5 rounded shadow-sm">
                Бишкек
              </span>
            </div>
          </motion.div>

          {/* Subtle grid overlay */}
          <div className="absolute inset-0 bg-[linear-gradient(to_right,#cbd5e1_1px,transparent_1px),linear-gradient(to_bottom,#cbd5e1_1px,transparent_1px)] bg-[size:50px_50px] opacity-10" />
        </div>

        {/* Path line connecting route */}
        <svg className="absolute inset-0 w-full h-full" style={{ zIndex: 1 }}>
          {/* Background path */}
          <motion.path
            d={`M ${journeySteps[0].position.x}% ${journeySteps[0].position.y}% 
                L ${journeySteps[1].position.x}% ${journeySteps[1].position.y}%
                L ${journeySteps[2].position.x}% ${journeySteps[2].position.y}%
                L ${journeySteps[3].position.x}% ${journeySteps[3].position.y}%
                L ${journeySteps[4].position.x}% ${journeySteps[4].position.y}%`}
            fill="none"
            stroke="#cbd5e1"
            strokeWidth="4"
            strokeLinecap="round"
            strokeDasharray="8 4"
            initial={{ pathLength: 0, opacity: 0 }}
            animate={{ pathLength: 1, opacity: 0.5 }}
            transition={{ duration: 1.5, ease: "easeInOut" }}
          />
          
          {/* Active path with gradient */}
          <motion.path
            d={`M ${journeySteps[0].position.x}% ${journeySteps[0].position.y}% 
                ${journeySteps.slice(0, currentStep + 1).map((step, idx) => 
                  idx === 0 ? '' : `L ${step.position.x}% ${step.position.y}%`
                ).join(' ')}`}
            fill="none"
            stroke="url(#activeGradient)"
            strokeWidth="5"
            strokeLinecap="round"
            initial={{ pathLength: 0 }}
            animate={{ pathLength: 1 }}
            transition={{ duration: 1, ease: "easeInOut" }}
          />
          
          <defs>
            <linearGradient id="activeGradient" x1="0%" y1="0%" x2="100%" y2="0%">
              <stop offset="0%" stopColor="#3b82f6" />
              <stop offset="50%" stopColor="#8b5cf6" />
              <stop offset="100%" stopColor="#10b981" />
            </linearGradient>
          </defs>
        </svg>

        {/* Journey step markers */}
        {journeySteps.map((step, idx) => (
          <div key={step.id}>
            {/* Step marker button */}
            <motion.button
              onClick={() => handleStepClick(step.id)}
              className="absolute group pointer-events-auto"
              style={{
                left: `${step.position.x}%`,
                top: `${step.position.y}%`,
                transform: "translate(-50%, -50%)",
                zIndex: idx === currentStep ? 20 : 10
              }}
              initial={{ scale: 0, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              transition={{ delay: 0.5 + idx * 0.15, type: "spring", stiffness: 200 }}
              whileHover={{ scale: 1.2 }}
              whileTap={{ scale: 0.9 }}
            >
              {/* Outer glow ring */}
              <motion.div
                className="absolute inset-0 rounded-full"
                animate={idx === currentStep ? {
                  boxShadow: [
                    "0 0 0 0 rgba(59, 130, 246, 0.7)",
                    "0 0 0 20px rgba(59, 130, 246, 0)",
                    "0 0 0 0 rgba(59, 130, 246, 0)"
                  ]
                } : {}}
                transition={{
                  duration: 2,
                  repeat: idx === currentStep ? Infinity : 0,
                  ease: "easeOut"
                }}
              />
              
              {/* Step dot */}
              <motion.div
                className={`relative w-6 h-6 rounded-full border-3 transition-all shadow-xl ${
                  idx <= currentStep
                    ? "bg-gradient-to-br from-blue-500 to-emerald-500 border-white"
                    : "bg-white border-slate-300"
                }`}
                animate={idx === currentStep ? {
                  scale: [1, 1.2, 1]
                } : {}}
                transition={{
                  duration: 1.5,
                  repeat: idx === currentStep ? Infinity : 0
                }}
              >
                {idx <= currentStep && (
                  <motion.div
                    initial={{ scale: 0 }}
                    animate={{ scale: 1 }}
                    className="absolute inset-0 flex items-center justify-center"
                  >
                    <CheckCircle2 className="w-4 h-4 text-white" />
                  </motion.div>
                )}
              </motion.div>
            </motion.button>

            {/* Step info below marker - only show for current step */}
            <AnimatePresence>
              {idx === currentStep && (
                <motion.div
                  initial={{ opacity: 0, y: -10 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -10 }}
                  className="absolute pointer-events-none"
                  style={{
                    left: `${step.position.x}%`,
                    top: `${step.position.y}%`,
                    transform: "translate(-50%, 0)",
                    marginTop: "20px",
                    zIndex: 25
                  }}
                >
                  <div className="bg-white/95 backdrop-blur-sm rounded-xl shadow-2xl border border-slate-200 p-4 max-w-xs">
                    <div className="flex items-center gap-2 mb-2">
                      <span className="text-xs font-semibold text-blue-600 bg-blue-100 px-2 py-1 rounded-full">
                        Шаг {idx + 1} из {journeySteps.length}
                      </span>
                    </div>
                    <h4 className="text-sm font-bold text-slate-900 mb-1">
                      {step.title}
                    </h4>
                    <p className="text-xs text-slate-600">
                      {step.description}
                    </p>
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        ))}

        {/* Animated Truck */}
        <motion.div
          className="absolute pointer-events-none"
          style={{
            left: `${currentStepData.position.x}%`,
            top: `${currentStepData.position.y}%`,
            transform: "translate(-50%, -50%)",
            zIndex: 30
          }}
          initial={{
            left: `${journeySteps[0].position.x}%`,
            top: `${journeySteps[0].position.y}%`
          }}
          animate={{
            left: `${currentStepData.position.x}%`,
            top: `${currentStepData.position.y}%`
          }}
          transition={{ 
            duration: 1.2, 
            ease: "easeInOut",
            type: "spring",
            stiffness: 50,
            damping: 15
          }}
        >
          {/* Status artifacts above truck */}
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            className="absolute bottom-full mb-4 left-1/2 -translate-x-1/2 pointer-events-none"
          >
            <div className="flex flex-col gap-2 items-center min-w-max">
              {currentStepData.artifacts.map((artifact, idx) => (
                <motion.div
                  key={idx}
                  initial={{ opacity: 0, scale: 0.8, y: 10 }}
                  animate={{ opacity: 1, scale: 1, y: 0 }}
                  transition={{ delay: idx * 0.1 }}
                  className="flex items-center gap-2 px-3 py-2 bg-white/95 backdrop-blur-sm rounded-lg shadow-lg border border-slate-200"
                >
                  <div className={`w-6 h-6 rounded-md flex items-center justify-center shadow-sm ${
                    artifact.type === "qr" ? "bg-gradient-to-br from-violet-500 to-violet-600" :
                    artifact.type === "document" ? "bg-gradient-to-br from-blue-500 to-blue-600" :
                    artifact.type === "status" ? "bg-gradient-to-br from-emerald-500 to-emerald-600" :
                    artifact.type === "location" ? "bg-gradient-to-br from-cyan-500 to-cyan-600" :
                    "bg-gradient-to-br from-orange-500 to-orange-600"
                  }`}>
                    <artifact.icon className="w-3.5 h-3.5 text-white" />
                  </div>
                  <span className="text-xs font-semibold text-slate-900">
                    {artifact.label}
                  </span>
                </motion.div>
              ))}
            </div>
          </motion.div>

          {/* Truck SVG */}
          <motion.div
            animate={{
              y: [0, -8, 0],
              rotate: [0, 1, -1, 0]
            }}
            transition={{
              duration: 3,
              repeat: Infinity,
              ease: "easeInOut"
            }}
          >
            <svg width="80" height="80" viewBox="0 0 120 80" fill="none" className="drop-shadow-2xl">
              {/* Trailer/Container */}
              <g filter="url(#truckShadow)">
                <rect x="15" y="25" width="70" height="35" rx="2" fill="url(#containerGradient)" />
                <rect x="15" y="25" width="70" height="4" fill="#1e40af" opacity="0.3" />
                <rect x="18" y="30" width="64" height="25" rx="1" fill="#3b82f6" opacity="0.2" />
                
                {/* Container details */}
                <line x1="20" y1="28" x2="80" y2="28" stroke="#1e40af" strokeWidth="0.5" opacity="0.5" />
                <line x1="20" y1="57" x2="80" y2="57" stroke="#1e40af" strokeWidth="0.5" opacity="0.5" />
                <rect x="22" y="33" width="18" height="18" rx="1" fill="#60a5fa" opacity="0.3" />
                <rect x="43" y="33" width="18" height="18" rx="1" fill="#60a5fa" opacity="0.3" />
                <rect x="64" y="33" width="14" height="18" rx="1" fill="#60a5fa" opacity="0.3" />
              </g>
              
              {/* Cabin */}
              <g filter="url(#truckShadow)">
                <path d="M85 35 L95 35 L105 42 L105 60 L85 60 Z" fill="url(#cabinGradient)" />
                <path d="M85 35 L95 35 L95 60 L85 60 Z" fill="#3b82f6" opacity="0.9" />
                <path d="M95 35 L105 42 L105 60 L95 60 Z" fill="#2563eb" opacity="0.9" />
                
                {/* Window */}
                <path d="M96 38 L103 43 L103 52 L96 52 Z" fill="#93c5fd" opacity="0.6" />
                <line x1="96" y1="45" x2="103" y2="45" stroke="#1e40af" strokeWidth="0.5" opacity="0.3" />
                
                {/* Front window */}
                <rect x="87" y="38" width="6" height="14" rx="1" fill="#93c5fd" opacity="0.6" />
                
                {/* Door line */}
                <line x1="90" y1="38" x2="90" y2="60" stroke="#1e40af" strokeWidth="0.5" opacity="0.5" />
                
                {/* Grill */}
                <rect x="105" y="48" width="3" height="10" rx="0.5" fill="#475569" />
                <line x1="105" y1="50" x2="108" y2="50" stroke="#64748b" strokeWidth="0.5" />
                <line x1="105" y1="52" x2="108" y2="52" stroke="#64748b" strokeWidth="0.5" />
                <line x1="105" y1="54" x2="108" y2="54" stroke="#64748b" strokeWidth="0.5" />
                <line x1="105" y1="56" x2="108" y2="56" stroke="#64748b" strokeWidth="0.5" />
              </g>
              
              {/* Wheels */}
              <g filter="url(#wheelShadow)">
                {/* Back wheels (trailer) */}
                <circle cx="30" cy="62" r="8" fill="url(#wheelGradient)" stroke="#1f2937" strokeWidth="1.5" />
                <circle cx="30" cy="62" r="4" fill="#374151" />
                <circle cx="30" cy="62" r="2" fill="#4b5563" />
                
                <circle cx="50" cy="62" r="8" fill="url(#wheelGradient)" stroke="#1f2937" strokeWidth="1.5" />
                <circle cx="50" cy="62" r="4" fill="#374151" />
                <circle cx="50" cy="62" r="2" fill="#4b5563" />
                
                {/* Front wheels (cabin) */}
                <circle cx="95" cy="62" r="8" fill="url(#wheelGradient)" stroke="#1f2937" strokeWidth="1.5" />
                <circle cx="95" cy="62" r="4" fill="#374151" />
                <circle cx="95" cy="62" r="2" fill="#4b5563" />
              </g>
              
              {/* Headlights */}
              <circle cx="107" cy="45" r="1.5" fill="#fef08a" opacity="0.9" />
              
              {/* Connecting hitch */}
              <rect x="82" y="47" width="6" height="3" rx="1" fill="#475569" />
              
              <defs>
                <linearGradient id="containerGradient" x1="15" y1="25" x2="15" y2="60">
                  <stop offset="0%" stopColor="#3b82f6" />
                  <stop offset="100%" stopColor="#2563eb" />
                </linearGradient>
                <linearGradient id="cabinGradient" x1="85" y1="35" x2="85" y2="60">
                  <stop offset="0%" stopColor="#3b82f6" />
                  <stop offset="100%" stopColor="#1e40af" />
                </linearGradient>
                <radialGradient id="wheelGradient" cx="50%" cy="50%" r="50%">
                  <stop offset="0%" stopColor="#6b7280" />
                  <stop offset="100%" stopColor="#374151" />
                </radialGradient>
                <filter id="truckShadow" x="-50%" y="-50%" width="200%" height="200%">
                  <feGaussianBlur in="SourceAlpha" stdDeviation="1" />
                  <feOffset dx="1" dy="2" result="offsetblur" />
                  <feComponentTransfer>
                    <feFuncA type="linear" slope="0.3" />
                  </feComponentTransfer>
                  <feMerge>
                    <feMergeNode />
                    <feMergeNode in="SourceGraphic" />
                  </feMerge>
                </filter>
                <filter id="wheelShadow" x="-50%" y="-50%" width="200%" height="200%">
                  <feGaussianBlur in="SourceAlpha" stdDeviation="0.5" />
                  <feOffset dx="0" dy="1" result="offsetblur" />
                  <feComponentTransfer>
                    <feFuncA type="linear" slope="0.4" />
                  </feComponentTransfer>
                  <feMerge>
                    <feMergeNode />
                    <feMergeNode in="SourceGraphic" />
                  </feMerge>
                </filter>
              </defs>
            </svg>

            {/* Speed lines */}
            {currentStep > 0 && currentStep < journeySteps.length - 1 && (
              <motion.div
                className="absolute left-0 top-1/2 -translate-y-1/2"
                initial={{ opacity: 0 }}
                animate={{ opacity: [0, 1, 0], x: [-20, -40] }}
                transition={{
                  duration: 0.8,
                  repeat: Infinity,
                  ease: "easeOut"
                }}
              >
                <div className="flex flex-col gap-1">
                  <div className="w-8 h-0.5 bg-blue-400 rounded" />
                  <div className="w-6 h-0.5 bg-blue-300 rounded" />
                  <div className="w-4 h-0.5 bg-blue-200 rounded" />
                </div>
              </motion.div>
            )}
          </motion.div>
        </motion.div>

        {/* Navigation Controls - Bottom Center */}
        <div className="absolute bottom-6 left-1/2 -translate-x-1/2 pointer-events-auto z-40">
          <div className="flex items-center gap-4 bg-white/95 backdrop-blur-sm rounded-full shadow-2xl border border-slate-200 px-6 py-3">
            <button
              onClick={handlePrev}
              disabled={currentStep === 0}
              className="px-4 py-2 text-sm font-semibold text-slate-900 hover:text-blue-600 disabled:text-slate-400 disabled:cursor-not-allowed transition-colors rounded-lg hover:bg-blue-50"
            >
              ← Назад
            </button>
            
            <div className="flex gap-2">
              {journeySteps.map((_, idx) => (
                <button
                  key={idx}
                  onClick={() => handleStepClick(idx)}
                  className={`h-2 rounded-full transition-all ${
                    idx === currentStep 
                      ? "bg-blue-500 w-8" 
                      : idx < currentStep
                      ? "bg-emerald-500 w-2"
                      : "bg-slate-300 w-2"
                  }`}
                />
              ))}
            </div>

            <button
              onClick={handleNext}
              disabled={currentStep === journeySteps.length - 1}
              className="px-4 py-2 text-sm font-semibold text-slate-900 hover:text-blue-600 disabled:text-slate-400 disabled:cursor-not-allowed transition-colors rounded-lg hover:bg-blue-50"
            >
              Далее →
            </button>
          </div>
        </div>

        {/* Hint */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 1.5 }}
          className="absolute top-6 left-1/2 -translate-x-1/2 pointer-events-none z-40"
        >
          <div className="bg-blue-600 text-white text-sm font-medium px-4 py-2 rounded-full shadow-lg">
            Кликните на точки маршрута для навигации
          </div>
        </motion.div>
      </div>
    </div>
  );
}
