import { useState, useEffect } from "react";
import * as React from "react";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { 
  Search, Shield, CheckCircle, XCircle, Clock, MapPin, Truck, User, 
  FileText, Calendar, MoreHorizontal, QrCode, Share2, AlertTriangle, 
  ChevronRight, ArrowRight, RefreshCw, Lock, Eye, Send, FileCheck, Phone,
  ArrowLeft
} from "lucide-react";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "./ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from "./ui/dialog";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "./ui/card";
import { Badge } from "./ui/badge";
import QRCode from "react-qr-code";
import { Textarea } from "./ui/textarea";

// Types
interface VerifiedPass {
  id: string;
  tripId: string;
  route: string;
  vehicle: string;
  driver: string;
  driverPhone: string;
  plannedDate: string;
  ruqsatStatus: "draft" | "sent" | "approved" | "error";
  checkpointStatus: "none" | "arrived" | "confirmed" | "error";
  lastUpdate: string;
  warehouse: string;
  checkpoint: string;
}

// Mock Data
const initialMockPasses: VerifiedPass[] = [
  {
    id: "VP-2026-000045",
    tripId: "TR-2026-000125",
    route: "СВХ 'Damu' → КПП 'Хоргос'",
    vehicle: "898 UJY 01",
    driver: "Алпаков Т.Б.",
    driverPhone: "+7 (777) 123-45-67",
    plannedDate: "2026-02-20",
    ruqsatStatus: "draft",
    checkpointStatus: "none",
    lastUpdate: "Сегодня, 10:30",
    warehouse: "СВХ 'Damu Logistics'",
    checkpoint: "КПП 'Хоргос'",
  },
  {
    id: "VP-2026-000046",
    tripId: "TR-2026-000120",
    route: "СВХ 'Continental' → КПП 'Достык'",
    vehicle: "342 ABA 02",
    driver: "Иванов И.И.",
    driverPhone: "+7 (771) 987-65-43",
    plannedDate: "2026-02-18",
    ruqsatStatus: "approved",
    checkpointStatus: "arrived",
    lastUpdate: "Вчера, 18:45",
    warehouse: "СВХ 'Continental'",
    checkpoint: "КПП 'Достык'",
  },
  {
    id: "VP-2026-000047",
    tripId: "TR-2026-000118",
    route: "СВХ 'Atakent' → КПП 'Алаколь'",
    vehicle: "123 KZ 05",
    driver: "Сидоров С.С.",
    driverPhone: "+7 (701) 555-44-33",
    plannedDate: "2026-02-15",
    ruqsatStatus: "error",
    checkpointStatus: "error",
    lastUpdate: "15.02.2026",
    warehouse: "СВХ 'Atakent'",
    checkpoint: "КПП 'Алаколь'",
  },
];

// Timeline Event Type
interface TimelineEvent {
  time: string;
  date: string;
  title: string;
  source: "Smart Cargo" | "СВХ" | "КЕДЕН" | "ПС" | "Ruqsat";
  status: "completed" | "processing" | "pending" | "error";
}

const mockTimeline: TimelineEvent[] = [
  { time: "14:30", date: "16.02", title: "ТД выпущен", source: "КЕДЕН", status: "completed" },
  { time: "12:15", date: "16.02", title: "ТД на регистрацию", source: "Smart Cargo", status: "completed" },
  { time: "11:00", date: "16.02", title: "ПИ подтвержден", source: "КЕДЕН", status: "completed" },
  { time: "10:30", date: "16.02", title: "Прибыл на СВХ", source: "СВХ", status: "completed" },
  { time: "09:00", date: "16.02", title: "Ruqsat: QR получен", source: "Ruqsat", status: "completed" },
  { time: "--:--", date: "", title: "Выезд подтвержден", source: "ПС", status: "pending" },
  { time: "--:--", date: "", title: "Прибыл на границу", source: "ПС", status: "pending" },
];

// Wizard Types
interface WizardData {
  warehouse: string;
  checkpoint: string;
  tripType: string;
  plannedDate: string;
  plannedTime: string;
  comment: string;
  vehicleNumber: string;
  vehicleType: string;
  trailerNumber: string;
  vehicleCountry: string;
  driverName: string;
  driverPhone: string;
  driverId: string;
  driverCitizenship: string;
  ruqsatSent: boolean;
  driverQrSent: boolean;
}

const initialWizardData: WizardData = {
  warehouse: "",
  checkpoint: "",
  tripType: "international",
  plannedDate: "",
  plannedTime: "",
  comment: "",
  vehicleNumber: "",
  vehicleType: "truck",
  trailerNumber: "",
  vehicleCountry: "",
  driverName: "",
  driverPhone: "",
  driverId: "",
  driverCitizenship: "",
  ruqsatSent: false,
  driverQrSent: false,
};

export default function VerifiedPassTab() {
  const [mockPasses, setMockPasses] = useState<VerifiedPass[]>(initialMockPasses);
  const [view, setView] = useState<"list" | "detail" | "wizard">("list");
  const [selectedPass, setSelectedPass] = useState<VerifiedPass | null>(null);
  
  // Detail View States
  const [ruqsatStep, setRuqsatStep] = useState<"draft" | "processing" | "approved">("draft");
  const [showOtp, setShowOtp] = useState(false);
  const [otpCode, setOtpCode] = useState("");
  const [otpTimer, setOtpTimer] = useState(0);
  const [showDriverQr, setShowDriverQr] = useState(false);

  // Filter States
  const [searchQuery, setSearchQuery] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");

  // Wizard States
  const [wizardStep, setWizardStep] = useState(1);
  const [wizardData, setWizardData] = useState<WizardData>(initialWizardData);

  const filteredPasses = mockPasses.filter(pass => {
    const matchesSearch = pass.tripId.toLowerCase().includes(searchQuery.toLowerCase()) || 
                          pass.driver.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          pass.vehicle.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesStatus = statusFilter === "all" || pass.ruqsatStatus === statusFilter;
    return matchesSearch && matchesStatus;
  });

  const handleOpenDetail = (pass: VerifiedPass) => {
    setSelectedPass(pass);
    setRuqsatStep(pass.ruqsatStatus === "approved" ? "approved" : "draft");
    setView("detail");
  };

  const handleBackToList = () => {
    setSelectedPass(null);
    setView("list");
  };

  // --- Wizard Logic ---

  const handleStartWizard = () => {
    setWizardStep(1);
    setWizardData(initialWizardData);
    setView("wizard");
  };

  const handleWizardNext = () => {
    if (wizardStep < 4) {
      setWizardStep(prev => prev + 1);
    }
  };

  const handleWizardBack = () => {
    if (wizardStep > 1) {
      setWizardStep(prev => prev - 1);
    } else {
      setView("list");
    }
  };

  const updateWizardData = (field: keyof WizardData, value: any) => {
    setWizardData(prev => ({ ...prev, [field]: value }));
  };

  const handleSendRuqsatWizard = () => {
    // Simulate API call
    setTimeout(() => {
      updateWizardData("ruqsatSent", true);
    }, 1500);
  };

  const handleSendDriverQrWizard = () => {
    setTimeout(() => {
      updateWizardData("driverQrSent", true);
    }, 1000);
  };

  const handleFinishWizard = () => {
    const newPass: VerifiedPass = {
      id: `VP-2026-${Math.floor(1000 + Math.random() * 9000)}`,
      tripId: `TR-2026-${Math.floor(1000 + Math.random() * 9000)}`,
      route: `${wizardData.warehouse || 'СВХ'} → ${wizardData.checkpoint || 'КПП'}`,
      vehicle: wizardData.vehicleNumber,
      driver: wizardData.driverName,
      driverPhone: wizardData.driverPhone,
      plannedDate: wizardData.plannedDate,
      ruqsatStatus: wizardData.ruqsatSent ? "approved" : "draft",
      checkpointStatus: "none",
      lastUpdate: "Только что",
      warehouse: wizardData.warehouse,
      checkpoint: wizardData.checkpoint,
    };

    setMockPasses([newPass, ...mockPasses]);
    setSelectedPass(newPass);
    setRuqsatStep(newPass.ruqsatStatus === "approved" ? "approved" : "draft");
    setView("detail");
  };

  // --- Detail View Logic ---

  const handleSendRuqsat = () => {
    setRuqsatStep("processing");
    setTimeout(() => {
      setRuqsatStep("approved");
    }, 2000);
  };

  const generateOtp = () => {
    const code = Math.floor(100000 + Math.random() * 900000).toString();
    setOtpCode(code);
    setOtpTimer(300); // 5 minutes
    setShowOtp(true);
  };

  useEffect(() => {
    let interval: NodeJS.Timeout;
    if (otpTimer > 0) {
      interval = setInterval(() => {
        setOtpTimer((prev) => prev - 1);
      }, 1000);
    }
    return () => clearInterval(interval);
  }, [otpTimer]);

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  // --- Render Wizard ---

  if (view === "wizard") {
    const isStep1Valid = wizardData.warehouse && wizardData.checkpoint && wizardData.plannedDate && wizardData.plannedTime;
    const isStep2Valid = wizardData.vehicleNumber && wizardData.driverName && wizardData.driverPhone;

    return (
      <div className="max-w-5xl mx-auto py-6 animate-in fade-in slide-in-from-bottom-4 duration-300">
        {/* Wizard Header */}
        <div className="mb-8">
           <div className="flex items-center justify-between mb-6">
              <h2 className="text-2xl font-bold text-slate-900">Новая заявка на проход</h2>
              <Button variant="ghost" onClick={() => setView("list")} className="text-slate-500 hover:text-slate-900">
                 Отмена
              </Button>
           </div>
           
           {/* Progress Steps */}
           <div className="relative">
              <div className="absolute left-0 top-1/2 -translate-y-1/2 w-full h-1 bg-slate-100 -z-10 rounded-full"></div>
              <div 
                 className="absolute left-0 top-1/2 -translate-y-1/2 h-1 bg-blue-600 -z-10 rounded-full transition-all duration-300"
                 style={{ width: `${((wizardStep - 1) / 3) * 100}%` }}
              ></div>
              <div className="flex justify-between">
                 {[
                    { step: 1, label: "Данные рейса" },
                    { step: 2, label: "Транспорт и водитель" },
                    { step: 3, label: "Очередь Ruqsat" },
                    { step: 4, label: "QR для водителя" }
                 ].map((s) => (
                    <div key={s.step} className="flex flex-col items-center gap-2">
                       <div className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-bold border-2 transition-colors
                          ${wizardStep >= s.step ? 'bg-blue-600 border-blue-600 text-white' : 'bg-white border-slate-300 text-slate-400'}
                       `}>
                          {wizardStep > s.step ? <CheckCircle className="w-5 h-5" /> : s.step}
                       </div>
                       <span className={`text-xs font-medium ${wizardStep >= s.step ? 'text-blue-700' : 'text-slate-500'}`}>
                          {s.label}
                       </span>
                    </div>
                 ))}
              </div>
           </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
           {/* Main Form Area */}
           <div className="lg:col-span-2 space-y-6">
              
              {/* Step 1: Trip Data */}
              {wizardStep === 1 && (
                 <Card className="animate-in fade-in slide-in-from-right-8 duration-300">
                    <CardHeader>
                       <CardTitle>Данные рейса</CardTitle>
                       <CardDescription>Выберите маршрут и планируемое время выезда</CardDescription>
                    </CardHeader>
                    <CardContent className="space-y-4">
                       <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                          <div className="space-y-2">
                             <label className="text-sm font-medium text-slate-700">СВХ Отправления <span className="text-red-500">*</span></label>
                             <Select value={wizardData.warehouse} onValueChange={(v) => updateWizardData("warehouse", v)}>
                                <SelectTrigger><SelectValue placeholder="Выберите СВХ" /></SelectTrigger>
                                <SelectContent>
                                   <SelectItem value="СВХ 'Damu Logistics'">СВХ 'Damu Logistics'</SelectItem>
                                   <SelectItem value="СВХ 'Continental'">СВХ 'Continental'</SelectItem>
                                   <SelectItem value="СВХ 'Atakent'">СВХ 'Atakent'</SelectItem>
                                </SelectContent>
                             </Select>
                          </div>
                          <div className="space-y-2">
                             <label className="text-sm font-medium text-slate-700">КПП Выезда <span className="text-red-500">*</span></label>
                             <Select value={wizardData.checkpoint} onValueChange={(v) => updateWizardData("checkpoint", v)}>
                                <SelectTrigger><SelectValue placeholder="Выберите КПП" /></SelectTrigger>
                                <SelectContent>
                                   <SelectItem value="КПП 'Хоргос'">КПП 'Хоргос'</SelectItem>
                                   <SelectItem value="КПП 'Достык'">КПП 'Достык'</SelectItem>
                                   <SelectItem value="КПП 'Алаколь'">КПП 'Алаколь'</SelectItem>
                                </SelectContent>
                             </Select>
                          </div>
                       </div>

                       <div className="space-y-3">
                          <label className="text-sm font-medium text-slate-700">Тип перевозки</label>
                          <div className="flex gap-4">
                             {['international', 'eaes', 'domestic'].map((type) => (
                                <label key={type} className={`flex items-center gap-2 px-4 py-3 rounded-lg border cursor-pointer transition-colors
                                   ${wizardData.tripType === type ? 'bg-blue-50 border-blue-500 text-blue-700' : 'bg-white border-slate-200 hover:bg-slate-50'}
                                `}>
                                   <input 
                                      type="radio" 
                                      name="tripType" 
                                      className="sr-only"
                                      checked={wizardData.tripType === type}
                                      onChange={() => updateWizardData("tripType", type)}
                                   />
                                   <span className="text-sm font-medium">
                                      {type === 'international' ? 'Международная' : type === 'eaes' ? 'ЕАЭС' : 'Внутри РК'}
                                   </span>
                                </label>
                             ))}
                          </div>
                       </div>

                       <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                          <div className="space-y-2">
                             <label className="text-sm font-medium text-slate-700">Дата выезда <span className="text-red-500">*</span></label>
                             <Input type="date" value={wizardData.plannedDate} onChange={(e) => updateWizardData("plannedDate", e.target.value)} />
                          </div>
                          <div className="space-y-2">
                             <label className="text-sm font-medium text-slate-700">Время <span className="text-red-500">*</span></label>
                             <Input type="time" value={wizardData.plannedTime} onChange={(e) => updateWizardData("plannedTime", e.target.value)} />
                          </div>
                       </div>

                       <div className="space-y-2">
                          <label className="text-sm font-medium text-slate-700">Комментарий</label>
                          <Textarea 
                             placeholder="Дополнительная информация..." 
                             value={wizardData.comment}
                             onChange={(e) => updateWizardData("comment", e.target.value)}
                             className="resize-none"
                          />
                       </div>
                    </CardContent>
                 </Card>
              )}

              {/* Step 2: Vehicle & Driver */}
              {wizardStep === 2 && (
                 <Card className="animate-in fade-in slide-in-from-right-8 duration-300">
                    <CardHeader>
                       <CardTitle>Транспорт и водитель</CardTitle>
                       <CardDescription>Укажите данные транспортного средства и водителя</CardDescription>
                    </CardHeader>
                    <CardContent className="space-y-6">
                       <div className="space-y-4">
                          <h4 className="text-sm font-semibold text-slate-900 uppercase tracking-wider flex items-center gap-2">
                             <Truck className="w-4 h-4" /> Транспорт
                          </h4>
                          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                             <div className="space-y-2">
                                <label className="text-sm font-medium text-slate-700">Госномер ТС <span className="text-red-500">*</span></label>
                                <Input placeholder="A 123 ABC 01" value={wizardData.vehicleNumber} onChange={(e) => updateWizardData("vehicleNumber", e.target.value)} />
                             </div>
                             <div className="space-y-2">
                                <label className="text-sm font-medium text-slate-700">Тип ТС</label>
                                <Select value={wizardData.vehicleType} onValueChange={(v) => updateWizardData("vehicleType", v)}>
                                   <SelectTrigger><SelectValue /></SelectTrigger>
                                   <SelectContent>
                                      <SelectItem value="truck">Тягач</SelectItem>
                                      <SelectItem value="lorry">Грузовик</SelectItem>
                                      <SelectItem value="trailer">Авто + Прицеп</SelectItem>
                                   </SelectContent>
                                </Select>
                             </div>
                             <div className="space-y-2">
                                <label className="text-sm font-medium text-slate-700">Госномер прицепа</label>
                                <Input placeholder="12 AB 01" value={wizardData.trailerNumber} onChange={(e) => updateWizardData("trailerNumber", e.target.value)} />
                             </div>
                             <div className="space-y-2">
                                <label className="text-sm font-medium text-slate-700">Страна регистрации</label>
                                <Input placeholder="Казахстан" value={wizardData.vehicleCountry} onChange={(e) => updateWizardData("vehicleCountry", e.target.value)} />
                             </div>
                          </div>
                       </div>

                       <div className="h-px bg-slate-100" />

                       <div className="space-y-4">
                          <h4 className="text-sm font-semibold text-slate-900 uppercase tracking-wider flex items-center gap-2">
                             <User className="w-4 h-4" /> Водитель
                          </h4>
                          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                             <div className="space-y-2">
                                <label className="text-sm font-medium text-slate-700">ФИО водителя <span className="text-red-500">*</span></label>
                                <Input placeholder="Иванов Иван Иванович" value={wizardData.driverName} onChange={(e) => updateWizardData("driverName", e.target.value)} />
                             </div>
                             <div className="space-y-2">
                                <label className="text-sm font-medium text-slate-700">Телефон <span className="text-red-500">*</span></label>
                                <Input placeholder="+7 (___) ___-__-__" value={wizardData.driverPhone} onChange={(e) => updateWizardData("driverPhone", e.target.value)} />
                             </div>
                             <div className="space-y-2">
                                <label className="text-sm font-medium text-slate-700">ИИН / ID</label>
                                <Input placeholder="12-значный код" value={wizardData.driverId} onChange={(e) => updateWizardData("driverId", e.target.value)} />
                             </div>
                             <div className="space-y-2">
                                <label className="text-sm font-medium text-slate-700">Гражданство</label>
                                <Input placeholder="Казахстан" value={wizardData.driverCitizenship} onChange={(e) => updateWizardData("driverCitizenship", e.target.value)} />
                             </div>
                          </div>
                       </div>
                    </CardContent>
                 </Card>
              )}

              {/* Step 3: Ruqsat Queue */}
              {wizardStep === 3 && (
                 <Card className="animate-in fade-in slide-in-from-right-8 duration-300">
                    <CardHeader>
                       <CardTitle>Очередь Ruqsat</CardTitle>
                       <CardDescription>Бронирование очереди в системе электронной очереди</CardDescription>
                    </CardHeader>
                    <CardContent className="space-y-6">
                       <div className="bg-slate-50 p-4 rounded-lg border border-slate-200 grid grid-cols-2 gap-4 text-sm">
                          <div>
                             <span className="text-slate-500 block text-xs">КПП Выезда</span>
                             <span className="font-medium text-slate-900">{wizardData.checkpoint}</span>
                          </div>
                          <div>
                             <span className="text-slate-500 block text-xs">Дата выезда</span>
                             <span className="font-medium text-slate-900">{wizardData.plannedDate} {wizardData.plannedTime}</span>
                          </div>
                          <div>
                             <span className="text-slate-500 block text-xs">Транспорт</span>
                             <span className="font-medium text-slate-900">{wizardData.vehicleNumber}</span>
                          </div>
                          <div>
                             <span className="text-slate-500 block text-xs">Водитель</span>
                             <span className="font-medium text-slate-900">{wizardData.driverName}</span>
                          </div>
                       </div>

                       {!wizardData.ruqsatSent ? (
                          <div className="flex flex-col items-center justify-center py-6 border-2 border-dashed border-slate-200 rounded-xl bg-slate-50/50">
                             <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center text-blue-600 mb-3">
                                <Send className="w-6 h-6 ml-1" />
                             </div>
                             <h3 className="font-medium text-slate-900 mb-1">Готово к отправке</h3>
                             <p className="text-sm text-slate-500 text-center max-w-xs mb-4">
                                Данные проверены. Нажмите кнопку ниже, чтобы забронировать очередь в системе Ruqsat.
                             </p>
                             <Button onClick={handleSendRuqsatWizard} className="bg-blue-600 hover:bg-blue-700">
                                Отправить в Ruqsat
                             </Button>
                          </div>
                       ) : (
                          <div className="flex flex-col sm:flex-row items-center gap-6 p-4 bg-green-50 border border-green-200 rounded-xl animate-in zoom-in duration-300">
                             <div className="bg-white p-2 rounded-lg border border-slate-200 shadow-sm shrink-0">
                                <QRCode value={`RUQSAT_MOCK:${Math.random()}`} size={100} />
                             </div>
                             <div className="space-y-2 text-center sm:text-left">
                                <div className="flex items-center justify-center sm:justify-start gap-2 text-green-700 font-semibold">
                                   <CheckCircle className="w-5 h-5" />
                                   Очередь успешно забронирована
                                </div>
                                <p className="text-sm text-slate-600">
                                   QR-код сформирован. Он необходим только для транспортного контроля.
                                </p>
                                <div className="flex gap-2 justify-center sm:justify-start pt-1">
                                   <Button variant="outline" size="sm" className="h-8 text-xs bg-white">Скачать</Button>
                                   <Button variant="outline" size="sm" className="h-8 text-xs bg-white">Открыть</Button>
                                </div>
                             </div>
                          </div>
                       )}

                       <div className="bg-blue-50 border-l-4 border-blue-500 p-4 rounded-r-lg">
                          <div className="flex items-start gap-3">
                             <AlertTriangle className="w-5 h-5 text-blue-600 shrink-0 mt-0.5" />
                             <div className="text-sm text-blue-900">
                                <p className="font-medium mb-1">Важная информация</p>
                                <p className="opacity-90">
                                   QR Ruqsat не является пропуском через границу. Идентификация на КПП идёт по госномеру (камеры) и биометрии. QR нужен для подтверждения даты выезда при проверке сотрудниками ТК.
                                </p>
                             </div>
                          </div>
                       </div>
                    </CardContent>
                 </Card>
              )}

              {/* Step 4: Driver QR */}
              {wizardStep === 4 && (
                 <Card className="animate-in fade-in slide-in-from-right-8 duration-300">
                    <CardHeader>
                       <CardTitle>QR Smart Cargo для водителя</CardTitle>
                       <CardDescription>Управление доступом водителя к цифровому паспорту</CardDescription>
                    </CardHeader>
                    <CardContent className="space-y-8">
                       <div className="flex flex-col items-center">
                          <div className="relative mb-6">
                             <div className="absolute inset-0 bg-gradient-to-tr from-blue-500 to-cyan-400 rounded-xl blur opacity-30"></div>
                             <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-lg relative">
                                <QRCode value={`SMART_CARGO_WIZARD:${Math.random()}`} size={180} />
                             </div>
                             <div className="absolute -bottom-3 left-1/2 -translate-x-1/2 bg-green-100 text-green-700 px-3 py-1 rounded-full text-xs font-bold border border-green-200 whitespace-nowrap">
                                Готов к использованию
                             </div>
                          </div>

                          <div className="flex flex-col sm:flex-row gap-3 w-full max-w-md">
                             <Button 
                                className={`flex-1 ${wizardData.driverQrSent ? 'bg-green-600 hover:bg-green-700' : 'bg-blue-600 hover:bg-blue-700'}`}
                                onClick={handleSendDriverQrWizard}
                                disabled={wizardData.driverQrSent}
                             >
                                {wizardData.driverQrSent ? (
                                   <>
                                      <CheckCircle className="w-4 h-4 mr-2" /> Отправлено
                                   </>
                                ) : (
                                   <>
                                      <Send className="w-4 h-4 mr-2" /> Отправить водителю
                                   </>
                                )}
                             </Button>
                             <Button variant="outline" className="flex-1">
                                <FileText className="w-4 h-4 mr-2" /> Инструкция
                             </Button>
                          </div>
                          
                          <div className="mt-6 pt-6 border-t border-slate-100 w-full max-w-md text-center">
                             <Button variant="link" onClick={() => setShowOtp(true)} className="text-slate-500 hover:text-blue-600">
                                <Lock className="w-4 h-4 mr-2" />
                                Альтернативная верификация (OTP)
                             </Button>
                          </div>
                       </div>
                    </CardContent>
                 </Card>
              )}

              {/* Wizard Footer Actions */}
              <div className="flex items-center justify-between pt-4 border-t border-slate-100">
                 <Button variant="ghost" onClick={handleWizardBack} disabled={wizardStep === 1}>
                    <ArrowLeft className="w-4 h-4 mr-2" /> Назад
                 </Button>
                 
                 {wizardStep < 4 ? (
                    <Button 
                       onClick={handleWizardNext} 
                       disabled={
                          (wizardStep === 1 && !isStep1Valid) ||
                          (wizardStep === 2 && !isStep2Valid) ||
                          (wizardStep === 3 && !wizardData.ruqsatSent)
                       }
                       className="bg-blue-600 hover:bg-blue-700"
                    >
                       Далее <ArrowRight className="w-4 h-4 ml-2" />
                    </Button>
                 ) : (
                    <Button onClick={handleFinishWizard} className="bg-green-600 hover:bg-green-700 px-8">
                       Завершить и открыть заявку
                    </Button>
                 )}
              </div>
           </div>

           {/* Summary Sidebar */}
           <div className="hidden lg:block">
              <div className="sticky top-6 space-y-4">
                 <h3 className="text-sm font-semibold text-slate-500 uppercase tracking-wider">Сводка</h3>
                 <Card className="border-none shadow-sm bg-slate-50">
                    <CardContent className="p-4 space-y-4">
                       <div className="space-y-1">
                          <span className="text-xs text-slate-500">Маршрут</span>
                          <div className="text-sm font-medium text-slate-900">
                             {wizardData.warehouse ? wizardData.warehouse : '...'}
                             <br />↓<br />
                             {wizardData.checkpoint ? wizardData.checkpoint : '...'}
                          </div>
                       </div>
                       
                       <div className="h-px bg-slate-200" />
                       
                       <div className="space-y-1">
                          <span className="text-xs text-slate-500">Дата выезда</span>
                          <div className="text-sm font-medium text-slate-900">
                             {wizardData.plannedDate ? wizardData.plannedDate : '...'} 
                             {wizardData.plannedTime && ` в ${wizardData.plannedTime}`}
                          </div>
                       </div>

                       <div className="h-px bg-slate-200" />

                       <div className="space-y-1">
                          <span className="text-xs text-slate-500">Транспорт / Водитель</span>
                          <div className="text-sm font-medium text-slate-900">
                             {wizardData.vehicleNumber || '...'}
                          </div>
                          <div className="text-xs text-slate-600">
                             {wizardData.driverName || '...'}
                          </div>
                       </div>

                       <div className="h-px bg-slate-200" />

                       <div className="space-y-2">
                          <div className="flex items-center justify-between text-xs">
                             <span className="text-slate-500">Статус Ruqsat</span>
                             {wizardData.ruqsatSent ? (
                                <span className="text-green-600 font-bold flex items-center gap-1"><CheckCircle className="w-3 h-3"/> Готов</span>
                             ) : (
                                <span className="text-slate-400">Ожидание</span>
                             )}
                          </div>
                          <div className="flex items-center justify-between text-xs">
                             <span className="text-slate-500">QR водителя</span>
                             {wizardData.driverQrSent ? (
                                <span className="text-green-600 font-bold flex items-center gap-1"><CheckCircle className="w-3 h-3"/> Отправлен</span>
                             ) : (
                                <span className="text-slate-400">Не отправлен</span>
                             )}
                          </div>
                       </div>
                    </CardContent>
                 </Card>
              </div>
           </div>
        </div>

        {/* Wizard OTP Dialog (Reused) */}
        <Dialog open={showOtp} onOpenChange={setShowOtp}>
           <DialogContent className="max-w-sm text-center">
              <DialogHeader>
                 <DialogTitle className="text-center">Альтернативная верификация</DialogTitle>
                 <DialogDescription className="text-center">
                    Сообщите этот код сотруднику пункта пропуска, если QR-код не считывается
                 </DialogDescription>
              </DialogHeader>
              <div className="py-6 space-y-4">
                 <div className="text-5xl font-mono font-bold tracking-widest text-slate-900">
                    {otpCode || "492 105"}
                 </div>
                 <Button variant="outline" size="sm" onClick={generateOtp}>Сгенерировать новый</Button>
                 <div className="flex items-center justify-center gap-2 text-sm text-slate-500">
                    <Clock className="w-4 h-4" />
                    Действует ещё 5:00
                 </div>
              </div>
              <DialogFooter>
                 <Button className="w-full bg-blue-600 hover:bg-blue-700" onClick={() => setShowOtp(false)}>
                    Закрыть
                 </Button>
              </DialogFooter>
           </DialogContent>
        </Dialog>
      </div>
    );
  }

  // --- Detail View ---

  if (view === "detail" && selectedPass) {
    return (
      <div className="space-y-6 animate-in fade-in duration-300">
        {/* Header */}
        <div className="flex items-center justify-between pb-4 border-b border-slate-200">
          <div className="flex items-center gap-4">
            <Button variant="ghost" size="sm" onClick={handleBackToList} className="text-slate-500 hover:text-slate-900">
              <ArrowRight className="w-5 h-5 rotate-180" />
            </Button>
            <div>
              <h2 className="text-xl font-bold text-slate-900 flex items-center gap-2">
                Верифицированный проход
                <Badge variant="outline" className="font-mono text-xs">{selectedPass.tripId}</Badge>
              </h2>
              <p className="text-sm text-slate-500 mt-1">
                {selectedPass.route} • {selectedPass.plannedDate}
              </p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <Button variant="outline" size="sm">
              <Share2 className="w-4 h-4 mr-2" />
              Поделиться
            </Button>
            <Button variant="outline" size="sm" className="text-red-600 border-red-200 hover:bg-red-50">
              Отменить заявку
            </Button>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Left Column: Key Data & Actions */}
          <div className="lg:col-span-2 space-y-6">
            
            {/* A) Key Data */}
            <Card>
              <CardHeader>
                <CardTitle className="text-base font-semibold">Данные перевозки</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-x-8 gap-y-4">
                  <div>
                    <label className="text-xs font-medium text-slate-500">СВХ Отправления</label>
                    <div className="mt-1 text-sm font-medium text-slate-900 flex items-center gap-2">
                      <MapPin className="w-4 h-4 text-slate-400" />
                      {selectedPass.warehouse}
                    </div>
                  </div>
                  <div>
                    <label className="text-xs font-medium text-slate-500">КПП Выезда</label>
                    <div className="mt-1 text-sm font-medium text-slate-900 flex items-center gap-2">
                      <Shield className="w-4 h-4 text-slate-400" />
                      {selectedPass.checkpoint}
                    </div>
                  </div>
                  <div>
                    <label className="text-xs font-medium text-slate-500">Транспортное средство</label>
                    <div className="mt-1 text-sm font-medium text-slate-900 flex items-center gap-2">
                      <Truck className="w-4 h-4 text-slate-400" />
                      {selectedPass.vehicle} <span className="text-slate-400 font-normal">(Тягач)</span>
                    </div>
                  </div>
                  <div>
                    <label className="text-xs font-medium text-slate-500">Водитель</label>
                    <div className="mt-1 text-sm font-medium text-slate-900 flex items-center gap-2">
                      <User className="w-4 h-4 text-slate-400" />
                      {selectedPass.driver}
                    </div>
                  </div>
                  <div className="md:col-span-2">
                     <label className="text-xs font-medium text-slate-500">Дата планового выезда</label>
                     <div className="mt-1 flex items-center gap-2">
                        <Calendar className="w-4 h-4 text-slate-400" />
                        <span className="text-sm font-medium text-slate-900">{selectedPass.plannedDate}</span>
                        <Button variant="link" size="sm" className="h-auto p-0 text-blue-600 text-xs ml-2">Изменить</Button>
                     </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* B) Ruqsat Queue */}
            <Card className="overflow-hidden border-blue-100 shadow-sm">
              <div className="bg-blue-50/50 p-4 border-b border-blue-100 flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <div className="w-6 h-6 rounded bg-blue-600 text-white flex items-center justify-center text-xs font-bold">R</div>
                  <h3 className="font-semibold text-blue-900">Очередь Ruqsat</h3>
                </div>
                <Badge variant="outline" className={`
                  ${ruqsatStep === 'draft' ? 'bg-slate-100 text-slate-600' : 
                    ruqsatStep === 'processing' ? 'bg-blue-100 text-blue-700' : 
                    'bg-green-100 text-green-700'}
                `}>
                  {ruqsatStep === 'draft' ? 'Черновик' : ruqsatStep === 'processing' ? 'Отправка...' : 'QR Получен'}
                </Badge>
              </div>
              
              <CardContent className="p-6">
                {ruqsatStep === 'draft' && (
                  <div className="space-y-4">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div className="space-y-2">
                         <label className="text-xs font-medium text-slate-700">Тип перевозки</label>
                         <Select defaultValue="international">
                            <SelectTrigger>
                                <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                                <SelectItem value="international">Международная</SelectItem>
                                <SelectItem value="eaes">ЕАЭС</SelectItem>
                            </SelectContent>
                         </Select>
                      </div>
                      <div className="space-y-2">
                         <label className="text-xs font-medium text-slate-700">Время выезда</label>
                         <Input type="time" defaultValue="10:00" />
                      </div>
                    </div>
                    <div className="space-y-2">
                       <label className="text-xs font-medium text-slate-700">Комментарий для КПП (опционально)</label>
                       <Input placeholder="Например: скоропортящийся груз" />
                    </div>
                    <div className="pt-2 flex justify-end">
                       <Button onClick={handleSendRuqsat} className="bg-blue-600 hover:bg-blue-700">
                          Отправить в Ruqsat
                       </Button>
                    </div>
                  </div>
                )}

                {ruqsatStep === 'processing' && (
                   <div className="flex flex-col items-center justify-center py-8">
                      <RefreshCw className="w-8 h-8 text-blue-600 animate-spin mb-4" />
                      <p className="text-sm font-medium text-slate-900">Синхронизация с системой Ruqsat...</p>
                      <p className="text-xs text-slate-500 mt-1">Это может занять до 30 секунд</p>
                   </div>
                )}

                {ruqsatStep === 'approved' && (
                  <div className="flex flex-col sm:flex-row items-start gap-6">
                    <div className="bg-white p-2 rounded-lg border border-slate-200 shadow-sm shrink-0">
                       <QRCode 
                          value={`RUQSAT:${selectedPass.id}`} 
                          size={120} 
                          level="M"
                       />
                    </div>
                    <div className="flex-1 space-y-3">
                       <div className="text-sm font-medium text-green-700 flex items-center gap-2">
                          <CheckCircle className="w-4 h-4" />
                          Очередь забронирована успешно
                       </div>
                       <p className="text-xs text-slate-600 leading-relaxed">
                          <strong>Внимание:</strong> QR Ruqsat не является пропуском через границу. Идентификация на КПП происходит автоматически по ГРНЗ (считывание номера). Данный QR необходим для прохождения транспортного контроля.
                       </p>
                       <div className="flex gap-2 pt-2">
                          <Button variant="outline" size="sm" className="text-xs">
                             <Share2 className="w-3 h-3 mr-2" />
                             Поделиться
                          </Button>
                          <Button variant="ghost" size="sm" className="text-xs text-slate-500">
                             Скачать PDF
                          </Button>
                       </div>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* C) Smart Cargo QR for Driver */}
            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-base font-semibold flex items-center gap-2">
                   <QrCode className="w-5 h-5 text-slate-500" />
                   QR Smart Cargo для водителя
                </CardTitle>
                <CardDescription>Основной идентификатор для всех проверок внутри системы</CardDescription>
              </CardHeader>
              <CardContent>
                 <div className="bg-slate-50 rounded-lg p-4 border border-slate-200 flex flex-col sm:flex-row items-center justify-between gap-4">
                    <div className="flex items-center gap-4">
                       <div className="w-10 h-10 rounded-full bg-blue-100 flex items-center justify-center text-blue-600">
                          <User className="w-5 h-5" />
                       </div>
                       <div>
                          <div className="text-sm font-medium text-slate-900">Водителю отправлено</div>
                          <div className="text-xs text-slate-500">Статус: Доставлено в приложение</div>
                       </div>
                    </div>
                    <div className="flex items-center gap-2 w-full sm:w-auto">
                       <Button variant="outline" size="sm" onClick={() => setShowDriverQr(true)}>
                          <Eye className="w-4 h-4 mr-2" />
                          Показать QR
                       </Button>
                       <Button variant="outline" size="sm" onClick={generateOtp}>
                          <Lock className="w-4 h-4 mr-2" />
                          OTP код
                       </Button>
                    </div>
                 </div>
              </CardContent>
            </Card>

            {/* F) Documents */}
            <div>
               <h3 className="text-sm font-semibold text-slate-900 mb-3 uppercase tracking-wider">Документы (доступны по QR)</h3>
               <div className="space-y-2">
                  {[
                     { name: "CMR Накладная", type: "PDF", date: "16.02.2026", user: "СВХ Agent" },
                     { name: "Инвойс №4021", type: "PDF", date: "16.02.2026", user: "СВХ Agent" },
                     { name: "Экспортная декларация", type: "XML", date: "16.02.2026", user: "Broker K." },
                     { name: "Путевой лист", type: "PDF", date: "17.02.2026", user: "Carrier" }
                  ].map((doc, i) => (
                     <div key={i} className="flex items-center justify-between p-3 bg-white border border-slate-200 rounded-lg hover:border-blue-300 transition-colors cursor-pointer group">
                        <div className="flex items-center gap-3">
                           <FileText className="w-8 h-8 text-slate-300 group-hover:text-blue-500 transition-colors" />
                           <div>
                              <div className="text-sm font-medium text-slate-900 group-hover:text-blue-600">{doc.name}</div>
                              <div className="text-xs text-slate-500">{doc.date} • {doc.user}</div>
                           </div>
                        </div>
                        <Badge variant="secondary" className="text-xs">{doc.type}</Badge>
                     </div>
                  ))}
               </div>
            </div>

          </div>

          {/* Right Column: Timeline */}
          <div className="lg:col-span-1">
             <Card className="h-full border-none shadow-none bg-transparent">
                <CardHeader className="px-0 pt-0">
                   <CardTitle className="text-base font-semibold">Хронология</CardTitle>
                </CardHeader>
                <CardContent className="px-0">
                   <div className="relative border-l-2 border-slate-200 ml-3 space-y-6 pb-10">
                      {mockTimeline.map((event, idx) => (
                         <div key={idx} className="relative pl-6">
                            <div className={`absolute -left-[9px] top-1 w-4 h-4 rounded-full border-2 
                               ${event.status === 'completed' ? 'bg-white border-blue-600' : 
                                 event.status === 'processing' ? 'bg-blue-600 border-blue-600 animate-pulse' : 
                                 'bg-slate-100 border-slate-300'}`} 
                            />
                            <div className="flex flex-col">
                               <div className="flex items-center justify-between">
                                  <span className={`text-sm font-medium ${event.status === 'pending' ? 'text-slate-400' : 'text-slate-900'}`}>
                                     {event.title}
                                  </span>
                                  {event.time !== "--:--" && (
                                     <span className="text-xs text-slate-400">{event.time}</span>
                                  )}
                               </div>
                               <div className="flex items-center gap-2 mt-1">
                                  <Badge variant="outline" className="text-[10px] h-5 px-1.5 py-0 bg-slate-50">
                                     {event.source}
                                  </Badge>
                                  {event.date && <span className="text-xs text-slate-400">{event.date}</span>}
                               </div>
                            </div>
                         </div>
                      ))}
                   </div>
                </CardContent>
             </Card>
          </div>
        </div>

        {/* OTP Dialog */}
        <Dialog open={showOtp} onOpenChange={setShowOtp}>
           <DialogContent className="max-w-sm text-center">
              <DialogHeader>
                 <DialogTitle className="text-center">Альтернативная верификация</DialogTitle>
                 <DialogDescription className="text-center">
                    Сообщите этот код сотруднику пункта пропуска, если QR-код не считывается
                 </DialogDescription>
              </DialogHeader>
              <div className="py-6 space-y-4">
                 <div className="text-5xl font-mono font-bold tracking-widest text-slate-900">
                    {otpCode}
                 </div>
                 <div className="flex items-center justify-center gap-2 text-sm text-slate-500">
                    <Clock className="w-4 h-4" />
                    Действует ещё {formatTime(otpTimer)}
                 </div>
              </div>
              <DialogFooter className="flex-col gap-2 sm:gap-0">
                 <Button className="w-full bg-blue-600 hover:bg-blue-700" onClick={() => setShowOtp(false)}>
                    Закрыть
                 </Button>
              </DialogFooter>
           </DialogContent>
        </Dialog>

        {/* Driver QR Dialog */}
        <Dialog open={showDriverQr} onOpenChange={setShowDriverQr}>
           <DialogContent className="max-w-sm flex flex-col items-center">
              <DialogHeader>
                 <DialogTitle>QR Smart Cargo</DialogTitle>
              </DialogHeader>
              <div className="p-4 bg-white border-2 border-blue-500 rounded-xl my-4">
                 <QRCode value={`SMART_CARGO:${selectedPass.id}`} size={200} />
              </div>
              <p className="text-center text-sm text-slate-500 mb-4">
                 Передайте этот QR водителю, если у него нет доступа к приложению
              </p>
              <Button onClick={() => setShowDriverQr(false)} className="w-full">Закрыть</Button>
           </DialogContent>
        </Dialog>
      </div>
    );
  }

  // --- List View (Default) ---
  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl font-semibold text-slate-900">Верифицированный проход</h2>
          <p className="text-slate-600 mt-1">Единый реестр заявок на пересечение границы</p>
        </div>
        <div className="flex gap-2">
           <Button variant="outline" className="hidden sm:flex">
              <FileCheck className="w-4 h-4 mr-2" />
              Отчеты
           </Button>
           <Button className="bg-blue-600 hover:bg-blue-700" onClick={handleStartWizard}>
              <Shield className="w-4 h-4 mr-2" />
              Новая заявка
           </Button>
        </div>
      </div>

      {/* Filters */}
      <div className="flex flex-col sm:flex-row gap-3 bg-white p-4 rounded-lg border border-slate-200 shadow-sm">
        <div className="relative flex-1">
           <Search className="absolute left-3 top-2.5 w-4 h-4 text-slate-400" />
           <Input
             placeholder="Поиск по ID, водителю или ТС"
             value={searchQuery}
             onChange={(e) => setSearchQuery(e.target.value)}
             className="pl-9"
           />
        </div>
        <Select value={statusFilter} onValueChange={setStatusFilter}>
          <SelectTrigger className="w-full sm:w-48">
            <SelectValue placeholder="Статус Ruqsat" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">Все статусы</SelectItem>
            <SelectItem value="draft">Черновик</SelectItem>
            <SelectItem value="approved">Одобрено</SelectItem>
            <SelectItem value="error">Ошибка</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {/* Table */}
      <div className="bg-white rounded-lg border border-slate-200 overflow-hidden shadow-sm">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-slate-50 border-b border-slate-200">
              <tr>
                <th className="px-4 py-3 text-left text-xs font-semibold uppercase tracking-wider text-slate-500">Перевозка / Маршрут</th>
                <th className="px-4 py-3 text-left text-xs font-semibold uppercase tracking-wider text-slate-500">Транспорт / Водитель</th>
                <th className="px-4 py-3 text-left text-xs font-semibold uppercase tracking-wider text-slate-500">Дата выезда</th>
                <th className="px-4 py-3 text-left text-xs font-semibold uppercase tracking-wider text-slate-500">Ruqsat</th>
                <th className="px-4 py-3 text-left text-xs font-semibold uppercase tracking-wider text-slate-500">КПП</th>
                <th className="px-4 py-3 text-right text-xs font-semibold uppercase tracking-wider text-slate-500">Действия</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filteredPasses.map((pass) => (
                <tr key={pass.id} className="hover:bg-slate-50 transition-colors group cursor-pointer" onClick={() => handleOpenDetail(pass)}>
                  <td className="px-4 py-4 align-top">
                    <div className="font-medium text-blue-600 text-sm">{pass.tripId}</div>
                    <div className="text-xs text-slate-500 mt-1 max-w-[200px] truncate">{pass.route}</div>
                  </td>
                  <td className="px-4 py-4 align-top">
                    <div className="text-sm text-slate-900 font-medium">{pass.vehicle}</div>
                    <div className="text-xs text-slate-500 mt-1">{pass.driver}</div>
                  </td>
                  <td className="px-4 py-4 align-top">
                    <div className="text-sm text-slate-900">{pass.plannedDate}</div>
                    <div className="text-xs text-slate-400 mt-1">План</div>
                  </td>
                  <td className="px-4 py-4 align-top">
                     {pass.ruqsatStatus === 'approved' ? (
                        <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200 font-normal">
                           <CheckCircle className="w-3 h-3 mr-1" /> Подтвержден
                        </Badge>
                     ) : pass.ruqsatStatus === 'draft' ? (
                        <Badge variant="outline" className="bg-slate-50 text-slate-600 border-slate-200 font-normal">
                           Черновик
                        </Badge>
                     ) : (
                        <Badge variant="outline" className="bg-red-50 text-red-700 border-red-200 font-normal">
                           <AlertTriangle className="w-3 h-3 mr-1" /> Ошибка
                        </Badge>
                     )}
                  </td>
                  <td className="px-4 py-4 align-top">
                     {pass.checkpointStatus === 'arrived' ? (
                        <span className="inline-flex items-center text-xs font-medium text-blue-600">
                           <MapPin className="w-3 h-3 mr-1" /> Прибыл
                        </span>
                     ) : (
                        <span className="text-xs text-slate-400">В пути</span>
                     )}
                  </td>
                  <td className="px-4 py-4 text-right align-top">
                    <Button
                      variant="ghost"
                      size="sm"
                      className="text-slate-400 hover:text-blue-600"
                    >
                      <ChevronRight className="w-5 h-5" />
                    </Button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}