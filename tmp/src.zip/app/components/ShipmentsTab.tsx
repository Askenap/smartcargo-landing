import { useState } from "react";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { Search, Filter, Plus, FileText, Truck, CheckCircle, XCircle, MapPin, QrCode, Grid3x3, List, Clock, ExternalLink, ArrowRight, Gauge } from "lucide-react";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "./ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "./ui/dialog";
import { Popover, PopoverContent, PopoverTrigger } from "./ui/popover";
import ShipmentDetails from "./ShipmentDetails";
import TrackingMap from "./TrackingMap";
import QRCodeDisplay from "./QRCodeDisplay";
import DriverPopover from "./DriverPopover";

type ShipmentStatus = "formed" | "in_progress" | "completed" | "stopped";
type OriginType = "PI_TD" | "SNT" | "E_TTN";

export interface Shipment {
  id: string;
  from: string;
  fromFlag: string;
  to: string;
  toFlag: string;
  totalAmount: string;
  status: ShipmentStatus;
  registrationNumber: string;
  transport?: string;
  driver?: string;
  originType: OriginType;
}

const mockShipments: Shipment[] = [
  {
    id: "1",
    from: "Китай",
    fromFlag: "🇨🇳",
    to: "Таджикистан",
    toFlag: "🇹🇯",
    totalAmount: "13894 KZT",
    status: "in_progress",
    registrationNumber: "39857505/270126/9021424",
    transport: "A123BC 01",
    driver: "Иванов И.И.",
    originType: "PI_TD",
  },
  {
    id: "2",
    from: "Китай",
    fromFlag: "🇨🇳",
    to: "Россия",
    toFlag: "🇷🇺",
    totalAmount: "459974.4 KZT",
    status: "completed",
    registrationNumber: "SN-2026-00789456",
    transport: "B456DE 02",
    driver: "Петров П.П.",
    originType: "SNT",
  },
  {
    id: "3",
    from: "Китай",
    fromFlag: "🇨🇳",
    to: "Узбекистан",
    toFlag: "🇺🇿",
    totalAmount: "53300 KZT",
    status: "in_progress",
    registrationNumber: "TTN-2026-123789",
    transport: "C789FG 03",
    originType: "E_TTN",
  },
  {
    id: "4",
    from: "Эквадор",
    fromFlag: "🇪🇨",
    to: "Узбекистан",
    toFlag: "🇺🇿",
    totalAmount: "2298.24 KZT",
    status: "in_progress",
    registrationNumber: "10216100/280126/5000597",
    transport: "D012HI 04",
    driver: "Сидоров С.С.",
    originType: "PI_TD",
  },
  {
    id: "5",
    from: "Чешская Республика",
    fromFlag: "🇨🇿",
    to: "Казахстан",
    toFlag: "🇰🇿",
    totalAmount: "16652.52 KZT",
    status: "in_progress",
    registrationNumber: "SN-2026-00445632",
    transport: "E345JK 05",
    originType: "SNT",
  },
  {
    id: "6",
    from: "Китай",
    fromFlag: "🇨🇳",
    to: "Туркмения",
    toFlag: "🇹🇲",
    totalAmount: "22759.2 KZT",
    status: "in_progress",
    registrationNumber: "TTN-2026-987456",
    transport: "F678LM 06",
    driver: "Алиев А.А.",
    originType: "E_TTN",
  },
  {
    id: "7",
    from: "Китай",
    fromFlag: "🇨🇳",
    to: "Казахстан",
    toFlag: "🇰🇿",
    totalAmount: "48000 KZT",
    status: "in_progress",
    registrationNumber: "39857505/240126/9019390",
    transport: "G901NO 07",
    originType: "PI_TD",
  },
  {
    id: "8",
    from: "Таджикистан",
    fromFlag: "🇹🇯",
    to: "Китай",
    toFlag: "🇨🇳",
    totalAmount: "0 KZT",
    status: "in_progress",
    registrationNumber: "39855507/240126/9022387",
    transport: "H234PQ 08",
    driver: "Мамедов М.М.",
    originType: "PI_TD",
  },
];

const statusConfig = {
  formed: { label: "Сформирован", color: "text-yellow-700", bg: "bg-yellow-50", icon: FileText },
  in_progress: { label: "В процессе поставки", color: "text-blue-700", bg: "bg-blue-50", icon: Truck },
  completed: { label: "Завершено", color: "text-green-700", bg: "bg-green-50", icon: CheckCircle },
  stopped: { label: "Остановлено", color: "text-red-700", bg: "bg-red-50", icon: XCircle },
};

// Mock drivers data
const mockDrivers = [
  { id: "1", fullName: "Иванов Иван Иванович", driverId: "DRV-001", phone: "+7 777 123 4567", status: "active" as const },
  { id: "2", fullName: "Петров Петр Петрович", driverId: "DRV-002", phone: "+7 777 234 5678", status: "active" as const },
  { id: "3", fullName: "Сидоров Сидор Сидорович", driverId: "DRV-003", phone: "+7 777 345 6789", status: "on_route" as const },
  { id: "4", fullName: "Казымов Асан Болатович", driverId: "DRV-004", phone: "+7 777 456 7890", status: "active" as const },
];

// Helper function to format amounts
function formatAmount(amount: string): string {
  const [value, currency] = amount.split(" ");
  const num = parseFloat(value);
  const formattedValue = num.toLocaleString("ru-RU", {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  });
  return `${formattedValue} ${currency}`;
}

export default function ShipmentsTab() {
  const [searchQuery, setSearchQuery] = useState("");
  const [showFilters, setShowFilters] = useState(false);
  const [statusFilter, setStatusFilter] = useState<string>("all");
  const [countryFromFilter, setCountryFromFilter] = useState<string>("all");
  const [countryToFilter, setCountryToFilter] = useState<string>("all");
  const [originFilter, setOriginFilter] = useState<string>("all");
  const [selectedShipment, setSelectedShipment] = useState<Shipment | null>(null);
  const [trackingShipment, setTrackingShipment] = useState<Shipment | null>(null);
  const [showQRDialog, setShowQRDialog] = useState(false);
  const [qrShipment, setQrShipment] = useState<Shipment | null>(null);
  const [showQRSelector, setShowQRSelector] = useState(false);
  const [viewMode, setViewMode] = useState<"grid" | "list">("grid"); // Default to grid view
  const [assignDriverShipment, setAssignDriverShipment] = useState<Shipment | null>(null);
  const [showAssignDriverDialog, setShowAssignDriverDialog] = useState(false);
  const [driverPopoverOpen, setDriverPopoverOpen] = useState<string | null>(null);

  // Calculate statistics
  const stats = {
    formed: mockShipments.filter((s) => s.status === "formed").length,
    in_progress: mockShipments.filter((s) => s.status === "in_progress").length,
    completed: mockShipments.filter((s) => s.status === "completed").length,
    stopped: mockShipments.filter((s) => s.status === "stopped").length,
  };

  // Filter shipments
  const filteredShipments = mockShipments.filter((shipment) => {
    const matchesSearch =
      searchQuery === "" ||
      shipment.registrationNumber.toLowerCase().includes(searchQuery.toLowerCase()) ||
      shipment.from.toLowerCase().includes(searchQuery.toLowerCase()) ||
      shipment.to.toLowerCase().includes(searchQuery.toLowerCase());

    const matchesStatus = statusFilter === "all" || shipment.status === statusFilter;
    const matchesCountryFrom = countryFromFilter === "all" || shipment.from === countryFromFilter;
    const matchesCountryTo = countryToFilter === "all" || shipment.to === countryToFilter;
    const matchesOrigin = originFilter === "all" || shipment.originType === originFilter;

    return matchesSearch && matchesStatus && matchesCountryFrom && matchesCountryTo && matchesOrigin;
  });

  // If a shipment is selected, show details
  if (selectedShipment) {
    return <ShipmentDetails shipment={selectedShipment} onBack={() => setSelectedShipment(null)} />;
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <h2 className="text-2xl font-semibold text-slate-900">Мои грузы ({mockShipments.length})</h2>
        <div className="flex gap-2">
          <Button variant="outline" className="text-slate-600">
            Обновить
          </Button>
        </div>
      </div>

      {/* Statistics Cards */}
      <div className="bg-white rounded-lg border border-slate-200 p-5">
        <h3 className="text-base font-semibold text-slate-900 mb-5">Статус перевозок</h3>
        <div className="grid grid-cols-2 gap-4 md:flex md:items-start md:justify-between md:gap-2">
          {/* Сформирован */}
          <div className="flex-1 flex flex-col items-center p-2 rounded-lg hover:bg-slate-50 transition-colors">
            <div className="w-10 h-10 rounded-full bg-yellow-100 border-2 border-yellow-500 flex items-center justify-center flex-shrink-0 z-10">
              <FileText className="w-4 h-4 text-yellow-600" />
            </div>
            <div className="text-xl font-bold text-yellow-600 mt-2.5">{stats.formed}</div>
            <div className="text-xs font-semibold text-slate-900 mt-1 text-center">Сформирован</div>
            <div className="text-[10px] text-slate-500 mt-0.5 text-center">В ожидании отправки</div>
          </div>

          {/* Arrow connector */}
          <div className="hidden md:flex items-center pt-5">
            <div className="h-0.5 w-6 bg-gradient-to-r from-yellow-300 to-blue-300"></div>
          </div>

          {/* В процессе поставки */}
          <div className="flex-1 flex flex-col items-center p-2 rounded-lg hover:bg-slate-50 transition-colors">
            <div className="w-10 h-10 rounded-full bg-blue-100 border-2 border-blue-500 flex items-center justify-center flex-shrink-0 z-10">
              <Truck className="w-4 h-4 text-blue-600" />
            </div>
            <div className="text-xl font-bold text-blue-600 mt-2.5">{stats.in_progress}</div>
            <div className="text-xs font-semibold text-slate-900 mt-1 text-center">В процессе</div>
            <div className="text-[10px] text-slate-500 mt-0.5 text-center">Активные перевозки</div>
          </div>

          {/* Arrow connector */}
          <div className="hidden md:flex items-center pt-5">
            <div className="h-0.5 w-6 bg-gradient-to-r from-blue-300 to-green-300"></div>
          </div>

          {/* Завершено */}
          <div className="flex-1 flex flex-col items-center p-2 rounded-lg hover:bg-slate-50 transition-colors">
            <div className="w-10 h-10 rounded-full bg-green-100 border-2 border-green-500 flex items-center justify-center flex-shrink-0 z-10">
              <CheckCircle className="w-4 h-4 text-green-600" />
            </div>
            <div className="text-xl font-bold text-green-600 mt-2.5">{stats.completed}</div>
            <div className="text-xs font-semibold text-slate-900 mt-1 text-center">Завершено</div>
            <div className="text-[10px] text-slate-500 mt-0.5 text-center">Успешно доставлено</div>
          </div>

          {/* Arrow connector */}
          <div className="hidden md:flex items-center pt-5">
            <div className="h-0.5 w-6 bg-gradient-to-r from-green-300 to-red-300"></div>
          </div>

          {/* Остановлено */}
          <div className="flex-1 flex flex-col items-center p-2 rounded-lg hover:bg-slate-50 transition-colors">
            <div className="w-10 h-10 rounded-full bg-red-100 border-2 border-red-500 flex items-center justify-center flex-shrink-0 z-10">
              <XCircle className="w-4 h-4 text-red-600" />
            </div>
            <div className="text-xl font-bold text-red-600 mt-2.5">{stats.stopped}</div>
            <div className="text-xs font-semibold text-slate-900 mt-1 text-center">Остановлено</div>
            <div className="text-[10px] text-slate-500 mt-0.5 text-center">Требуется внимание</div>
          </div>
        </div>
      </div>

      {/* Search and Filters */}
      <div className="bg-white rounded-lg border border-slate-200 p-4">
        <div className="flex flex-col sm:flex-row gap-3">
          <div className="flex-1 flex gap-2">
            <Input
              placeholder="оиск груза по номеру"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="flex-1"
            />
            <Button variant="default" className="bg-sky-500 hover:bg-sky-600">
              <Search className="w-4 h-4" />
            </Button>
          </div>
          <Button
            variant="outline"
            onClick={() => setShowFilters(!showFilters)}
            className={showFilters ? "bg-slate-100" : ""}
          >
            <Filter className="w-4 h-4 mr-2" />
            Фильтры
          </Button>
        </div>

        {/* Filter Panel */}
        {showFilters && (
          <div className="mt-4 pt-4 border-t border-slate-200">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div>
                <label className="text-sm text-slate-600 mb-2 block">Статус</label>
                <Select value={statusFilter} onValueChange={setStatusFilter}>
                  <SelectTrigger>
                    <SelectValue placeholder="Все статусы" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">Все статусы</SelectItem>
                    <SelectItem value="formed">Сформирован</SelectItem>
                    <SelectItem value="in_progress">В процессе поставки</SelectItem>
                    <SelectItem value="completed">Завершено</SelectItem>
                    <SelectItem value="stopped">Остановлено</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div>
                <label className="text-sm text-slate-600 mb-2 block">Откуда</label>
                <Select value={countryFromFilter} onValueChange={setCountryFromFilter}>
                  <SelectTrigger>
                    <SelectValue placeholder="Все страны" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">Все страны</SelectItem>
                    <SelectItem value="Китай">Китай</SelectItem>
                    <SelectItem value="Россия">Россия</SelectItem>
                    <SelectItem value="Казахстан">Казахстан</SelectItem>
                    <SelectItem value="Узбекистан">Узбекистан</SelectItem>
                    <SelectItem value="Таджикистан">Таджикистан</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div>
                <label className="text-sm text-slate-600 mb-2 block">Куда</label>
                <Select value={countryToFilter} onValueChange={setCountryToFilter}>
                  <SelectTrigger>
                    <SelectValue placeholder="Все страны" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">Все страны</SelectItem>
                    <SelectItem value="Китай">Китай</SelectItem>
                    <SelectItem value="Россия">Россия</SelectItem>
                    <SelectItem value="Казахстан">Казахстан</SelectItem>
                    <SelectItem value="Узбекистан">Узбекистан</SelectItem>
                    <SelectItem value="Таджикистан">Таджикистан</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div>
                <label className="text-sm text-slate-600 mb-2 block">Происхождение</label>
                <Select value={originFilter} onValueChange={setOriginFilter}>
                  <SelectTrigger>
                    <SelectValue placeholder="Все типы" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">Все типы</SelectItem>
                    <SelectItem value="PI_TD">ПИ/ТД</SelectItem>
                    <SelectItem value="SNT">СНТ</SelectItem>
                    <SelectItem value="E_TTN">Е-ТТН</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="mt-4 flex gap-2">
              <Button
                variant="outline"
                size="sm"
                onClick={() => {
                  setStatusFilter("all");
                  setCountryFromFilter("all");
                  setCountryToFilter("all");
                  setOriginFilter("all");
                  setSearchQuery("");
                }}
              >
                Сбросить фильтры
              </Button>
            </div>
          </div>
        )}
      </div>

      {/* Table */}
      <div className="bg-white rounded-lg border border-slate-200 overflow-hidden">
        {/* View Mode Toggle */}
        <div className="px-4 py-3 border-b border-slate-200 flex items-center justify-between">
          <div className="text-sm text-slate-600">
            Показано {filteredShipments.length} из {mockShipments.length} грузов
          </div>
          <div className="flex gap-1">
            <button
              onClick={() => setViewMode("grid")}
              className={`p-2 rounded transition-colors ${
                viewMode === "grid"
                  ? "bg-sky-500 text-white"
                  : "bg-slate-100 text-slate-600 hover:bg-slate-200"
              }`}
              title="Плиточный вид"
            >
              <Grid3x3 className="w-4 h-4" />
            </button>
            <button
              onClick={() => setViewMode("list")}
              className={`p-2 rounded transition-colors ${
                viewMode === "list"
                  ? "bg-sky-500 text-white"
                  : "bg-slate-100 text-slate-600 hover:bg-slate-200"
              }`}
              title="Табличный вид"
            >
              <List className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Grid View */}
        {viewMode === "grid" && (
          <div className="p-6">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {filteredShipments.map((shipment) => {
                const statusInfo = statusConfig[shipment.status];
                return (
                  <div
                    key={shipment.id}
                    className="bg-white border border-slate-200 rounded-lg p-4 hover:shadow-md transition-shadow"
                  >
                    {/* Header */}
                    <div className="flex items-start justify-between mb-3">
                      <div className="flex items-center gap-2">
                        <Truck className="w-5 h-5 text-sky-600" />
                        <div>
                          <div className="text-xs font-medium text-slate-900">
                            SC/{shipment.registrationNumber.split("/")[0]}
                          </div>
                          <div className="text-xs text-slate-500 flex items-center gap-1">
                            <Clock className="w-3 h-3" />
                            26.12.2025 10:48:14
                          </div>
                        </div>
                      </div>
                    </div>

                    {/* Status Badge */}
                    <div className="mb-4">
                      <span
                        className={`inline-flex items-center px-2.5 py-1 rounded-full text-xs font-medium ${statusInfo.bg} ${statusInfo.color}`}
                      >
                        {statusInfo.label}
                      </span>
                    </div>

                    {/* Route Progress Bar */}
                    <div className="mb-4">
                      <div className="flex items-center gap-2">
                        {/* From */}
                        <div className="flex flex-col items-center">
                          <div className="w-8 h-8 rounded-full bg-sky-500 flex items-center justify-center flex-shrink-0">
                            <span className="text-white text-xs">{shipment.fromFlag}</span>
                          </div>
                        </div>

                        {/* Progress line */}
                        <div className="flex-1 flex items-center gap-1">
                          <div className="w-3 h-3 rounded-full bg-sky-500 flex-shrink-0"></div>
                          <div className="flex-1 h-0.5 bg-slate-200 relative">
                            <div className="absolute inset-0 bg-sky-500" style={{ width: "60%" }}></div>
                          </div>
                          <div className="w-3 h-3 rounded-full bg-slate-200 flex-shrink-0"></div>
                          <div className="flex-1 h-0.5 bg-slate-200"></div>
                          <div className="w-3 h-3 rounded-full bg-slate-200 flex-shrink-0"></div>
                        </div>

                        {/* To */}
                        <div className="flex flex-col items-center">
                          <div className="w-8 h-8 rounded-full bg-slate-200 flex items-center justify-center flex-shrink-0">
                            <span className="text-xs">{shipment.toFlag}</span>
                          </div>
                        </div>
                      </div>

                      {/* Country labels */}
                      <div className="flex items-center justify-between mt-2">
                        <div className="text-xs font-medium text-slate-900">{shipment.from}</div>
                        <div className="text-xs font-medium text-slate-500">{shipment.to}</div>
                      </div>
                    </div>

                    {/* Registration Number */}
                    <div className="mb-3">
                      <div className="text-xs text-slate-500 mb-1">Регистрационный номер</div>
                      <div className="text-xs font-medium text-slate-900">{shipment.registrationNumber}</div>
                    </div>

                    {/* Invoice Amount */}
                    <div className="mb-4">
                      <div className="text-xs text-slate-500 mb-1">Сумма инвойса</div>
                      <div className="text-sm font-medium text-slate-900 tabular-nums">
                        {formatAmount(shipment.totalAmount)}
                      </div>
                    </div>

                    {/* Actions */}
                    <div className="flex items-center gap-2">
                      <Button
                        size="sm"
                        variant="outline"
                        className="text-sky-600 border-sky-300 hover:bg-sky-50"
                        onClick={() => setSelectedShipment(shipment)}
                      >
                        Открыть
                      </Button>
                      <Button
                        size="sm"
                        variant="outline"
                        className="text-slate-600 border-slate-300 hover:bg-slate-50"
                        title="Трекинг"
                        onClick={() => setTrackingShipment(shipment)}
                      >
                        <MapPin className="w-4 h-4" />
                      </Button>
                      <Button
                        size="sm"
                        variant="outline"
                        className="text-sky-600 border-sky-300 hover:bg-sky-50"
                        title="QR-код"
                        onClick={() => {
                          setQrShipment(shipment);
                          setShowQRDialog(true);
                        }}
                      >
                        <QrCode className="w-4 h-4" />
                      </Button>
                      <DriverPopover
                        shipmentId={shipment.id}
                        drivers={mockDrivers}
                        onSelect={(driverId, shipmentId) => {
                          console.log(`Assigned driver ${driverId} to shipment ${shipmentId}`);
                        }}
                      />
                    </div>
                  </div>
                );
              })}
            </div>

            {filteredShipments.length === 0 && (
              <div className="text-center py-12">
                <p className="text-slate-500">Грузы не найдены</p>
              </div>
            )}
          </div>
        )}

        {/* List View */}
        {viewMode === "list" && (
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-slate-50 border-b border-slate-200">
                <tr>
                  <th className="px-4 py-3 text-left text-sm font-medium text-slate-700">Откуда</th>
                  <th className="px-4 py-3 text-left text-sm font-medium text-slate-700">Куда</th>
                  <th className="px-4 py-3 text-left text-sm font-medium text-slate-700">Общая сумма</th>
                  <th className="px-4 py-3 text-left text-sm font-medium text-slate-700">Статус</th>
                  <th className="px-4 py-3 text-left text-sm font-medium text-slate-700">
                    Регистрационный номер
                  </th>
                  <th className="px-4 py-3 text-right text-sm font-medium text-slate-700">Действия</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {filteredShipments.map((shipment) => {
                  const statusInfo = statusConfig[shipment.status];
                  return (
                    <tr key={shipment.id} className="hover:bg-slate-50 transition-colors">
                      <td className="px-4 py-4">
                        <div className="flex items-center gap-2">
                          <span className="text-xl">{shipment.fromFlag}</span>
                          <span className="text-sm text-slate-900">{shipment.from}</span>
                        </div>
                      </td>
                      <td className="px-4 py-4">
                        <div className="flex items-center gap-2">
                          <span className="text-xl">{shipment.toFlag}</span>
                          <span className="text-sm text-slate-900">{shipment.to}</span>
                        </div>
                      </td>
                      <td className="px-4 py-4">
                        <span className="text-sm text-slate-900 font-medium tabular-nums">
                          {formatAmount(shipment.totalAmount)}
                        </span>
                      </td>
                      <td className="px-4 py-4">
                        <span
                          className={`inline-flex items-center px-3 py-1 rounded-full text-xs font-medium ${statusInfo.bg} ${statusInfo.color}`}
                        >
                          {statusInfo.label}
                        </span>
                      </td>
                      <td className="px-4 py-4">
                        <span className="text-sm text-sky-600 hover:text-sky-700 cursor-pointer font-medium">
                          {shipment.registrationNumber}
                        </span>
                      </td>
                      <td className="px-4 py-4">
                        <div className="flex items-center justify-end gap-2">
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => setSelectedShipment(shipment)}
                            className="text-sky-600 border-sky-300 hover:bg-sky-50"
                          >
                            Открыть
                          </Button>
                          <Button
                            size="sm"
                            variant="outline"
                            className="text-slate-600 border-slate-300 hover:bg-slate-50"
                            title="Трекинг"
                            onClick={() => setTrackingShipment(shipment)}
                          >
                            <MapPin className="w-4 h-4" />
                          </Button>
                          <Button
                            size="sm"
                            variant="outline"
                            className="text-sky-600 border-sky-300 hover:bg-sky-50"
                            title="QR-код"
                            onClick={() => {
                              setQrShipment(shipment);
                              setShowQRDialog(true);
                            }}
                          >
                            <QrCode className="w-4 h-4" />
                          </Button>
                          <DriverPopover
                            shipmentId={shipment.id}
                            drivers={mockDrivers}
                            onSelect={(driverId, shipmentId) => {
                              console.log(`Assigned driver ${driverId} to shipment ${shipmentId}`);
                            }}
                          />
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>

            {filteredShipments.length === 0 && (
              <div className="text-center py-12">
                <p className="text-slate-500">Грузы не найдены</p>
              </div>
            )}
          </div>
        )}
      </div>

      {/* Tracking Map Dialog */}
      <Dialog open={!!trackingShipment} onOpenChange={(open) => !open && setTrackingShipment(null)}>
        <DialogContent className="max-w-4xl h-[80vh] flex flex-col">
          <DialogHeader>
            <DialogTitle>
              Трекинг груза {trackingShipment?.fromFlag} {trackingShipment?.from} → {trackingShipment?.toFlag}{" "}
              {trackingShipment?.to}
            </DialogTitle>
            <DialogDescription className="sr-only">
              Карта трекинга маршрута перевозки
            </DialogDescription>
          </DialogHeader>
          <div className="flex-1 min-h-0">
            <TrackingMap />
          </div>
        </DialogContent>
      </Dialog>

      {/* QR Code Dialog */}
      <Dialog open={showQRDialog} onOpenChange={setShowQRDialog}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>
              QR-код перевозки {qrShipment?.fromFlag} {qrShipment?.from} → {qrShipment?.toFlag} {qrShipment?.to}
            </DialogTitle>
            <DialogDescription>
              Единый паспорт перевозки (ЦПП) № SC/{qrShipment?.registrationNumber}
            </DialogDescription>
          </DialogHeader>
          <QRCodeDisplay tripId={`SC/${qrShipment?.registrationNumber}`} lastSync="2026-02-17 16:30" />
        </DialogContent>
      </Dialog>

      {/* QR Code Selector Dialog */}
      <Dialog open={showQRSelector} onOpenChange={setShowQRSelector}>
        <DialogContent className="max-w-4xl h-[80vh] flex flex-col">
          <DialogHeader>
            <DialogTitle>Выберите перевозку для QR-кода</DialogTitle>
            <DialogDescription className="sr-only">
              Выберите перевозку для отображения QR-кода
            </DialogDescription>
          </DialogHeader>
          <div className="flex-1 min-h-0">
            <table className="w-full">
              <thead className="bg-slate-50 border-b border-slate-200">
                <tr>
                  <th className="px-4 py-3 text-left text-sm font-medium text-slate-700">Откуда</th>
                  <th className="px-4 py-3 text-left text-sm font-medium text-slate-700">Куда</th>
                  <th className="px-4 py-3 text-left text-sm font-medium text-slate-700">Общая сумма</th>
                  <th className="px-4 py-3 text-left text-sm font-medium text-slate-700">Статус</th>
                  <th className="px-4 py-3 text-left text-sm font-medium text-slate-700">
                    Регистрационный номер
                  </th>
                  <th className="px-4 py-3 text-right text-sm font-medium text-slate-700">Действия</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {filteredShipments.map((shipment) => {
                  const statusInfo = statusConfig[shipment.status];
                  return (
                    <tr key={shipment.id} className="hover:bg-slate-50 transition-colors">
                      <td className="px-4 py-4">
                        <div className="flex items-center gap-2">
                          <span className="text-xl">{shipment.fromFlag}</span>
                          <span className="text-sm text-slate-900">{shipment.from}</span>
                        </div>
                      </td>
                      <td className="px-4 py-4">
                        <div className="flex items-center gap-2">
                          <span className="text-xl">{shipment.toFlag}</span>
                          <span className="text-sm text-slate-900">{shipment.to}</span>
                        </div>
                      </td>
                      <td className="px-4 py-4">
                        <span className="text-sm text-slate-900 font-medium tabular-nums">
                          {formatAmount(shipment.totalAmount)}
                        </span>
                      </td>
                      <td className="px-4 py-4">
                        <span
                          className={`inline-flex items-center px-3 py-1 rounded-full text-xs font-medium ${statusInfo.bg} ${statusInfo.color}`}
                        >
                          {statusInfo.label}
                        </span>
                      </td>
                      <td className="px-4 py-4">
                        <span className="text-sm text-sky-600 hover:text-sky-700 cursor-pointer font-medium">
                          {shipment.registrationNumber}
                        </span>
                      </td>
                      <td className="px-4 py-4">
                        <div className="flex items-center justify-end gap-2">
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => {
                              setQrShipment(shipment);
                              setShowQRDialog(true);
                              setShowQRSelector(false);
                            }}
                            className="text-sky-600 border-sky-300 hover:bg-sky-50"
                          >
                            QR-код
                          </Button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </DialogContent>
      </Dialog>

      {/* Assign Driver Dialog */}
      <Dialog open={showAssignDriverDialog} onOpenChange={setShowAssignDriverDialog}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>Добавить водителя</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            {/* ИИН водителя */}
            <div>
              <label className="text-sm font-medium text-slate-900 mb-2 block">ИИН водителя</label>
              <Input placeholder="Введите ИИН" className="w-full" maxLength={12} />
            </div>

            {/* Номер телефона */}
            <div>
              <label className="text-sm font-medium text-slate-900 mb-2 block">
                Номер телефона <span className="text-red-500">*</span>
              </label>
              <div className="flex gap-2">
                <div className="flex items-center justify-center gap-2 px-3 border border-slate-300 rounded-md bg-white h-10">
                  <span className="text-lg">🇰🇿</span>
                  <span className="text-sm text-slate-700">KZ</span>
                </div>
                <Input 
                  placeholder="+7 000 000 00 00" 
                  className="flex-1" 
                  defaultValue="+7 "
                />
              </div>
            </div>

            {/* Транспорт */}
            <div>
              <label className="text-sm font-medium text-slate-900 mb-2 block">
                Транспорт <span className="text-red-500">*</span>
              </label>
              <Input 
                value={assignDriverShipment?.transport || ""} 
                disabled
                className="w-full bg-slate-100 text-slate-500 cursor-not-allowed"
              />
            </div>

            {/* Buttons */}
            <div className="flex gap-3 justify-end pt-2">
              <Button
                variant="outline"
                onClick={() => setShowAssignDriverDialog(false)}
                className="px-6"
              >
                Отменить
              </Button>
              <Button
                className="bg-sky-500 hover:bg-sky-600 px-6"
                onClick={() => {
                  // Here would be the logic to assign driver
                  setShowAssignDriverDialog(false);
                }}
              >
                Добавить
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}