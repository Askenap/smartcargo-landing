import { useEffect, useRef } from "react";
import L from "leaflet";

// Route points from China (Khorgos) through Kazakhstan to Kyrgyzstan
const routePoints = [
  {
    name: "Хоргос (граница КНР-РК)",
    coords: [43.2167, 80.3833] as [number, number],
    time: "27.01.2026 10:30",
    deviation: "Без отклонений",
    status: "completed",
  },
  {
    name: "Алматы",
    coords: [43.2220, 76.8512] as [number, number],
    time: "28.01.2026 14:15",
    deviation: "Опоздание 45 мин",
    status: "completed",
  },
  {
    name: "Тараз",
    coords: [42.9000, 71.3667] as [number, number],
    time: "29.01.2026 09:20",
    deviation: "Без отклонений",
    status: "completed",
  },
  {
    name: "Шымкент",
    coords: [42.3000, 69.6000] as [number, number],
    time: "29.01.2026 18:45",
    deviation: "Раннее прибытие 20 мин",
    status: "in_progress",
  },
  {
    name: "Бишкек (граница РК-КР)",
    coords: [42.8746, 74.5698] as [number, number],
    time: "30.01.2026 12:00 (ожидается)",
    deviation: "—",
    status: "pending",
  },
];

export default function TrackingMap() {
  const mapRef = useRef<HTMLDivElement>(null);
  const mapInstanceRef = useRef<L.Map | null>(null);

  useEffect(() => {
    if (!mapRef.current || mapInstanceRef.current) return;

    // Initialize map centered on Kazakhstan
    const map = L.map(mapRef.current).setView([48.0, 68.0], 5);
    mapInstanceRef.current = map;

    // Add satellite tile layer (OpenStreetMap as fallback, with satellite-like styling)
    L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
      attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>',
      maxZoom: 19,
    }).addTo(map);

    // Custom icons for different statuses
    const completedIcon = L.divIcon({
      className: "custom-marker",
      html: `<div style="
        width: 24px;
        height: 24px;
        background-color: #10b981;
        border: 3px solid white;
        border-radius: 50%;
        box-shadow: 0 2px 8px rgba(0,0,0,0.3);
      "></div>`,
      iconSize: [24, 24],
      iconAnchor: [12, 12],
    });

    const inProgressIcon = L.divIcon({
      className: "custom-marker",
      html: `<div style="
        width: 28px;
        height: 28px;
        background-color: #3b82f6;
        border: 3px solid white;
        border-radius: 50%;
        box-shadow: 0 2px 8px rgba(0,0,0,0.3);
        animation: pulse 2s infinite;
      "></div>`,
      iconSize: [28, 28],
      iconAnchor: [14, 14],
    });

    const pendingIcon = L.divIcon({
      className: "custom-marker",
      html: `<div style="
        width: 20px;
        height: 20px;
        background-color: #94a3b8;
        border: 3px solid white;
        border-radius: 50%;
        box-shadow: 0 2px 8px rgba(0,0,0,0.3);
      "></div>`,
      iconSize: [20, 20],
      iconAnchor: [10, 10],
    });

    // Add markers for each point
    routePoints.forEach((point) => {
      let icon = pendingIcon;
      if (point.status === "completed") icon = completedIcon;
      if (point.status === "in_progress") icon = inProgressIcon;

      const marker = L.marker(point.coords, { icon }).addTo(map);

      // Create popup content
      const popupContent = `
        <div style="min-width: 200px; font-family: system-ui, -apple-system, sans-serif;">
          <div style="font-size: 14px; font-weight: 600; color: #0f172a; margin-bottom: 8px;">
            ${point.name}
          </div>
          <div style="font-size: 12px; color: #64748b; margin-bottom: 4px;">
            <strong>Время:</strong> ${point.time}
          </div>
          <div style="font-size: 12px; color: #64748b;">
            <strong>Отклонение:</strong> ${point.deviation}
          </div>
        </div>
      `;

      marker.bindPopup(popupContent);
    });

    // Draw route lines
    // Completed route (green)
    const completedRouteCoords = routePoints
      .filter((p, i) => i < 3) // First 3 points are completed
      .map((p) => p.coords);

    if (completedRouteCoords.length > 1) {
      L.polyline(completedRouteCoords, {
        color: "#10b981",
        weight: 4,
        opacity: 0.8,
      }).addTo(map);
    }

    // In progress route (blue)
    if (routePoints.length > 3) {
      L.polyline([routePoints[2].coords, routePoints[3].coords], {
        color: "#3b82f6",
        weight: 4,
        opacity: 0.8,
        dashArray: "10, 5",
      }).addTo(map);
    }

    // Pending route (gray)
    if (routePoints.length > 4) {
      L.polyline([routePoints[3].coords, routePoints[4].coords], {
        color: "#94a3b8",
        weight: 3,
        opacity: 0.5,
        dashArray: "5, 5",
      }).addTo(map);
    }

    // Fit bounds to show all points
    const bounds = L.latLngBounds(routePoints.map((p) => p.coords));
    map.fitBounds(bounds, { padding: [50, 50] });

    // Cleanup
    return () => {
      if (mapInstanceRef.current) {
        mapInstanceRef.current.remove();
        mapInstanceRef.current = null;
      }
    };
  }, []);

  return (
    <div className="relative w-full h-full">
      <div ref={mapRef} className="w-full h-full rounded-lg" />
      <style>{`
        @keyframes pulse {
          0%, 100% {
            transform: scale(1);
            opacity: 1;
          }
          50% {
            transform: scale(1.1);
            opacity: 0.8;
          }
        }
        .leaflet-popup-content-wrapper {
          border-radius: 8px;
          box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
        }
        .leaflet-popup-tip {
          display: none;
        }
      `}</style>
    </div>
  );
}