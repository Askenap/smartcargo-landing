import { useState } from "react";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { Search, Plus, Truck, Upload, X, FileText, Trash2 } from "lucide-react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogDescription } from "./ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "./ui/select";

type TransportSource = "keden" | "mvd" | "rental";

interface Transport {
  id: string;
  type: string;
  plateNumber: string;
  status: "active" | "inactive";
  source: TransportSource;
  rentalDocuments?: File[];
}

const mockTransports: Transport[] = [
  { id: "1", type: "Грузовик", plateNumber: "KZ 123 AB 01", status: "active", source: "keden" },
  { id: "2", type: "Фургон", plateNumber: "KZ 456 CD 02", status: "active", source: "mvd" },
  { id: "3", type: "Грузовик", plateNumber: "KZ 789 EF 03", status: "active", source: "rental", rentalDocuments: [new File([""], "rental_document_1.pdf")] },
  { id: "4", type: "Прицеп", plateNumber: "KZ 012 GH 04", status: "inactive", source: "keden" },
];

export default function TransportTab() {
  const [searchQuery, setSearchQuery] = useState("");
  const [showAddDialog, setShowAddDialog] = useState(false);
  const [selectedTransport, setSelectedTransport] = useState<Transport | null>(null);
  const [formData, setFormData] = useState({ type: "", plateNumber: "", ownershipType: "owned" as "owned" | "rented" });
  const [rentalDocuments, setRentalDocuments] = useState<File[]>([]);

  const filteredTransports = mockTransports.filter(
    (t) =>
      searchQuery === "" ||
      t.plateNumber.toLowerCase().includes(searchQuery.toLowerCase()) ||
      t.type.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const handleAdd = () => {
    // Валидация для арендованного транспорта
    if (formData.ownershipType === "rented" && rentalDocuments.length === 0) {
      alert("Для арендованного транспорта необходимо загрузить договор аренды");
      return;
    }
    
    setShowAddDialog(false);
    setFormData({ type: "", plateNumber: "", ownershipType: "owned" });
    setRentalDocuments([]);
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files) {
      setRentalDocuments([...rentalDocuments, ...Array.from(e.target.files)]);
    }
  };

  const removeDocument = (index: number) => {
    setRentalDocuments(rentalDocuments.filter((_, i) => i !== index));
  };

  const handleDeleteTransport = (transportId: string) => {
    if (confirm("Вы уверены, что хотите удалить этот транспорт?")) {
      // Логика удаления транспорта
      console.log("Удаление транспорта:", transportId);
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl font-semibold text-slate-900">Транспорт</h2>
          <p className="text-slate-600 mt-1">Управление транспортными средствами</p>
        </div>
        <Button onClick={() => setShowAddDialog(true)} className="bg-sky-500 hover:bg-sky-600">
          <Plus className="w-4 h-4 mr-2" />
          Добавить транспорт
        </Button>
      </div>

      {/* Search */}
      <div className="flex gap-2">
        <Input
          placeholder="Поиск по номеру или типу"
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          className="flex-1"
        />
        <Button variant="default" className="bg-sky-500 hover:bg-sky-600">
          <Search className="w-4 h-4" />
        </Button>
      </div>

      {/* Table (Desktop) */}
      <div className="hidden md:block bg-white rounded-lg border border-slate-200 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-slate-50 border-b border-slate-200">
              <tr>
                <th className="px-4 py-3 text-left text-sm font-medium text-slate-700">Тип</th>
                <th className="px-4 py-3 text-left text-sm font-medium text-slate-700">Госномер</th>
                <th className="px-4 py-3 text-left text-sm font-medium text-slate-700">Источник</th>
                <th className="px-4 py-3 text-left text-sm font-medium text-slate-700">Статус</th>
                <th className="px-4 py-3 text-right text-sm font-medium text-slate-700">Действия</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filteredTransports.map((transport) => (
                <tr key={transport.id} className="hover:bg-slate-50 transition-colors">
                  <td className="px-4 py-4">
                    <div className="flex items-center gap-2">
                      <Truck className="w-4 h-4 text-slate-400" />
                      <span className="text-sm text-slate-900">{transport.type}</span>
                    </div>
                  </td>
                  <td className="px-4 py-4">
                    <span className="text-sm font-medium text-slate-900">{transport.plateNumber}</span>
                  </td>
                  <td className="px-4 py-4">
                    <span className="text-sm text-slate-900">
                      {transport.source === "keden" ? "Keden" : transport.source === "mvd" ? "База МВД" : "По договору аренды"}
                    </span>
                  </td>
                  <td className="px-4 py-4">
                    <span
                      className={`inline-flex items-center px-3 py-1 rounded-full text-xs font-medium ${
                        transport.status === "active"
                          ? "bg-green-50 text-green-700"
                          : "bg-slate-100 text-slate-600"
                      }`}
                    >
                      {transport.status === "active" ? "Активен" : "Неактивен"}
                    </span>
                  </td>
                  <td className="px-4 py-4 text-right">
                    {transport.source === "rental" ? (
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => handleDeleteTransport(transport.id)}
                        className="text-red-600 border-red-300 hover:bg-red-50"
                      >
                        <Trash2 className="w-4 h-4 mr-1" />
                        Удалить
                      </Button>
                    ) : (
                      <span className="text-xs text-slate-400">—</span>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Cards (Mobile) */}
      <div className="md:hidden space-y-4">
        {filteredTransports.map((transport) => (
          <div key={transport.id} className="bg-white rounded-lg border border-slate-200 p-4 shadow-sm">
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-2">
                <Truck className="w-5 h-5 text-sky-600" />
                <span className="font-medium text-slate-900">{transport.plateNumber}</span>
              </div>
              <span
                className={`inline-flex items-center px-2.5 py-1 rounded-full text-xs font-medium ${
                  transport.status === "active"
                    ? "bg-green-50 text-green-700"
                    : "bg-slate-100 text-slate-600"
                }`}
              >
                {transport.status === "active" ? "Активен" : "Неактивен"}
              </span>
            </div>
            
            <div className="space-y-2 text-sm text-slate-600 mb-4">
              <div className="flex justify-between">
                <span className="text-slate-500">Тип:</span>
                <span className="font-medium text-slate-900">{transport.type}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">Источник:</span>
                <span className="font-medium text-slate-900">
                  {transport.source === "keden" ? "Keden" : transport.source === "mvd" ? "База МВД" : "По договору аренды"}
                </span>
              </div>
            </div>

            {transport.source === "rental" && (
              <Button
                variant="outline"
                className="w-full text-red-600 border-red-300 hover:bg-red-50"
                onClick={() => handleDeleteTransport(transport.id)}
              >
                <Trash2 className="w-4 h-4 mr-2" />
                Удалить
              </Button>
            )}
          </div>
        ))}
      </div>

      {/* Add Transport Dialog */}
      <Dialog open={showAddDialog} onOpenChange={setShowAddDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Добавить транспорт</DialogTitle>
            <DialogDescription className="sr-only">
              Форма для добавления нового транспортного средства
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            {/* Ownership Type Toggle */}
            <div>
              <label className="text-sm text-slate-700 mb-2 block">
                Тип владения <span className="text-red-500">*</span>
              </label>
              <div className="flex gap-2 p-1 bg-slate-100 rounded-lg">
                <Button
                  type="button"
                  variant="ghost"
                  className={`flex-1 ${
                    formData.ownershipType === "owned"
                      ? "bg-white text-slate-900 shadow-sm hover:bg-white"
                      : "text-slate-600 hover:text-slate-900 hover:bg-slate-50"
                  }`}
                  onClick={() => {
                    setFormData({ ...formData, ownershipType: "owned" });
                    setRentalDocuments([]);
                  }}
                >
                  Собственный
                </Button>
                <Button
                  type="button"
                  variant="ghost"
                  className={`flex-1 ${
                    formData.ownershipType === "rented"
                      ? "bg-white text-slate-900 shadow-sm hover:bg-white"
                      : "text-slate-600 hover:text-slate-900 hover:bg-slate-50"
                  }`}
                  onClick={() => setFormData({ ...formData, ownershipType: "rented" })}
                >
                  Арендованный
                </Button>
              </div>
            </div>

            <div>
              <label className="text-sm text-slate-700 mb-2 block">
                Тип транспорта <span className="text-red-500">*</span>
              </label>
              <Select value={formData.type} onValueChange={(val) => setFormData({ ...formData, type: val })}>
                <SelectTrigger>
                  <SelectValue placeholder="Выберите тип" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="truck">Грузовик</SelectItem>
                  <SelectItem value="van">Фургон</SelectItem>
                  <SelectItem value="trailer">Прицеп</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <label className="text-sm text-slate-700 mb-2 block">
                Госномер <span className="text-red-500">*</span>
              </label>
              <Input
                placeholder="KZ 000 AA 00"
                value={formData.plateNumber}
                onChange={(e) => setFormData({ ...formData, plateNumber: e.target.value })}
              />
            </div>
            <div>
              <label className="text-sm text-slate-700 mb-2 block">
                Договор аренды{formData.ownershipType === "rented" && <span className="text-red-500"> *</span>}
              </label>
              
              {formData.ownershipType === "rented" && (
                <>
                  {/* File Upload Area */}
                  <div className="border-2 border-dashed border-slate-300 rounded-lg p-4 hover:border-sky-400 transition-colors">
                    <label className="flex flex-col items-center justify-center cursor-pointer">
                      <Upload className="w-8 h-8 text-slate-400 mb-2" />
                      <span className="text-sm text-slate-600 mb-1">Нажмите для выбора файлов</span>
                      <span className="text-xs text-slate-500">или перетащите файлы сюда</span>
                      <input
                        type="file"
                        multiple
                        accept=".pdf,.doc,.docx,.jpg,.jpeg,.png"
                        onChange={handleFileChange}
                        className="hidden"
                      />
                    </label>
                  </div>

                  {/* Uploaded Files List */}
                  {rentalDocuments.length > 0 && (
                    <div className="mt-3 space-y-2">
                      {rentalDocuments.map((doc, index) => (
                        <div
                          key={index}
                          className="flex items-center justify-between p-3 bg-slate-50 rounded-lg border border-slate-200"
                        >
                          <div className="flex items-center gap-2 flex-1 min-w-0">
                            <FileText className="w-4 h-4 text-sky-600 flex-shrink-0" />
                            <span className="text-sm text-slate-900 truncate">{doc.name}</span>
                            <span className="text-xs text-slate-500 flex-shrink-0">
                              {(doc.size / 1024).toFixed(1)} KB
                            </span>
                          </div>
                          <Button
                            size="sm"
                            variant="ghost"
                            onClick={() => removeDocument(index)}
                            className="text-slate-400 hover:text-red-600 hover:bg-red-50 flex-shrink-0"
                          >
                            <X className="w-4 h-4" />
                          </Button>
                        </div>
                      ))}
                    </div>
                  )}
                </>
              )}
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowAddDialog(false)}>
              Отменить
            </Button>
            <Button onClick={handleAdd} className="bg-sky-500 hover:bg-sky-600">
              Сохранить
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Transport Details Dialog */}
      <Dialog open={!!selectedTransport} onOpenChange={(open) => !open && setSelectedTransport(null)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Детали транспорта</DialogTitle>
            <DialogDescription className="sr-only">
              Подробная информация о транспортном средстве
            </DialogDescription>
          </DialogHeader>
          {selectedTransport && (
            <div className="space-y-4">
              <div className="flex items-center justify-between py-3 border-b border-slate-100">
                <span className="text-sm text-slate-500">Тип</span>
                <span className="text-sm text-slate-900">{selectedTransport.type}</span>
              </div>
              <div className="flex items-center justify-between py-3 border-b border-slate-100">
                <span className="text-sm text-slate-500">Госномер</span>
                <span className="text-sm font-medium text-slate-900">{selectedTransport.plateNumber}</span>
              </div>
              <div className="flex items-center justify-between py-3 border-b border-slate-100">
                <span className="text-sm text-slate-500">Статус</span>
                <span
                  className={`px-3 py-1 rounded-full text-xs font-medium ${
                    selectedTransport.status === "active"
                      ? "bg-green-50 text-green-700"
                      : "bg-slate-100 text-slate-600"
                  }`}
                >
                  {selectedTransport.status === "active" ? "Активен" : "Неактивен"}
                </span>
              </div>
              <div className="flex items-center justify-between py-3 border-b border-slate-100">
                <span className="text-sm text-slate-500">Источник</span>
                <span className="text-sm text-slate-900">
                  {selectedTransport.source === "keden" ? "KEDEN" : selectedTransport.source === "mvd" ? "МВД" : "Аренда"}
                </span>
              </div>
              {selectedTransport.source === "rental" && selectedTransport.rentalDocuments && (
                <div className="flex items-center justify-between py-3 border-b border-slate-100">
                  <span className="text-sm text-slate-500">Документы аренды</span>
                  <div className="flex items-center gap-2">
                    {selectedTransport.rentalDocuments.map((doc, index) => (
                      <div key={index} className="flex items-center gap-2">
                        <FileText className="w-4 h-4 text-slate-400" />
                        <span className="text-sm text-slate-900">{doc.name}</span>
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => {
                            const url = URL.createObjectURL(doc);
                            const a = document.createElement("a");
                            a.href = url;
                            a.download = doc.name;
                            a.click();
                            URL.revokeObjectURL(url);
                          }}
                          className="text-sky-600 border-sky-300 hover:bg-sky-50"
                        >
                          Скачать
                        </Button>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}