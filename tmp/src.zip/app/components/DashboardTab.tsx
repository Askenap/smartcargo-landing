import { Card } from "./ui/card";
import { Truck, FileText, Users, Shield, TrendingUp, Clock, QrCode } from "lucide-react";
import { LineChart, Line, ResponsiveContainer } from 'recharts';
import { Button } from "./ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "./ui/dialog";
import { useState } from "react";
import QRCodeDisplay from "./QRCodeDisplay";

export default function DashboardTab() {
  const [showQRDialog, setShowQRDialog] = useState(false);
  
  const activeTransportations = 12; // Number of active transportations
  
  const stats = [
    {
      label: "Активные перевозки",
      value: activeTransportations.toString(),
      icon: Truck,
      color: "bg-blue-50 text-blue-600",
      trend: "+3 за неделю",
      data: [
        { value: 6 },
        { value: 8 },
        { value: 7 },
        { value: 9 },
        { value: 10 },
        { value: 11 },
        { value: 12 },
      ],
      chartColor: "#3b82f6",
    },
    {
      label: "Транспорт",
      value: "8",
      icon: Truck,
      color: "bg-green-50 text-green-600",
      trend: "Все активны",
      data: [
        { value: 8 },
        { value: 8 },
        { value: 7 },
        { value: 8 },
        { value: 8 },
        { value: 8 },
        { value: 8 },
      ],
      chartColor: "#10b981",
    },
    {
      label: "Водители",
      value: "15",
      icon: Users,
      color: "bg-purple-50 text-purple-600",
      trend: "10 на маршруте",
      data: [
        { value: 12 },
        { value: 13 },
        { value: 14 },
        { value: 14 },
        { value: 13 },
        { value: 14 },
        { value: 15 },
      ],
      chartColor: "#a855f7",
    },
    {
      label: "Заявки на проход",
      value: "5",
      icon: Shield,
      color: "bg-yellow-50 text-yellow-600",
      trend: "2 на проверке",
      data: [
        { value: 2 },
        { value: 3 },
        { value: 4 },
        { value: 3 },
        { value: 5 },
        { value: 4 },
        { value: 5 },
      ],
      chartColor: "#eab308",
    },
  ];

  const recentActivities = [
    {
      id: 1,
      type: "transportation",
      title: "Новая перевозка создана",
      description: "TR-2026-000125 • Китай → Казахстан",
      time: "2 часа назад",
    },
    {
      id: 2,
      type: "pass",
      title: "Заявка на проход одобрена",
      description: "КПП Хоргос • VP-2026-000045",
      time: "5 часов назад",
    },
    {
      id: 3,
      type: "document",
      title: "Документ загружен",
      description: "Путевой лист • TR-2026-000124",
      time: "1 день назад",
    },
    {
      id: 4,
      type: "driver",
      title: "Водитель прибыл на КПП",
      description: "Иванов И.И. • КПП Достык",
      time: "1 день назад",
    },
  ];

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h2 className="text-2xl font-semibold text-slate-900">Дашборд</h2>
        <p className="text-slate-600 mt-1">Обзор вашей деятельности</p>
      </div>

      {/* Statistics Cards */}
      <Card className="p-6">
        <div className="space-y-4">
          {stats.map((stat, idx) => (
            <div 
              key={idx} 
              className="flex items-center gap-4 pb-4 border-b border-slate-100 last:border-0 last:pb-0"
            >
              <div className={`w-10 h-10 rounded-lg ${stat.color} flex items-center justify-center flex-shrink-0`}>
                <stat.icon className="w-5 h-5" />
              </div>
              <div className="min-w-[60px]">
                <div className="text-2xl font-semibold text-slate-900">{stat.value}</div>
              </div>
              <div className="flex-1">
                <div className="text-sm font-medium text-slate-900">{stat.label}</div>
                <div className="text-xs text-slate-500 flex items-center gap-1 mt-0.5">
                  <TrendingUp className="w-3 h-3" />
                  {stat.trend}
                </div>
              </div>
              <div className="w-32 h-12 flex-shrink-0">
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart data={stat.data}>
                    <Line 
                      type="monotone" 
                      dataKey="value" 
                      stroke={stat.chartColor} 
                      strokeWidth={2}
                      dot={false}
                    />
                  </LineChart>
                </ResponsiveContainer>
              </div>
            </div>
          ))}
        </div>
      </Card>

      {/* Recent Activity */}
      <Card className="p-6">
        <h3 className="font-semibold text-lg mb-4 text-slate-900">Последняя активность</h3>
        <div className="space-y-4">
          {recentActivities.map((activity) => (
            <div key={activity.id} className="flex items-start gap-4 pb-4 border-b border-slate-100 last:border-0 last:pb-0">
              <div className="w-2 h-2 bg-sky-500 rounded-full mt-2 flex-shrink-0" />
              <div className="flex-1 min-w-0">
                <div className="font-medium text-slate-900">{activity.title}</div>
                <div className="text-sm text-slate-600 mt-1">{activity.description}</div>
              </div>
              <div className="text-xs text-slate-500 flex items-center gap-1 whitespace-nowrap">
                <Clock className="w-3 h-3" />
                {activity.time}
              </div>
            </div>
          ))}
        </div>
      </Card>

      {/* Quick Actions */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card className="p-6 hover:shadow-md transition-shadow cursor-pointer">
          <FileText className="w-8 h-8 text-sky-500 mb-3" />
          <h3 className="font-semibold mb-2">Создать перевозку</h3>
          <p className="text-sm text-slate-600">Начать новую перевозку</p>
        </Card>
        <Card 
          className="p-6 hover:shadow-md transition-shadow cursor-pointer border-2 border-sky-500 bg-sky-50/50 relative"
          onClick={() => setShowQRDialog(true)}
        >
          <div className="absolute top-2 right-2 bg-sky-500 text-white text-xs px-2 py-1 rounded-full font-medium">
            Ключевая функция
          </div>
          <QrCode className="w-8 h-8 text-sky-500 mb-3" />
          <h3 className="font-semibold mb-2 text-sky-900">QR-код перевозки</h3>
          <p className="text-sm text-sky-700">Единый паспорт перевозки (ЦПП)</p>
        </Card>
        <Card className="p-6 hover:shadow-md transition-shadow cursor-pointer">
          <Shield className="w-8 h-8 text-green-500 mb-3" />
          <h3 className="font-semibold mb-2">Подать заявку на проход</h3>
          <p className="text-sm text-slate-600">Запрос верификации для КПП</p>
        </Card>
      </div>

      {/* QR Code Dialog */}
      <Dialog open={showQRDialog} onOpenChange={setShowQRDialog}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>QR-код перевозки</DialogTitle>
            <DialogDescription>
              Единый паспорт перевозки для сканирования контрольными органами
            </DialogDescription>
          </DialogHeader>
          <div className="text-center py-8">
            <p className="text-slate-600">
              У вас {activeTransportations} активных перевозок. Выберите перевозку из раздела "Мои грузы" для отображения QR-кода.
            </p>
            <Button 
              className="mt-4 bg-sky-500 hover:bg-sky-600"
              onClick={() => setShowQRDialog(false)}
            >
              Перейти к грузам
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}