import { useState } from "react";
import { CheckCircle, Circle, ChevronDown, ChevronUp } from "lucide-react";
import { Button } from "./ui/button";

interface TimelineStage {
  id: string;
  title: string;
  subtitle: string;
  status: "completed" | "in-progress" | "pending";
  completedCount: number;
  totalCount: number;
  duration?: string;
  details?: {
    label: string;
    value: string;
    duration?: string;
  }[];
}

const mockStages: TimelineStage[] = [
  {
    id: "1",
    title: "Предварительное декларирование и смежные контроли",
    subtitle: "Ваше прохождение: 3 мин",
    status: "completed",
    completedCount: 3,
    totalCount: 3,
    details: [
      {
        label: "Предварительное информирование",
        value: "Завершена",
        duration: "22.12.2025 - 22.12.2025\n22:14 - 22:15",
      },
      {
        label: "Фито-санитарный контроль",
        value: "Завершена",
        duration: "22.12.2025 - 22.12.2025\n22:15 - 22:16",
      },
      {
        label: "Транспортный контроль",
        value: "Завершена",
        duration: "22.12.2025 - 22.12.2025\n22:16 - 22:17",
      },
    ],
  },
  {
    id: "2",
    title: "Прибытие в КПП и открытие транзита",
    subtitle: "Ваше прохождение: 5 мин",
    status: "in-progress",
    completedCount: 0,
    totalCount: 1,
  },
  {
    id: "3",
    title: "В пути",
    subtitle: "Ваше прохождение: 11 мин",
    status: "pending",
    completedCount: 0,
    totalCount: 1,
  },
  {
    id: "4",
    title: "Завершение транзита и фактический выезд из страны",
    subtitle: "Ваше прохождение: 1 мин",
    status: "pending",
    completedCount: 0,
    totalCount: 1,
  },
];

export default function ProcessTimeline() {
  const [expandedStages, setExpandedStages] = useState<string[]>([]);

  const toggleStage = (stageId: string) => {
    setExpandedStages((prev) =>
      prev.includes(stageId) ? prev.filter((id) => id !== stageId) : [...prev, stageId]
    );
  };

  const getStatusColor = (status: TimelineStage["status"]) => {
    switch (status) {
      case "completed":
        return "border-green-500 bg-green-100";
      case "in-progress":
        return "border-blue-500 bg-blue-100";
      default:
        return "border-slate-300 bg-slate-100";
    }
  };

  const getLineColor = (currentStatus: TimelineStage["status"], nextStatus?: TimelineStage["status"]) => {
    if (currentStatus === "completed" && (nextStatus === "completed" || nextStatus === "in-progress")) {
      return "bg-green-500";
    }
    return "bg-slate-300";
  };

  return (
    <div className="bg-white rounded-lg border border-slate-200 p-6">
      {/* Timeline */}
      <div className="relative flex items-start justify-between mb-8">
        {mockStages.map((stage, index) => (
          <div key={stage.id} className="flex-1 flex flex-col items-center relative">
            {/* Stage Circle */}
            <div
              className={`w-12 h-12 rounded-full border-2 flex items-center justify-center z-10 ${getStatusColor(
                stage.status
              )}`}
            >
              {stage.status === "completed" ? (
                <CheckCircle className="w-6 h-6 text-green-600" />
              ) : stage.status === "in-progress" ? (
                <Circle className="w-6 h-6 text-blue-600 fill-current" />
              ) : (
                <Circle className="w-6 h-6 text-slate-400" />
              )}
            </div>

            {/* Connector Line */}
            {index < mockStages.length - 1 && (
              <div className="absolute left-1/2 top-6 w-full h-0.5 -z-0">
                <div className={`h-full ${getLineColor(stage.status, mockStages[index + 1]?.status)}`} />
              </div>
            )}

            {/* Stage Info */}
            <div className="mt-4 text-center w-full px-2">
              <div className="text-xs font-semibold text-slate-900">
                Завершен {stage.completedCount}/{stage.totalCount}
              </div>
              <div className="text-xs text-slate-700 mt-2 min-h-[40px]">{stage.title}</div>
              <div className="text-[10px] text-slate-500 mt-1">{stage.subtitle}</div>

              {/* Expand Button - only for completed stages with details */}
              {stage.details && stage.status === "completed" && (
                <Button
                  variant="ghost"
                  size="sm"
                  className="mt-2 text-xs text-sky-600 hover:text-sky-700 h-auto p-1"
                  onClick={() => toggleStage(stage.id)}
                >
                  {expandedStages.includes(stage.id) ? (
                    <>
                      <ChevronUp className="w-3 h-3 mr-1" />
                      Скрыть
                    </>
                  ) : (
                    <>
                      <ChevronDown className="w-3 h-3 mr-1" />
                      Показать
                    </>
                  )}
                </Button>
              )}
            </div>
          </div>
        ))}
      </div>

      {/* Expanded Details */}
      {mockStages.map(
        (stage) =>
          expandedStages.includes(stage.id) &&
          stage.details && (
            <div key={`details-${stage.id}`} className="bg-slate-50 rounded-lg p-4 mb-4">
              <h4 className="font-semibold text-sm text-slate-900 mb-3">{stage.title}</h4>
              <div className="text-xs text-slate-500 mb-3">
                Режим среднего времени находится в стадии разработки
              </div>
              {stage.details.map((detail, idx) => (
                <div key={idx} className="bg-white rounded-lg p-4 mb-3">
                  <div className="flex items-start justify-between mb-2">
                    <div>
                      <div className="text-sm font-medium text-slate-900">{detail.label}</div>
                      <div className="text-xs text-slate-600 mt-1 whitespace-pre-line">{detail.value}</div>
                    </div>
                    {detail.duration && (
                      <div className="text-right">
                        <div className="px-3 py-1 bg-green-50 text-green-700 text-xs rounded-full inline-block mb-1">
                          Завершена
                        </div>
                        <div className="text-xs text-slate-500 whitespace-pre-line">{detail.duration}</div>
                      </div>
                    )}
                  </div>
                </div>
              ))}
            </div>
          )
      )}
    </div>
  );
}