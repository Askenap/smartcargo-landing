import { useState } from "react";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { Search, Plus, User, Phone, IdCard, Trash2 } from "lucide-react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogDescription } from "./ui/dialog";
import { Switch } from "./ui/switch";

interface Driver {
  id: string;
  fullName: string;
  licenseNumber: string;
  phone: string;
  status: "active" | "on_route" | "inactive";
}

const mockDrivers: Driver[] = [
  { id: "1", fullName: "Иванов Иван Иванович", licenseNumber: "AA 1234567", phone: "+7 777 123 4567", status: "on_route" },
  { id: "2", fullName: "Петров Петр Петрович", licenseNumber: "AB 2345678", phone: "+7 777 234 5678", status: "active" },
  { id: "3", fullName: "Сидоров Сидор Сидорович", licenseNumber: "AC 3456789", phone: "+7 777 345 6789", status: "on_route" },
  { id: "4", fullName: "Казымов Асан Болатович", licenseNumber: "AD 4567890", phone: "+7 777 456 7890", status: "active" },
];

export default function DriversTab() {
  const [searchQuery, setSearchQuery] = useState("");
  const [showAddDialog, setShowAddDialog] = useState(false);
  const [selectedDriver, setSelectedDriver] = useState<Driver | null>(null);
  const [formData, setFormData] = useState({ fullName: "", licenseNumber: "", phone: "", iin: "", kazEtaNumber: "" });
  const [isResident, setIsResident] = useState(true);

  const filteredDrivers = mockDrivers.filter(
    (d) =>
      searchQuery === "" ||
      d.fullName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      d.licenseNumber.toLowerCase().includes(searchQuery.toLowerCase()) ||
      d.phone.includes(searchQuery)
  );

  const handleAdd = () => {
    setShowAddDialog(false);
    setFormData({ fullName: "", licenseNumber: "", phone: "", iin: "", kazEtaNumber: "" });
  };

  const handleDeleteDriver = (driverId: string) => {
    if (confirm("Вы уверены, что хотите удалить этого водителя?")) {
      // Логика удаления водителя
      console.log("Удаление водителя:", driverId);
    }
  };

  const statusConfig = {
    active: { label: "Доступен", color: "bg-green-50 text-green-700" },
    on_route: { label: "На маршруте", color: "bg-blue-50 text-blue-700" },
    inactive: { label: "Неактивен", color: "bg-slate-100 text-slate-600" },
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl font-semibold text-slate-900">Водители</h2>
          <p className="text-slate-600 mt-1">Управление водителями</p>
        </div>
        <Button onClick={() => setShowAddDialog(true)} className="bg-sky-500 hover:bg-sky-600">
          <Plus className="w-4 h-4 mr-2" />
          Добавить водителя
        </Button>
      </div>

      {/* Search */}
      <div className="flex gap-2">
        <Input
          placeholder="Поиск по ФИО, ID или телефону"
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          className="flex-1"
        />
        <Button variant="default" className="bg-sky-500 hover:bg-sky-600">
          <Search className="w-4 h-4" />
        </Button>
      </div>

      {/* Table (Desktop) */}
      <div className="hidden md:block bg-white rounded-lg border border-slate-200 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-slate-50 border-b border-slate-200">
              <tr>
                <th className="px-4 py-3 text-left text-sm font-medium text-slate-700">ФИО</th>
                <th className="px-4 py-3 text-left text-sm font-medium text-slate-700">Водительское удостоверение</th>
                <th className="px-4 py-3 text-left text-sm font-medium text-slate-700">Телефон</th>
                <th className="px-4 py-3 text-left text-sm font-medium text-slate-700">Статус</th>
                <th className="px-4 py-3 text-right text-sm font-medium text-slate-700">Действия</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filteredDrivers.map((driver) => {
                const status = statusConfig[driver.status];
                return (
                  <tr key={driver.id} className="hover:bg-slate-50 transition-colors">
                    <td className="px-4 py-4">
                      <div className="flex items-center gap-2">
                        <User className="w-4 h-4 text-slate-400" />
                        <span className="text-sm text-slate-900">{driver.fullName}</span>
                      </div>
                    </td>
                    <td className="px-4 py-4">
                      <span className="text-sm text-slate-600">{driver.licenseNumber}</span>
                    </td>
                    <td className="px-4 py-4">
                      <span className="text-sm text-slate-600">{driver.phone}</span>
                    </td>
                    <td className="px-4 py-4">
                      <span className={`inline-flex items-center px-3 py-1 rounded-full text-xs font-medium ${status.color}`}>
                        {status.label}
                      </span>
                    </td>
                    <td className="px-4 py-4 text-right">
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => handleDeleteDriver(driver.id)}
                        className="text-red-600 border-red-300 hover:bg-red-50"
                      >
                        <Trash2 className="w-4 h-4 mr-1" />
                        Удалить
                      </Button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* Cards (Mobile) */}
      <div className="md:hidden space-y-4">
        {filteredDrivers.map((driver) => {
          const status = statusConfig[driver.status];
          return (
            <div key={driver.id} className="bg-white rounded-lg border border-slate-200 p-4 shadow-sm">
              <div className="flex items-center justify-between mb-3">
                <div className="flex items-center gap-2">
                  <User className="w-5 h-5 text-sky-600" />
                  <span className="font-medium text-slate-900">{driver.fullName}</span>
                </div>
                <span className={`inline-flex items-center px-2.5 py-1 rounded-full text-xs font-medium ${status.color}`}>
                  {status.label}
                </span>
              </div>
              
              <div className="space-y-2 text-sm text-slate-600 mb-4">
                <div className="flex justify-between">
                  <span className="text-slate-500">В/У:</span>
                  <span className="font-medium text-slate-900">{driver.licenseNumber}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">Телефон:</span>
                  <span className="font-medium text-slate-900">{driver.phone}</span>
                </div>
              </div>

              <div className="flex gap-2">
                <Button
                  variant="outline"
                  className="flex-1 text-red-600 border-red-300 hover:bg-red-50"
                  onClick={() => handleDeleteDriver(driver.id)}
                >
                  <Trash2 className="w-4 h-4 mr-2" />
                  Удалить
                </Button>
                <Button
                  variant="outline"
                  className="flex-1"
                  onClick={() => setSelectedDriver(driver)}
                >
                  Подробнее
                </Button>
              </div>
            </div>
          );
        })}
      </div>

      {/* Add Driver Dialog */}
      <Dialog open={showAddDialog} onOpenChange={setShowAddDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Добавить водителя</DialogTitle>
            <DialogDescription className="sr-only">
              Форма для добавления нового водителя
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            {/* Resident/Non-resident Switch */}
            <div className="flex items-center justify-between p-3 bg-slate-50 rounded-lg">
              <div className="flex items-center gap-3">
                <span className={`text-sm font-medium transition-colors ${!isResident ? 'text-slate-400' : 'text-slate-900'}`}>
                  Резидент
                </span>
                <Switch
                  checked={!isResident}
                  onCheckedChange={(checked) => setIsResident(!checked)}
                />
                <span className={`text-sm font-medium transition-colors ${isResident ? 'text-slate-400' : 'text-slate-900'}`}>
                  Нерезидент
                </span>
              </div>
            </div>

            {/* Conditional Fields based on residency */}
            {isResident ? (
              <>
                {/* Resident Fields */}
                <div>
                  <label className="text-sm text-slate-700 mb-2 block">
                    ФИО <span className="text-red-500">*</span>
                  </label>
                  <Input
                    placeholder="Иванов Иван Иванович"
                    value={formData.fullName}
                    onChange={(e) => setFormData({ ...formData, fullName: e.target.value })}
                  />
                </div>
                <div>
                  <label className="text-sm text-slate-700 mb-2 block">
                    Номер водительского удостоверения <span className="text-red-500">*</span>
                  </label>
                  <Input
                    placeholder="AA 1234567"
                    value={formData.licenseNumber}
                    onChange={(e) => setFormData({ ...formData, licenseNumber: e.target.value })}
                  />
                </div>
                <div>
                  <label className="text-sm text-slate-700 mb-2 block">
                    ИИН <span className="text-red-500">*</span>
                  </label>
                  <Input
                    placeholder="123456789012"
                    value={formData.iin}
                    onChange={(e) => {
                      const value = e.target.value.replace(/\D/g, '').slice(0, 12);
                      setFormData({ ...formData, iin: value });
                    }}
                    maxLength={12}
                  />
                </div>
                <div>
                  <label className="text-sm text-slate-700 mb-2 block">
                    Телефон <span className="text-red-500">*</span>
                  </label>
                  <Input
                    placeholder="+7 777 000 0000"
                    value={formData.phone}
                    onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                  />
                </div>
              </>
            ) : (
              <>
                {/* Non-resident Field */}
                <div>
                  <label className="text-sm text-slate-700 mb-2 block">
                    Номер KazETA <span className="text-red-500">*</span>
                  </label>
                  <Input
                    placeholder="KZETA-123456789"
                    value={formData.kazEtaNumber}
                    onChange={(e) => setFormData({ ...formData, kazEtaNumber: e.target.value })}
                  />
                </div>
              </>
            )}
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowAddDialog(false)}>
              Отменить
            </Button>
            <Button onClick={handleAdd} className="bg-sky-500 hover:bg-sky-600">
              Сохранить
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Driver Details Dialog */}
      <Dialog open={!!selectedDriver} onOpenChange={(open) => !open && setSelectedDriver(null)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Детали водителя</DialogTitle>
            <DialogDescription className="sr-only">
              Подробная информация о водителе
            </DialogDescription>
          </DialogHeader>
          {selectedDriver && (
            <div className="space-y-4">
              <div className="flex items-center justify-between py-3 border-b border-slate-100">
                <span className="text-sm text-slate-500 flex items-center gap-2">
                  <User className="w-4 h-4" />
                  ФИО
                </span>
                <span className="text-sm text-slate-900">{selectedDriver.fullName}</span>
              </div>
              <div className="flex items-center justify-between py-3 border-b border-slate-100">
                <span className="text-sm text-slate-500 flex items-center gap-2">
                  <IdCard className="w-4 h-4" />
                  ID
                </span>
                <span className="text-sm text-slate-900">{selectedDriver.licenseNumber}</span>
              </div>
              <div className="flex items-center justify-between py-3 border-b border-slate-100">
                <span className="text-sm text-slate-500 flex items-center gap-2">
                  <Phone className="w-4 h-4" />
                  Телефон
                </span>
                <span className="text-sm text-slate-900">{selectedDriver.phone}</span>
              </div>
              <div className="flex items-center justify-between py-3 border-b border-slate-100">
                <span className="text-sm text-slate-500">Статус</span>
                <span
                  className={`px-3 py-1 rounded-full text-xs font-medium ${
                    statusConfig[selectedDriver.status].color
                  }`}
                >
                  {statusConfig[selectedDriver.status].label}
                </span>
              </div>
              
              {/* Documents Section */}
              <div className="mt-6">
                <h4 className="font-medium text-slate-900 mb-3">Документы</h4>
                <div className="space-y-2">
                  <div className="p-3 bg-slate-50 rounded-lg text-sm text-slate-600">
                    Водительское удостоверение
                  </div>
                  <div className="p-3 bg-slate-50 rounded-lg text-sm text-slate-600">
                    Медицинская справка
                  </div>
                </div>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}