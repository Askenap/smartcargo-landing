import { useState } from "react";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { Search, Upload, FileText, Check, X, Clock } from "lucide-react";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "./ui/select";

interface Document {
  id: string;
  name: string;
  type: string;
  relatedTransportation: string;
  date: string;
  status: "approved" | "pending" | "rejected";
}

const mockDocuments: Document[] = [
  {
    id: "1",
    name: "Путевой лист",
    type: "Транспортный документ",
    relatedTransportation: "TR-2026-000123",
    date: "2026-02-15",
    status: "approved",
  },
  {
    id: "2",
    name: "Товарно-транспортная накладная",
    type: "Транспортный документ",
    relatedTransportation: "TR-2026-000124",
    date: "2026-02-16",
    status: "pending",
  },
  {
    id: "3",
    name: "Таможенная декларация",
    type: "Таможенный документ",
    relatedTransportation: "TR-2026-000125",
    date: "2026-02-17",
    status: "approved",
  },
  {
    id: "4",
    name: "Сертификат соответствия",
    type: "Сертификат",
    relatedTransportation: "TR-2026-000123",
    date: "2026-02-14",
    status: "rejected",
  },
];

export default function DocumentsTab() {
  const [searchQuery, setSearchQuery] = useState("");
  const [statusFilter, setStatusFilter] = useState<string>("all");

  const filteredDocuments = mockDocuments.filter((doc) => {
    const matchesSearch =
      searchQuery === "" ||
      doc.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      doc.relatedTransportation.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesStatus = statusFilter === "all" || doc.status === statusFilter;
    return matchesSearch && matchesStatus;
  });

  const statusConfig = {
    approved: { label: "Утвержден", color: "bg-green-50 text-green-700", icon: Check },
    pending: { label: "На проверке", color: "bg-yellow-50 text-yellow-700", icon: Clock },
    rejected: { label: "Отклонен", color: "bg-red-50 text-red-700", icon: X },
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl font-semibold text-slate-900">Документы</h2>
          <p className="text-slate-600 mt-1">Управление документами перевозок</p>
        </div>
        <Button className="bg-sky-500 hover:bg-sky-600">
          <Upload className="w-4 h-4 mr-2" />
          Загрузить документ
        </Button>
      </div>

      {/* Filters */}
      <div className="flex flex-col sm:flex-row gap-3">
        <Input
          placeholder="Поиск по названию или номеру перевозки"
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          className="flex-1"
        />
        <Select value={statusFilter} onValueChange={setStatusFilter}>
          <SelectTrigger className="w-full sm:w-48">
            <SelectValue placeholder="Все статусы" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">Все статусы</SelectItem>
            <SelectItem value="approved">Утвержден</SelectItem>
            <SelectItem value="pending">На проверке</SelectItem>
            <SelectItem value="rejected">Отклонен</SelectItem>
          </SelectContent>
        </Select>
        <Button variant="default" className="bg-sky-500 hover:bg-sky-600">
          <Search className="w-4 h-4" />
        </Button>
      </div>

      {/* Table (Desktop) */}
      <div className="hidden md:block bg-white rounded-lg border border-slate-200 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-slate-50 border-b border-slate-200">
              <tr>
                <th className="px-4 py-3 text-left text-sm font-medium text-slate-700">Название</th>
                <th className="px-4 py-3 text-left text-sm font-medium text-slate-700">Тип</th>
                <th className="px-4 py-3 text-left text-sm font-medium text-slate-700">Связанная перевозка</th>
                <th className="px-4 py-3 text-left text-sm font-medium text-slate-700">Дата</th>
                <th className="px-4 py-3 text-left text-sm font-medium text-slate-700">Статус</th>
                <th className="px-4 py-3 text-right text-sm font-medium text-slate-700">Действия</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filteredDocuments.map((doc) => {
                const status = statusConfig[doc.status];
                const StatusIcon = status.icon;
                return (
                  <tr key={doc.id} className="hover:bg-slate-50 transition-colors">
                    <td className="px-4 py-4">
                      <div className="flex items-center gap-2">
                        <FileText className="w-4 h-4 text-slate-400" />
                        <span className="text-sm text-slate-900">{doc.name}</span>
                      </div>
                    </td>
                    <td className="px-4 py-4">
                      <span className="text-sm text-slate-600">{doc.type}</span>
                    </td>
                    <td className="px-4 py-4">
                      <span className="text-sm text-sky-600 hover:text-sky-700 cursor-pointer font-medium">
                        {doc.relatedTransportation}
                      </span>
                    </td>
                    <td className="px-4 py-4">
                      <span className="text-sm text-slate-600">
                        {new Date(doc.date).toLocaleDateString("ru-RU")}
                      </span>
                    </td>
                    <td className="px-4 py-4">
                      <span className={`inline-flex items-center gap-1 px-3 py-1 rounded-full text-xs font-medium ${status.color}`}>
                        <StatusIcon className="w-3 h-3" />
                        {status.label}
                      </span>
                    </td>
                    <td className="px-4 py-4 text-right">
                      <Button size="sm" variant="outline" className="text-sky-600 border-sky-300 hover:bg-sky-50">
                        Просмотр
                      </Button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* Cards (Mobile) */}
      <div className="md:hidden space-y-4">
        {filteredDocuments.map((doc) => {
          const status = statusConfig[doc.status];
          const StatusIcon = status.icon;
          return (
            <div key={doc.id} className="bg-white rounded-lg border border-slate-200 p-4 shadow-sm">
              <div className="flex items-center justify-between mb-3">
                <div className="flex items-center gap-2">
                  <FileText className="w-5 h-5 text-sky-600" />
                  <span className="font-medium text-slate-900">{doc.name}</span>
                </div>
                <span className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-medium ${status.color}`}>
                  <StatusIcon className="w-3 h-3" />
                  {status.label}
                </span>
              </div>
              
              <div className="space-y-2 text-sm text-slate-600 mb-4">
                <div className="flex justify-between">
                  <span className="text-slate-500">Тип:</span>
                  <span className="font-medium text-slate-900">{doc.type}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">Перевозка:</span>
                  <span className="font-medium text-sky-600">{doc.relatedTransportation}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">Дата:</span>
                  <span className="font-medium text-slate-900">{new Date(doc.date).toLocaleDateString("ru-RU")}</span>
                </div>
              </div>

              <Button variant="outline" className="w-full text-sky-600 border-sky-300 hover:bg-sky-50">
                Просмотр
              </Button>
            </div>
          );
        })}
      </div>

      {/* Stats */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="bg-green-50 border border-green-200 rounded-lg p-4">
          <div className="flex items-center justify-between">
            <div>
              <div className="text-sm text-green-800 mb-1">Утверждено</div>
              <div className="text-2xl font-semibold text-green-900">
                {mockDocuments.filter((d) => d.status === "approved").length}
              </div>
            </div>
            <Check className="w-8 h-8 text-green-600" />
          </div>
        </div>
        <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4">
          <div className="flex items-center justify-between">
            <div>
              <div className="text-sm text-yellow-800 mb-1">На проверке</div>
              <div className="text-2xl font-semibold text-yellow-900">
                {mockDocuments.filter((d) => d.status === "pending").length}
              </div>
            </div>
            <Clock className="w-8 h-8 text-yellow-600" />
          </div>
        </div>
        <div className="bg-red-50 border border-red-200 rounded-lg p-4">
          <div className="flex items-center justify-between">
            <div>
              <div className="text-sm text-red-800 mb-1">Отклонено</div>
              <div className="text-2xl font-semibold text-red-900">
                {mockDocuments.filter((d) => d.status === "rejected").length}
              </div>
            </div>
            <X className="w-8 h-8 text-red-600" />
          </div>
        </div>
      </div>
    </div>
  );
}
