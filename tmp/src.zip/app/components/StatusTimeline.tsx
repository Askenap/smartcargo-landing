import { CheckCircle, Clock, XCircle, AlertCircle, Circle } from "lucide-react";
import { Card } from "./ui/card";

interface StatusEvent {
  id: string;
  label: string;
  status: "completed" | "in_progress" | "pending" | "failed";
  timestamp?: string;
  source?: string;
  role?: string;
  description?: string;
}

interface StatusTimelineProps {
  scenario: "third-countries" | "eaeu" | "domestic";
  tripId: string;
}

export default function StatusTimeline({ scenario, tripId }: StatusTimelineProps) {
  // Different statuses based on scenario
  const getStatuses = (): StatusEvent[] => {
    if (scenario === "third-countries") {
      return [
        {
          id: "1",
          label: "ПИ подан",
          status: "completed",
          timestamp: "2026-02-15 10:30",
          source: "КЕДЕН",
          role: "Декларант",
        },
        {
          id: "2",
          label: "ПИ прибыл",
          status: "completed",
          timestamp: "2026-02-15 14:20",
          source: "КЕДЕН",
          role: "Таможенный инспектор",
        },
        {
          id: "3",
          label: "ПИ подтвержден",
          status: "completed",
          timestamp: "2026-02-15 14:45",
          source: "КЕДЕН",
          role: "Таможенный инспектор",
        },
        {
          id: "4",
          label: "Допуск на пост (КНБ)",
          status: "completed",
          timestamp: "2026-02-15 15:00",
          source: "Smart Cargo",
          role: "ПС КНБ",
          description: "Проверка пассажиров: 2 человека"
        },
        {
          id: "5",
          label: "Рентген/ИДК",
          status: "completed",
          timestamp: "2026-02-15 15:30",
          source: "КЕДЕН",
          role: "Оператор рентгена",
        },
        {
          id: "6",
          label: "Весогабаритный контроль",
          status: "completed",
          timestamp: "2026-02-15 16:00",
          source: "КЕДЕН",
          role: "Инспектор",
        },
        {
          id: "7",
          label: "ТД подана",
          status: "in_progress",
          timestamp: "2026-02-15 16:30",
          source: "КЕДЕН",
          role: "Декларант",
        },
        {
          id: "8",
          label: "Выпуск с СВХ",
          status: "pending",
          source: "Smart Cargo",
          role: "Контроль СВХ",
        },
        {
          id: "9",
          label: "ТД выпущена",
          status: "pending",
          source: "КЕДЕН",
          role: "Таможенный инспектор",
        },
        {
          id: "10",
          label: "Финальный выпуск/выезд",
          status: "pending",
          source: "Smart Cargo",
          role: "КПП",
        },
      ];
    } else if (scenario === "eaeu") {
      return [
        {
          id: "1",
          label: "Создание перевозки",
          status: "completed",
          timestamp: "2026-02-15 09:00",
          source: "Smart Cargo",
          role: "Перевозчик",
        },
        {
          id: "2",
          label: "СНТ проверка (через ЭСФ)",
          status: "completed",
          timestamp: "2026-02-15 09:15",
          source: "ЭСФ",
          role: "Автоматическая проверка",
          description: "СНТ найден и соответствует"
        },
        {
          id: "3",
          label: "Граница ЕАЭС: КГД НДС/СНТ",
          status: "in_progress",
          timestamp: "2026-02-15 14:00",
          source: "Smart Cargo",
          role: "КГД НДС/СНТ",
        },
        {
          id: "4",
          label: "Выпуск (упрощенный)",
          status: "pending",
          source: "Smart Cargo",
          role: "КПП",
        },
      ];
    } else {
      // domestic
      return [
        {
          id: "1",
          label: "Начало перевозки",
          status: "completed",
          timestamp: "2026-02-15 08:00",
          source: "Smart Cargo",
          role: "Водитель",
        },
        {
          id: "2",
          label: "Проверка на трассе (пост 1)",
          status: "completed",
          timestamp: "2026-02-15 12:30",
          source: "Smart Cargo",
          role: "Транспортный контроль",
          description: "Проверка документов, взвешивание"
        },
        {
          id: "3",
          label: "Мобильный пост (пост 2)",
          status: "in_progress",
          timestamp: "2026-02-15 16:00",
          source: "Smart Cargo",
          role: "Транспортный контроль",
        },
        {
          id: "4",
          label: "Прибытие в пункт назначения",
          status: "pending",
          source: "Smart Cargo",
          role: "Водитель",
        },
      ];
    }
  };

  const statuses = getStatuses();

  const getStatusIcon = (status: StatusEvent["status"]) => {
    switch (status) {
      case "completed":
        return <CheckCircle className="w-5 h-5 text-green-600" />;
      case "in_progress":
        return <Clock className="w-5 h-5 text-blue-600" />;
      case "failed":
        return <XCircle className="w-5 h-5 text-red-600" />;
      default:
        return <Circle className="w-5 h-5 text-slate-300" />;
    }
  };

  const getStatusColor = (status: StatusEvent["status"]) => {
    switch (status) {
      case "completed":
        return "bg-green-50 border-green-200";
      case "in_progress":
        return "bg-blue-50 border-blue-200";
      case "failed":
        return "bg-red-50 border-red-200";
      default:
        return "bg-slate-50 border-slate-200";
    }
  };

  return (
    <Card className="p-6">
      <div className="flex items-center justify-between mb-6">
        <h3 className="font-semibold text-lg text-slate-900">Статусы грузоперевозки</h3>
        <div className="text-sm text-slate-600">
          Сценарий: <span className="font-medium">
            {scenario === "third-countries" ? "Из третьих стран" : scenario === "eaeu" ? "ЕАЭС" : "Внутри РК"}
          </span>
        </div>
      </div>

      <div className="relative">
        {statuses.map((event, index) => (
          <div key={event.id} className="flex gap-4 mb-6 last:mb-0">
            {/* Icon & Line */}
            <div className="flex flex-col items-center">
              <div className="relative z-10">
                {getStatusIcon(event.status)}
              </div>
              {index < statuses.length - 1 && (
                <div className={`w-0.5 h-full min-h-[60px] ${
                  event.status === "completed" ? "bg-green-300" : "bg-slate-200"
                }`} />
              )}
            </div>

            {/* Content */}
            <div className="flex-1 pb-6">
              <div className={`border rounded-lg p-4 ${getStatusColor(event.status)}`}>
                <div className="flex items-start justify-between mb-2">
                  <div className="font-medium text-slate-900">{event.label}</div>
                  {event.timestamp && (
                    <div className="text-xs text-slate-600 whitespace-nowrap ml-4">
                      {event.timestamp}
                    </div>
                  )}
                </div>

                <div className="space-y-1 text-sm text-slate-600">
                  {event.source && (
                    <div className="flex items-center gap-2">
                      <span className="text-xs font-medium">Источник:</span>
                      <span className={`px-2 py-0.5 rounded text-xs ${
                        event.source === "КЕДЕН" ? "bg-purple-100 text-purple-700" :
                        event.source === "Smart Cargo" ? "bg-sky-100 text-sky-700" :
                        "bg-amber-100 text-amber-700"
                      }`}>
                        {event.source}
                      </span>
                    </div>
                  )}
                  
                  {event.role && (
                    <div className="text-xs text-slate-500">
                      Роль: {event.role}
                    </div>
                  )}

                  {event.description && (
                    <div className="text-xs text-slate-600 mt-2 italic">
                      {event.description}
                    </div>
                  )}
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Legend */}
      <div className="border-t border-slate-200 pt-4 mt-4">
        <div className="text-xs text-slate-600 mb-2">Статусы:</div>
        <div className="flex flex-wrap gap-4 text-xs">
          <div className="flex items-center gap-1">
            <CheckCircle className="w-4 h-4 text-green-600" />
            <span>Завершено</span>
          </div>
          <div className="flex items-center gap-1">
            <Clock className="w-4 h-4 text-blue-600" />
            <span>В процессе</span>
          </div>
          <div className="flex items-center gap-1">
            <Circle className="w-4 h-4 text-slate-300" />
            <span>Ожидание</span>
          </div>
          <div className="flex items-center gap-1">
            <XCircle className="w-4 h-4 text-red-600" />
            <span>Отклонено</span>
          </div>
        </div>
      </div>
    </Card>
  );
}
