import { useState } from "react";
import { Card } from "./ui/card";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "./ui/select";
import { Search, FileText, Camera, MapPin, User, AlertCircle, Flag } from "lucide-react";

interface AuditEvent {
  eventId: string;
  tripId: string;
  timestamp: string;
  eventType: string;
  source: "SC" | "KEDEN" | "CargoRuqsat" | "ESF" | "KazToll";
  user?: string;
  role?: string;
  authority?: string;
  location?: string;
  comment?: string;
  attachments?: string[];
}

interface Complaint {
  status: "pending" | "accepted" | "rejected";
  comment?: string;
  submittedAt: string;
}

const mockEvents: AuditEvent[] = [
  {
    eventId: "EVT-001",
    tripId: "TR-2026-000125",
    timestamp: "2026-02-17 16:30:00",
    eventType: "QR_SCANNED",
    source: "SC",
    user: "Иванов И.И.",
    role: "ПС КНБ",
    authority: "КНБ РК, пост Хоргос",
    location: "КПП Хоргос",
    comment: "Проверка пассажиров: 2 человека",
  },
  {
    eventId: "EVT-008",
    tripId: "TR-2026-000125",
    timestamp: "2026-02-17 14:15:00",
    eventType: "QR_SCANNED",
    source: "SC",
    user: "Смирнов А.В.",
    role: "Таможенный инспектор",
    authority: "КГД РК, пост Жетысу",
    location: "КПП Жетысу",
    comment: "Инспекция груза при въезде",
  },
  {
    eventId: "EVT-009",
    tripId: "TR-2026-000125",
    timestamp: "2026-02-17 12:45:00",
    eventType: "QR_SCANNED",
    source: "SC",
    user: "Нурланов Е.К.",
    role: "Инспектор транспортного контроля",
    authority: "Комитет транспортного контроля МИР РК",
    location: "Трасса А-2, км 85",
    comment: "Плановая проверка документов и груза",
  },
  {
    eventId: "EVT-010",
    tripId: "TR-2026-000125",
    timestamp: "2026-02-17 10:20:00",
    eventType: "QR_SCANNED",
    source: "SC",
    user: "Абдуллаев М.Р.",
    role: "Инспектор весогабаритного контроля",
    authority: "КГД РК, передвижной пост",
    location: "Пост весогабаритного контроля, трасса А-2",
    comment: "Проверка весогабаритных параметров",
  },
  {
    eventId: "EVT-011",
    tripId: "TR-2026-000125",
    timestamp: "2026-02-16 18:30:00",
    eventType: "QR_SCANNED",
    source: "SC",
    user: "Токаева Г.Ж.",
    role: "ПС КНБ",
    authority: "КНБ РК, пограничный пост Достык",
    location: "КПП Достык",
    comment: "Первичная проверка при въезде в РК",
  },
];

export default function AuditTrail({ tripId }: { tripId: string }) {
  const [searchQuery, setSearchQuery] = useState("");
  const [sourceFilter, setSourceFilter] = useState<string>("all");
  const [eventTypeFilter, setEventTypeFilter] = useState<string>("all");
  const [complaints, setComplaints] = useState<Record<string, Complaint>>({});

  const handleComplaint = (eventId: string) => {
    const now = new Date().toLocaleString("ru-RU");
    setComplaints({
      ...complaints,
      [eventId]: {
        status: "pending",
        comment: "Жалоба находится на рассмотрении",
        submittedAt: now,
      },
    });
  };

  const complaintStatusConfig = {
    pending: { label: "На рассмотрении", color: "bg-amber-50 text-amber-700 border-amber-200" },
    accepted: { label: "Принята", color: "bg-green-50 text-green-700 border-green-200" },
    rejected: { label: "Отклонена", color: "bg-red-50 text-red-700 border-red-200" },
  };

  const filteredEvents = mockEvents.filter((event) => {
    const matchesSearch =
      searchQuery === "" ||
      event.eventType.toLowerCase().includes(searchQuery.toLowerCase()) ||
      event.comment?.toLowerCase().includes(searchQuery.toLowerCase()) ||
      event.user?.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesSource = sourceFilter === "all" || event.source === sourceFilter;
    const matchesEventType = eventTypeFilter === "all" || event.eventType === eventTypeFilter;
    return matchesSearch && matchesSource && matchesEventType;
  });

  const sourceColors = {
    SC: "bg-sky-100 text-sky-700",
    KEDEN: "bg-purple-100 text-purple-700",
    CargoRuqsat: "bg-green-100 text-green-700",
    ESF: "bg-amber-100 text-amber-700",
    KazToll: "bg-blue-100 text-blue-700",
  };

  const eventTypeLabels: Record<string, string> = {
    QR_SCANNED: "QR отсканирован",
    ARRIVAL_MARKED: "Прибытие отмечено",
    STATUS_SYNCED_FROM_KEDEN: "Синхронизация из КЕДЕН",
    TD_DECISION: "Решение по ТД",
    SVH_RELEASED: "Выпуск с СВХ",
    INSPECTION_CREATED: "Проверка создана",
    NONCONFORMITY_NOTED: "Несоответствие зафиксировано",
    COMPLAINT_SUBMITTED: "Жалоба подана",
  };

  return (
    <div className="space-y-6">
      <div>
        <h3 className="font-semibold text-lg mb-4 text-slate-900">Журнал действий</h3>
        <p className="text-sm text-slate-600 mb-4">
          История сканирований QR-кода ЦПП различными контролирующими органами
        </p>
      </div>

      {/* Filters */}
      <div className="flex flex-col sm:flex-row gap-3">
        <Input
          placeholder="Поиск по событию, комментарию, пользователю"
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          className="flex-1"
        />
        <Select value={sourceFilter} onValueChange={setSourceFilter}>
          <SelectTrigger className="w-full sm:w-40">
            <SelectValue placeholder="Все источники" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">Все источники</SelectItem>
            <SelectItem value="SC">Smart Cargo</SelectItem>
            <SelectItem value="KEDEN">КЕДЕН</SelectItem>
            <SelectItem value="CargoRuqsat">Cargo Ruqsat</SelectItem>
            <SelectItem value="ESF">ЭСФ</SelectItem>
            <SelectItem value="KazToll">KazToll</SelectItem>
          </SelectContent>
        </Select>
        <Button variant="default" className="bg-sky-500 hover:bg-sky-600">
          <Search className="w-4 h-4" />
        </Button>
      </div>

      {/* Events Timeline */}
      <div className="space-y-4">
        {filteredEvents.map((event) => (
          <Card key={event.eventId} className="p-4 hover:shadow-md transition-shadow">
            <div className="flex items-start justify-between mb-3">
              <div className="flex-1">
                <div className="flex items-center gap-2 mb-2">
                  <span className="font-medium text-slate-900">
                    {eventTypeLabels[event.eventType] || event.eventType}
                  </span>
                  <span className={`px-2 py-0.5 rounded text-xs font-medium ${sourceColors[event.source]}`}>
                    {event.source}
                  </span>
                  {event.eventType === "NONCONFORMITY_NOTED" && (
                    <AlertCircle className="w-4 h-4 text-red-500" />
                  )}
                </div>
                <div className="text-xs text-slate-500">ID: {event.eventId}</div>
              </div>
              <div className="text-sm text-slate-600 whitespace-nowrap ml-4">
                {event.timestamp}
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-sm text-slate-600 mb-2">
              {event.user && (
                <div className="flex items-center gap-1">
                  <User className="w-3 h-3" />
                  <span className="text-xs">Пользователь:</span>
                  <span className="text-xs font-medium">{event.user}</span>
                </div>
              )}
              {event.role && (
                <div className="text-xs">
                  Роль: <span className="font-medium">{event.role}</span>
                </div>
              )}
              {event.authority && (
                <div className="text-xs">
                  Орган: <span className="font-medium">{event.authority}</span>
                </div>
              )}
              {event.location && (
                <div className="flex items-center gap-1">
                  <MapPin className="w-3 h-3" />
                  <span className="text-xs">{event.location}</span>
                </div>
              )}
            </div>

            {event.comment && (
              <div className="text-sm text-slate-700 bg-slate-50 rounded p-2 mb-2">
                {event.comment}
              </div>
            )}

            {event.attachments && event.attachments.length > 0 && (
              <div className="flex flex-wrap gap-2 mb-2">
                {event.attachments.map((file, idx) => (
                  <div
                    key={idx}
                    className="flex items-center gap-1 text-xs bg-sky-50 text-sky-700 px-2 py-1 rounded"
                  >
                    {file.endsWith(".jpg") || file.endsWith(".png") ? (
                      <Camera className="w-3 h-3" />
                    ) : (
                      <FileText className="w-3 h-3" />
                    )}
                    <span>{file}</span>
                  </div>
                ))}
              </div>
            )}

            {/* Complaint Button for QR_SCANNED events */}
            {event.eventType === "QR_SCANNED" && !complaints[event.eventId] && (
              <div className="mt-3 pt-3 border-t border-slate-200">
                <Button
                  variant="outline"
                  size="sm"
                  className="text-red-600 border-red-300 hover:bg-red-50"
                  onClick={() => handleComplaint(event.eventId)}
                >
                  <Flag className="w-3 h-3 mr-2" />
                  Пожаловаться
                </Button>
              </div>
            )}

            {/* Complaint Status */}
            {complaints[event.eventId] && (
              <div className="mt-3 pt-3 border-t border-slate-200">
                <div className={`p-3 rounded-lg border ${complaintStatusConfig[complaints[event.eventId].status].color}`}>
                  <div className="flex items-center gap-2 mb-2">
                    <Flag className="w-4 h-4" />
                    <span className="text-sm font-semibold">
                      Статус жалобы: {complaintStatusConfig[complaints[event.eventId].status].label}
                    </span>
                  </div>
                  {complaints[event.eventId].comment && (
                    <div className="text-xs mb-1">
                      {complaints[event.eventId].comment}
                    </div>
                  )}
                  <div className="text-xs opacity-75">
                    Подана: {complaints[event.eventId].submittedAt}
                  </div>
                </div>
              </div>
            )}
          </Card>
        ))}
      </div>

      {/* Summary */}
      <Card className="p-4 bg-slate-50">
        <div className="text-sm text-slate-700">
          <strong>Всего событий:</strong> {filteredEvents.length} из {mockEvents.length}
        </div>
      </Card>
    </div>
  );
}