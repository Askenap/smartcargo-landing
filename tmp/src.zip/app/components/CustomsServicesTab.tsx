import { Card } from "./ui/card";
import { FileText, Shield, CheckCircle, AlertTriangle, Database } from "lucide-react";

export default function CustomsServicesTab() {
  const scenarios = [
    {
      icon: Database,
      title: "Автоматическая подача ТД",
      description: "Формирование и подача таможенных деклараций на основе данных ЦПП",
    },
    {
      icon: CheckCircle,
      title: "Проверка соответствия",
      description: "Автоматическая проверка комплектности и корректности документов",
    },
    {
      icon: Shield,
      title: "Отслеживание статусов",
      description: "Мониторинг статусов ПИ, ТД и других таможенных процедур",
    },
    {
      icon: FileText,
      title: "Электронный архив",
      description: "Хранение всех таможенных документов в электронном виде",
    },
  ];

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center gap-3">
        <div className="w-12 h-12 bg-amber-500 rounded-lg flex items-center justify-center">
          <FileText className="w-6 h-6 text-white" />
        </div>
        <div>
          <h2 className="text-2xl font-semibold text-slate-900">Таможенные сервисы</h2>
          <p className="text-slate-600 mt-1">Интеграция с таможенными системами</p>
        </div>
      </div>

      {/* Development Banner */}
      <Card className="p-6 bg-amber-50 border-amber-200">
        <div className="flex items-start gap-3">
          <AlertTriangle className="w-6 h-6 text-amber-600 flex-shrink-0 mt-1" />
          <div>
            <h3 className="font-medium text-amber-900 mb-2">Модуль скоро будет доступен</h3>
            <p className="text-sm text-amber-800">
              Модуль таможенных сервисов находится на стадии интеграции с государственными системами. 
              Функционал будет включать автоматизацию таможенного оформления и проверки деклараций.
            </p>
          </div>
        </div>
      </Card>

      {/* Scenarios */}
      <div>
        <h3 className="font-semibold text-lg mb-4 text-slate-900">Сценарии применения</h3>
        <div className="grid md:grid-cols-2 gap-4">
          {scenarios.map((scenario, idx) => (
            <Card key={idx} className="p-6">
              <div className="flex items-start gap-3 mb-3">
                <div className="w-10 h-10 bg-amber-100 rounded-lg flex items-center justify-center flex-shrink-0">
                  <scenario.icon className="w-5 h-5 text-amber-600" />
                </div>
                <div>
                  <h4 className="font-medium text-slate-900">{scenario.title}</h4>
                </div>
              </div>
              <p className="text-sm text-slate-600">{scenario.description}</p>
            </Card>
          ))}
        </div>
      </div>
    </div>
  );
}