import { useState } from "react";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { Card } from "./ui/card";
import { User, Building, Phone, Mail, MapPin, Edit } from "lucide-react";

export default function ProfileTab() {
  const [isEditing, setIsEditing] = useState(false);
  const [formData, setFormData] = useState({
    companyName: "ТОО 'Транс Логистик'",
    bin: "123456789012",
    director: "Иванов Иван Иванович",
    phone: "+7 (7172) 123-456",
    email: "info@translogistic.kz",
    address: "г. Астана, ул. Кабанбай батыра, 32",
  });

  const handleSave = () => {
    setIsEditing(false);
    // Save logic here
  };

  return (
    <div className="space-y-6 max-w-3xl">
      {/* Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl font-semibold text-slate-900">Профиль</h2>
          <p className="text-slate-600 mt-1">Информация о компании</p>
        </div>
        {!isEditing ? (
          <Button onClick={() => setIsEditing(true)} variant="outline">
            <Edit className="w-4 h-4 mr-2" />
            Редактировать
          </Button>
        ) : (
          <div className="flex gap-2">
            <Button onClick={() => setIsEditing(false)} variant="outline">
              Отменить
            </Button>
            <Button onClick={handleSave} className="bg-sky-500 hover:bg-sky-600">
              Сохранить
            </Button>
          </div>
        )}
      </div>

      {/* Company Info Card */}
      <Card className="p-6">
        <h3 className="font-semibold text-lg mb-6 text-slate-900">Данные компании</h3>
        <div className="space-y-4">
          <div>
            <label className="text-sm text-slate-500 mb-2 flex items-center gap-2">
              <Building className="w-4 h-4" />
              Название компании
            </label>
            {isEditing ? (
              <Input
                value={formData.companyName}
                onChange={(e) => setFormData({ ...formData, companyName: e.target.value })}
              />
            ) : (
              <p className="text-slate-900">{formData.companyName}</p>
            )}
          </div>

          <div>
            <label className="text-sm text-slate-500 mb-2 flex items-center gap-2">
              <Building className="w-4 h-4" />
              БИН
            </label>
            {isEditing ? (
              <Input
                value={formData.bin}
                onChange={(e) => setFormData({ ...formData, bin: e.target.value })}
              />
            ) : (
              <p className="text-slate-900">{formData.bin}</p>
            )}
          </div>

          <div>
            <label className="text-sm text-slate-500 mb-2 flex items-center gap-2">
              <User className="w-4 h-4" />
              Руководитель
            </label>
            {isEditing ? (
              <Input
                value={formData.director}
                onChange={(e) => setFormData({ ...formData, director: e.target.value })}
              />
            ) : (
              <p className="text-slate-900">{formData.director}</p>
            )}
          </div>

          <div>
            <label className="text-sm text-slate-500 mb-2 flex items-center gap-2">
              <Phone className="w-4 h-4" />
              Телефон
            </label>
            {isEditing ? (
              <Input
                value={formData.phone}
                onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
              />
            ) : (
              <p className="text-slate-900">{formData.phone}</p>
            )}
          </div>

          <div>
            <label className="text-sm text-slate-500 mb-2 flex items-center gap-2">
              <Mail className="w-4 h-4" />
              Email
            </label>
            {isEditing ? (
              <Input
                value={formData.email}
                onChange={(e) => setFormData({ ...formData, email: e.target.value })}
              />
            ) : (
              <p className="text-slate-900">{formData.email}</p>
            )}
          </div>

          <div>
            <label className="text-sm text-slate-500 mb-2 flex items-center gap-2">
              <MapPin className="w-4 h-4" />
              Адрес
            </label>
            {isEditing ? (
              <Input
                value={formData.address}
                onChange={(e) => setFormData({ ...formData, address: e.target.value })}
              />
            ) : (
              <p className="text-slate-900">{formData.address}</p>
            )}
          </div>
        </div>
      </Card>

      {/* Statistics Card */}
      <Card className="p-6">
        <h3 className="font-semibold text-lg mb-6 text-slate-900">Статистика</h3>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <div>
            <div className="text-sm text-slate-500 mb-1">Перевозок</div>
            <div className="text-2xl font-semibold text-slate-900">45</div>
          </div>
          <div>
            <div className="text-sm text-slate-500 mb-1">Транспорта</div>
            <div className="text-2xl font-semibold text-slate-900">8</div>
          </div>
          <div>
            <div className="text-sm text-slate-500 mb-1">Водителей</div>
            <div className="text-2xl font-semibold text-slate-900">15</div>
          </div>
          <div>
            <div className="text-sm text-slate-500 mb-1">Документов</div>
            <div className="text-2xl font-semibold text-slate-900">127</div>
          </div>
        </div>
      </Card>
    </div>
  );
}
