import { Card } from "./ui/card";
import { Brain, TrendingUp, AlertTriangle, FileText, MapPin } from "lucide-react";

export default function AIAssistantTab() {
  const scenarios = [
    {
      icon: TrendingUp,
      title: "Прогнозирование задержек",
      description: "AI анализирует исторические данные и текущую ситуацию на КПП для прогноза времени прохождения",
    },
    {
      icon: AlertTriangle,
      title: "Обнаружение аномалий",
      description: "Автоматическое выявление нестандартных ситуаций и потенциальных проблем в маршруте",
    },
    {
      icon: MapPin,
      title: "Оптимизация маршрутов",
      description: "Рекомендации по выбору оптимального маршрута на основе загруженности КПП и дорожной ситуации",
    },
    {
      icon: FileText,
      title: "Помощь с документами",
      description: "Интеллектуальная проверка комплектности и корректности документов перед подачей",
    },
  ];

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center gap-3">
        <div className="w-12 h-12 bg-indigo-500 rounded-lg flex items-center justify-center">
          <Brain className="w-6 h-6 text-white" />
        </div>
        <div>
          <h2 className="text-2xl font-semibold text-slate-900">AI-ассистент</h2>
          <p className="text-slate-600 mt-1">Интеллектуальная поддержка и прогнозирование</p>
        </div>
      </div>

      {/* Development Banner */}
      <Card className="p-6 bg-amber-50 border-amber-200">
        <div className="flex items-start gap-3">
          <AlertTriangle className="w-6 h-6 text-amber-600 flex-shrink-0 mt-1" />
          <div>
            <h3 className="font-medium text-amber-900 mb-2">Модуль скоро будет доступен</h3>
            <p className="text-sm text-amber-800">
              AI-ассистент находится на стадии активной разработки. Функционал будет доступен в ближайших обновлениях.
            </p>
          </div>
        </div>
      </Card>

      {/* Scenarios */}
      <div>
        <h3 className="font-semibold text-lg mb-4 text-slate-900">Сценарии применения</h3>
        <div className="grid md:grid-cols-2 gap-4">
          {scenarios.map((scenario, idx) => (
            <Card key={idx} className="p-6">
              <div className="flex items-start gap-3 mb-3">
                <div className="w-10 h-10 bg-indigo-100 rounded-lg flex items-center justify-center flex-shrink-0">
                  <scenario.icon className="w-5 h-5 text-indigo-600" />
                </div>
                <div>
                  <h4 className="font-medium text-slate-900">{scenario.title}</h4>
                </div>
              </div>
              <p className="text-sm text-slate-600">{scenario.description}</p>
            </Card>
          ))}
        </div>
      </div>
    </div>
  );
}