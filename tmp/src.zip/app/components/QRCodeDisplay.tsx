import { Button } from "./ui/button";
import { QrCode, Download, Share2, WifiOff, Clock } from "lucide-react";
import { Card } from "./ui/card";

interface QRCodeDisplayProps {
  tripId?: string;
  offlineMode?: boolean;
  lastSync?: string;
}

export default function QRCodeDisplay({ tripId = "TR-2026-000125", offlineMode = false, lastSync }: QRCodeDisplayProps) {
  const handleDownloadQR = () => {
    // Download QR code logic
    console.log("Downloading QR code for trip:", tripId);
  };

  const handleShareTracking = () => {
    // Share tracking link logic
    const trackingUrl = `https://smartcargo.kz/tracking/${tripId}`;
    navigator.clipboard.writeText(trackingUrl);
    alert("Ссылка на трекинг скопирована в буфер обмена");
  };

  return (
    <Card className="p-6">
      <h3 className="font-semibold text-lg mb-4 text-slate-900">QR Smart Cargo</h3>
      
      <div className="flex flex-col items-center mb-6">
        {/* QR Code Placeholder */}
        <div className="w-64 h-64 bg-white border-4 border-slate-200 rounded-lg flex items-center justify-center mb-4 relative">
          <QrCode className="w-48 h-48 text-slate-300" />
          
          {/* Offline badge */}
          {offlineMode && (
            <div className="absolute top-2 right-2 bg-amber-100 text-amber-800 text-xs px-2 py-1 rounded-full flex items-center gap-1">
              <WifiOff className="w-3 h-3" />
              Offline snapshot
            </div>
          )}
        </div>

        <div className="text-center text-sm text-slate-600 mb-2">
          ID перевозки: <span className="font-medium text-slate-900">{tripId}</span>
        </div>

        {/* Info about QR */}
        <div className="bg-sky-50 border border-sky-200 rounded-lg p-4 text-sm text-slate-700 max-w-md">
          <p className="mb-2 text-[13px]">
            Закон РК «Об автомобильном транспорте» № 476 I от 21.09.1994.
          </p>
          <p className="mb-2 text-[13px]">
            Указ Президента РК № 2271 от 12.05.1995 «О присоединении Республики Казахстан к Конвенции о договоре международной дорожной перевозки грузов (CMR)».
          </p>
          {lastSync && (
            <div className="flex items-center gap-1 text-xs text-slate-600 mt-2">
              <Clock className="w-3 h-3" />
              Последняя синхронизация: {lastSync}
            </div>
          )}
        </div>
      </div>

      {/* Action Buttons */}
      <div className="flex flex-col sm:flex-row gap-3">
        <Button variant="outline" className="flex-1" onClick={handleDownloadQR}>
          <Download className="w-4 h-4 mr-2" />
          Скачать QR
        </Button>
        <Button variant="outline" className="flex-1" onClick={handleShareTracking}>
          <Share2 className="w-4 h-4 mr-2" />
          Создать ссылку на трекинг
        </Button>
      </div>

      {/* Technical info */}
      <div className="mt-4 text-xs text-slate-500 border-t border-slate-200 pt-4">
        <div className="grid grid-cols-2 gap-2">
          <div>TTL: 24 часа</div>
          <div>Шифрование: AES-256</div>
          <div>Формат: QR Code 2D</div>
          <div>Версия: v2.1</div>
        </div>
      </div>
    </Card>
  );
}