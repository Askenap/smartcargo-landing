import { useState } from "react";
import { Button } from "./ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "./ui/dialog";
import { Gauge } from "lucide-react";

interface Driver {
  id: string;
  fullName: string;
  driverId: string;
  phone: string;
  status: "active" | "on_route" | "inactive";
}

interface DriverPopoverProps {
  shipmentId: string;
  drivers: Driver[];
  onSelect: (driverId: string, shipmentId: string) => void;
}

export default function DriverPopover({ shipmentId, drivers, onSelect }: DriverPopoverProps) {
  const [open, setOpen] = useState(false);

  const handleSelect = (driverId: string) => {
    onSelect(driverId, shipmentId);
    setOpen(false);
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <Button
        type="button"
        size="sm"
        variant="outline"
        className="text-emerald-600 border-emerald-300 hover:bg-emerald-50"
        title="Назначить водителя"
        onClick={() => setOpen(true)}
      >
        <Gauge className="w-4 h-4" />
      </Button>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle>Выберите водителя</DialogTitle>
          <DialogDescription>Назначьте водителя для этой перевозки</DialogDescription>
        </DialogHeader>
        <div className="space-y-2 max-h-96 overflow-y-auto">
          {drivers.map((driver) => (
            <button
              key={driver.id}
              onClick={() => handleSelect(driver.id)}
              className="w-full text-left p-3 rounded-lg border border-slate-200 hover:bg-sky-50 hover:border-sky-300 transition-colors"
            >
              <div className="flex items-center justify-between">
                <div className="flex-1 min-w-0">
                  <div className="text-sm font-medium text-slate-900 truncate">{driver.fullName}</div>
                  <div className="text-xs text-slate-500 mt-0.5">{driver.driverId}</div>
                </div>
                <span
                  className={`ml-2 px-2 py-1 rounded-full text-xs font-medium flex-shrink-0 ${
                    driver.status === "active"
                      ? "bg-green-50 text-green-700"
                      : driver.status === "on_route"
                      ? "bg-blue-50 text-blue-700"
                      : "bg-slate-100 text-slate-600"
                  }`}
                >
                  {driver.status === "active" ? "Доступен" : driver.status === "on_route" ? "На маршруте" : "Неактивен"}
                </span>
              </div>
            </button>
          ))}
        </div>
      </DialogContent>
    </Dialog>
  );
}