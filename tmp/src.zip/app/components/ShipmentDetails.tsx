import { useState } from "react";
import { Button } from "./ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "./ui/tabs";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "./ui/dialog";
import { ArrowLeft, CheckCircle, MapPin, Clock, QrCode, ChevronDown, ChevronUp, FileText, RefreshCw } from "lucide-react";
import QRCodeDisplay from "./QRCodeDisplay";
import StatusTimeline from "./StatusTimeline";
import AuditTrail from "./AuditTrail";
import ProcessTimeline from "./ProcessTimeline";
import TrackingMap from "./TrackingMap";
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "./ui/tooltip";

interface Shipment {
  id: string;
  from: string;
  fromFlag: string;
  to: string;
  toFlag: string;
  totalAmount: string;
  status: string;
  registrationNumber: string;
  originType: "PI_TD" | "SNT" | "E_TTN";
}

interface ShipmentDetailsProps {
  shipment: Shipment;
  onBack: () => void;
}

export default function ShipmentDetails({ shipment, onBack }: ShipmentDetailsProps) {
  const [activeTab, setActiveTab] = useState("general");
  const [showQRDialog, setShowQRDialog] = useState(false);
  const [expandedTractor, setExpandedTractor] = useState(true);
  const [expandedTrailer, setExpandedTrailer] = useState(true);

  // Helper function to get document label
  function getDocumentLabel(originType: "PI_TD" | "SNT" | "E_TTN"): string {
    const labels = {
      PI_TD: "ПИ",
      SNT: "СНТ",
      E_TTN: "Е-ТТН",
    };
    return labels[originType];
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <Button variant="ghost" onClick={onBack} className="mb-2 -ml-3">
            <ArrowLeft className="w-4 h-4 mr-2" />
            Назад к списку
          </Button>
          <div className="flex items-center gap-3">
            <h2 className="text-2xl font-semibold text-slate-900">
              Единый паспорт перевозки (ЦПП)
            </h2>
          </div>
          <div className="flex items-center gap-3 mt-2">
            <span className="text-lg font-medium text-slate-900">
              {getDocumentLabel(shipment.originType)} № {shipment.registrationNumber}
            </span>
            <span className="px-3 py-1 bg-blue-50 text-blue-700 text-sm rounded-full">
              В процессе поставки
            </span>
          </div>
          <p className="text-sm text-slate-500 mt-1">26.01.2026 10:57</p>
        </div>
        <div className="flex gap-2">
          <Button
            variant="default"
            className="bg-sky-500 hover:bg-sky-600"
            onClick={() => setShowQRDialog(true)}
          >
            <QrCode className="w-4 h-4 mr-2" />
            QR-код
          </Button>
          <Button variant="outline" className="text-slate-600 p-2" size="icon">
            <RefreshCw className="w-4 h-4" />
          </Button>
        </div>
      </div>

      {/* Process Timeline */}
      <ProcessTimeline />

      {/* Tabs */}
      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="w-full justify-start overflow-x-auto whitespace-nowrap flex-nowrap h-auto gap-2 bg-slate-100 p-1">
          <TabsTrigger value="general" className="flex-shrink-0">Обзор</TabsTrigger>
          <TabsTrigger value="cargo" className="flex-shrink-0">Груз</TabsTrigger>
          <TabsTrigger value="transport" className="flex-shrink-0">Транспорт</TabsTrigger>
          <TabsTrigger value="participants" className="flex-shrink-0">Участники</TabsTrigger>
          <TabsTrigger value="documents" className="flex-shrink-0">Документы</TabsTrigger>
          <TabsTrigger value="tracking" className="flex-shrink-0">Трекинг груза</TabsTrigger>
          <TabsTrigger value="qr" className="flex-shrink-0">QR-код ЦПП</TabsTrigger>
          <TabsTrigger value="audit" className="flex-shrink-0">Журнал действий</TabsTrigger>
        </TabsList>

        {/* General Tab - Combined Overview and Route */}
        <TabsContent value="general" className="space-y-6 mt-6">
          <div className="bg-white rounded-lg border border-slate-200 p-6">
            <h3 className="font-semibold text-lg mb-4 text-slate-900">Общая информация</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="text-sm text-slate-500">Тип перевозки</label>
                <div className="text-slate-900 mt-1">Международная автомобильная</div>
              </div>
              <div>
                <label className="text-sm text-slate-500">Номер перевозки</label>
                <div className="text-slate-900 mt-1">SC/{shipment.registrationNumber}</div>
              </div>
              <div>
                <label className="text-sm text-slate-500">Дата создания</label>
                <div className="text-slate-900 mt-1">26.01.2026</div>
              </div>
              <div>
                <label className="text-sm text-slate-500">Статус</label>
                <div className="mt-1">
                  <span className="px-3 py-1 bg-blue-50 text-blue-700 text-sm rounded-full">
                    В процессе поставки
                  </span>
                </div>
              </div>
            </div>
          </div>

          {/* Verified Passage Block */}
          <div className="bg-gradient-to-r from-blue-50 to-indigo-50 rounded-lg border border-blue-100 p-6">
             <div className="flex items-center justify-between">
                <div className="flex items-center gap-4">
                   <div className="w-10 h-10 rounded-full bg-blue-600 flex items-center justify-center text-white shadow-sm shadow-blue-200">
                      <CheckCircle className="w-5 h-5" />
                   </div>
                   <div>
                      <h3 className="font-semibold text-lg text-slate-900">Верифицированный проход</h3>
                      <div className="flex items-center gap-3 mt-1">
                         <span className="text-sm text-slate-600">Ruqsat: <span className="font-medium text-green-600">Подтверждено</span></span>
                         <span className="w-1 h-1 rounded-full bg-slate-300"></span>
                         <span className="text-sm text-slate-600">КПП: <span className="font-medium text-blue-600">Ожидание прибытия</span></span>
                      </div>
                   </div>
                </div>
                <Button className="bg-blue-600 hover:bg-blue-700 shadow-sm">
                   Перейти в Верифицированный проход
                </Button>
             </div>
          </div>

          {/* Route Information */}
          <div className="bg-white rounded-lg border border-slate-200 p-6">
            <h3 className="font-semibold text-lg mb-4 text-slate-900">Маршрут</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <label className="text-sm text-slate-500 mb-2 block">Страна отправления</label>
                <div className="text-slate-900 flex items-center gap-2">
                  {shipment.fromFlag} <span className="capitalize">{shipment.from.toLowerCase()}</span>
                </div>
              </div>
              <div>
                <label className="text-sm text-slate-500 mb-2 block">Страна назначения</label>
                <div className="text-slate-900 flex items-center gap-2">
                  {shipment.toFlag} <span className="capitalize">{shipment.to.toLowerCase()}</span>
                </div>
              </div>
              <div>
                <label className="text-sm text-slate-500 mb-2 block">Таможенный орган отправления</label>
                <div className="text-slate-900">Таможенный пост «Жетысу»</div>
              </div>
              <div>
                <label className="text-sm text-slate-500 mb-2 block">Место погрузки</label>
                <div className="text-slate-900 flex items-center gap-2">
                  <span className="text-lg">🇲🇳</span>
                  <span>Монголия</span>
                </div>
              </div>
              <div>
                <label className="text-sm text-slate-500 mb-2 block">Таможенный орган назначения</label>
                <div className="text-slate-900">Таможенный пост «Алтынколь-Жол»</div>
              </div>
              <div>
                <label className="text-sm text-slate-500 mb-2 block">Место разгрузки</label>
                <div className="text-slate-900 flex items-center gap-2">
                  <span className="text-lg">🇨🇳</span>
                  <span>Китай</span>
                </div>
              </div>
            </div>
          </div>

          {/* Help Text about CPP */}
          <div className="bg-sky-50 border border-sky-200 rounded-lg p-4 text-sm text-slate-700">
            <p className="font-medium mb-2">Что такое ЦПП?</p>
            <p>
              ЦПП (Единый паспорт перевозки) — это паспортное представление перевозки с журнлом событий 
              (audit trail), которое агрегирует статусы и документы из Smart Cargo и всех внешних 
              информационных систем (КЕДЕН, ЭСФ, KazToll и др.).
            </p>
          </div>
        </TabsContent>

        {/* Cargo Tab */}
        <TabsContent value="cargo" className="space-y-6 mt-6">
          <div className="bg-white rounded-lg border border-slate-200 p-6">
            <h3 className="font-semibold text-lg mb-4 text-slate-900">Информация о грузе</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="text-sm text-slate-500">Общее количество товаров</label>
                <div className="text-slate-900 mt-1">42 шт</div>
              </div>
              <div>
                <label className="text-sm text-slate-500">Общая стоимость</label>
                <div className="text-slate-900 mt-1">$125,000.00</div>
              </div>
              <div>
                <label className="text-sm text-slate-500">Масса брутто (кг)</label>
                <div className="text-slate-900 mt-1">15,420 кг</div>
              </div>
              <div>
                <label className="text-sm text-slate-500">Масса нетто (кг)</label>
                <div className="text-slate-900 mt-1">14,850 кг</div>
              </div>
              <div>
                <label className="text-sm text-slate-500">Количество грузовых мест</label>
                <div className="text-slate-900 mt-1">24</div>
              </div>
              <div>
                <label className="text-sm text-slate-500">Вид груза</label>
                <div className="text-slate-900 mt-1">Промышленное оборудование</div>
              </div>
            </div>
          </div>
        </TabsContent>

        {/* Transport Tab */}
        <TabsContent value="transport" className="space-y-6 mt-6">
          {/* Tractor Details */}
          <div className="bg-white rounded-lg border border-slate-200 overflow-hidden">
            <button
              className="w-full flex items-center justify-between p-6 hover:bg-slate-50 transition-colors"
              onClick={() => setExpandedTractor(!expandedTractor)}
            >
              <h3 className="font-semibold text-lg text-slate-900">Тягач</h3>
              {expandedTractor ? (
                <ChevronUp className="w-5 h-5 text-slate-500" />
              ) : (
                <ChevronDown className="w-5 h-5 text-slate-500" />
              )}
            </button>
            {expandedTractor && (
              <div className="px-6 pb-6 space-y-4 border-t border-slate-200 pt-4">
                <div>
                  <label className="text-sm text-slate-500">Госномер</label>
                  <div className="text-slate-900 mt-1">A 123 BC 01</div>
                </div>
                <div>
                  <label className="text-sm text-slate-500">Общее количество грузовых мест</label>
                  <div className="text-slate-900 mt-1">0</div>
                </div>
                <div>
                  <label className="text-sm text-slate-500">Тип транспорта</label>
                  <div className="text-slate-900 mt-1">Седельный тягач</div>
                </div>
                <div>
                  <label className="text-sm text-slate-500">Страна регистрации</label>
                  <div className="text-slate-900 mt-1 flex items-center gap-2">
                    <span className="text-lg">🇰🇿</span>
                    <span>Казахстан</span>
                  </div>
                </div>
                <div>
                  <label className="text-sm text-slate-500">Вид транспорта</label>
                  <div className="text-slate-900 mt-1">Автомобильный</div>
                </div>
                <div>
                  <label className="text-sm text-slate-500">Собственник ТС</label>
                  <div className="text-slate-900 mt-1">ТОО "Транс Логистик" (БИН: 123456789012)</div>
                  <div className="text-xs text-slate-500 mt-1">
                    Определен по связке ТС→БИН через реестр МВД
                  </div>
                </div>
              </div>
            )}
          </div>

          {/* Trailer Details */}
          <div className="bg-white rounded-lg border border-slate-200 overflow-hidden">
            <button
              className="w-full flex items-center justify-between p-6 hover:bg-slate-50 transition-colors"
              onClick={() => setExpandedTrailer(!expandedTrailer)}
            >
              <h3 className="font-semibold text-lg text-slate-900">Прицеп</h3>
              {expandedTrailer ? (
                <ChevronUp className="w-5 h-5 text-slate-500" />
              ) : (
                <ChevronDown className="w-5 h-5 text-slate-500" />
              )}
            </button>
            {expandedTrailer && (
              <div className="px-6 pb-6 space-y-4 border-t border-slate-200 pt-4">
                <div>
                  <label className="text-sm text-slate-500">Госномер</label>
                  <div className="text-slate-900 mt-1">B 456 DE 02</div>
                </div>
                <div>
                  <label className="text-sm text-slate-500">Общее количество грузовых мест</label>
                  <div className="text-slate-900 mt-1">24</div>
                </div>
                <div>
                  <label className="text-sm text-slate-500">Тип транспорта</label>
                  <div className="text-slate-900 mt-1">Полуприцеп рефрижератор</div>
                </div>
                <div>
                  <label className="text-sm text-slate-500">Страна регистрации</label>
                  <div className="text-slate-900 mt-1 flex items-center gap-2">
                    <span className="text-lg">🇰🇿</span>
                    <span>Казахстан</span>
                  </div>
                </div>
                <div>
                  <label className="text-sm text-slate-500">Вид транспорта</label>
                  <div className="text-slate-900 mt-1">Автомобильный</div>
                </div>
                <div>
                  <label className="text-sm text-slate-500">Собственник ТС</label>
                  <div className="text-slate-900 mt-1">ТОО "Транс Логистик" (БИН: 123456789012)</div>
                  <div className="text-xs text-slate-500 mt-1">
                    Определен по связке ТС→БИН через реестр МВД
                  </div>
                </div>
              </div>
            )}
          </div>
        </TabsContent>

        {/* Participants Tab */}
        <TabsContent value="participants" className="space-y-6 mt-6">
          <div className="bg-white rounded-lg border border-slate-200 p-6">
            <h3 className="font-semibold text-lg mb-4 text-slate-900">Участники</h3>
            <div className="space-y-4">
              <div>
                <label className="text-sm text-slate-500">Водитель</label>
                <div className="text-slate-900 mt-1">Иванов Иван Иванович</div>
                <div className="text-sm text-slate-600 mt-1">ИИН: 900101300123 • +7 777 123 4567</div>
              </div>
              <div>
                <label className="text-sm text-slate-500">Перевозчик</label>
                <div className="text-slate-900 mt-1">ТОО "Транс Логистик"</div>
                <div className="text-sm text-slate-600 mt-1">БИН: 123456789012</div>
              </div>
              <div>
                <label className="text-sm text-slate-500">Отправитель</label>
                <div className="text-slate-900 mt-1">ТОО "Экспорт Монголия"</div>
                <div className="text-sm text-slate-600 mt-1">РНН: MN-987654321</div>
              </div>
              <div>
                <label className="text-sm text-slate-500">Получатель</label>
                <div className="text-slate-900 mt-1">ООО "Китай Импорт Групп"</div>
                <div className="text-sm text-slate-600 mt-1">РНН: CN-123456789</div>
              </div>
              <div>
                <label className="text-sm text-slate-500">Таможенный представитель</label>
                <div className="text-slate-900 mt-1">ТОО "Таможенный Брокер Про"</div>
                <div className="text-sm text-slate-600 mt-1">БИН: 210987654321 • Лицензия: CB-2024-001</div>
              </div>
              <div>
                <label className="text-sm text-slate-500">Декларант</label>
                <div className="text-slate-900 mt-1">Петрова Анна Сергеевна</div>
                <div className="text-sm text-slate-600 mt-1">ИИН: 850515400456 • +7 702 555 1234</div>
              </div>
            </div>
          </div>
        </TabsContent>

        {/* Documents Tab */}
        <TabsContent value="documents" className="space-y-6 mt-6">
          <div className="bg-white rounded-lg border border-slate-200 p-6">
            <div className="flex items-center justify-between mb-4">
              <h3 className="font-semibold text-lg text-slate-900">Документы</h3>
            </div>
            
            {/* Documents List */}
            <div className="space-y-3">
              <TooltipProvider>
                {[
                  {
                    typeCode: "09013",
                    typeName: "Транспортный (перевозочный) документ",
                    name: "CMR № 123456",
                    docNumber: "CMR-2026-001234",
                    date: "2026-01-25",
                    createdDate: "2026-01-25",
                    status: "verified",
                  },
                  {
                    typeCode: "02011",
                    typeName: "Паспорт гражданина",
                    name: "Паспорт водителя",
                    docNumber: "N12345678",
                    date: "2026-01-20",
                    createdDate: "2026-01-20",
                    status: "verified",
                  },
                  {
                    typeCode: "08010",
                    typeName: "Инвойс (счет-фактура)",
                    name: "Инвойс",
                    docNumber: "INV-2026-00789",
                    date: "2026-01-24",
                    createdDate: "2026-01-24",
                    status: "verified",
                  },
                  {
                    typeCode: "04021",
                    typeName: "Сертификат происхождения товара",
                    name: "Сертификат CT-1",
                    docNumber: "CT1-MN-2026-0156",
                    date: "2026-01-23",
                    createdDate: "2026-01-23",
                    status: "uploaded",
                  },
                  {
                    typeCode: "09033",
                    typeName: "Страховой полис",
                    name: "Страховка груза",
                    docNumber: "POL-2026-567890",
                    date: "2026-01-22",
                    createdDate: "2026-01-22",
                    status: "verified",
                  },
                ].map((doc, idx) => (
                  <div
                    key={idx}
                    className="flex flex-col sm:flex-row items-start justify-between p-4 bg-slate-50 rounded-lg hover:bg-slate-100 transition-colors gap-3 sm:gap-0"
                  >
                    <div className="flex-1 space-y-2 w-full">
                      <div className="flex items-center gap-2 flex-wrap">
                        <Tooltip>
                          <TooltipTrigger asChild>
                            <span className="px-2 py-0.5 bg-slate-200 text-slate-700 text-xs font-mono rounded cursor-help flex-shrink-0">
                              {doc.typeCode}
                            </span>
                          </TooltipTrigger>
                          <TooltipContent>
                            <p className="max-w-xs">{doc.typeName}</p>
                          </TooltipContent>
                        </Tooltip>
                        <span className="text-sm font-medium text-slate-900 break-words">{doc.name}</span>
                      </div>
                      <div className="text-xs text-slate-600">
                        <span>Номер документа: {doc.docNumber}</span>
                      </div>
                      <div className="text-xs text-slate-500">
                        Дата создания: {doc.createdDate}
                      </div>
                    </div>
                    <div className="flex items-center gap-3 w-full sm:w-auto justify-end">
                      <Button variant="ghost" size="sm" className="text-sky-600 hover:text-sky-700">
                        <FileText className="w-4 h-4 mr-1" />
                        Открыть
                      </Button>
                      <span
                        className={`px-2 py-1 text-xs rounded-full whitespace-nowrap flex-shrink-0 ${
                          doc.status === "verified"
                            ? "bg-green-50 text-green-700"
                            : doc.status === "uploaded"
                            ? "bg-blue-50 text-blue-700"
                            : "bg-red-50 text-red-700"
                        }`}
                      >
                        {doc.status === "verified"
                          ? "Проверен"
                          : doc.status === "uploaded"
                          ? "Загружен"
                          : "Отклонен"}
                      </span>
                    </div>
                  </div>
                ))}
              </TooltipProvider>
            </div>
          </div>
        </TabsContent>

        {/* Tracking Tab */}
        <TabsContent value="tracking" className="space-y-6 mt-6">
          <div className="bg-white rounded-lg border border-slate-200 p-6">
            <h3 className="font-semibold text-lg mb-4 text-slate-900">Трекинг груза</h3>
            <div className="h-[600px] rounded-lg overflow-hidden border border-slate-300">
              <TrackingMap />
            </div>
          </div>
        </TabsContent>

        {/* QR Tab */}
        <TabsContent value="qr" className="space-y-6 mt-6">
          <QRCodeDisplay tripId={shipment.id} lastSync="2026-02-17 16:30" />
        </TabsContent>

        {/* Audit Trail Tab */}
        <TabsContent value="audit" className="space-y-6 mt-6">
          <AuditTrail tripId={shipment.id} />
        </TabsContent>
      </Tabs>

      {/* QR Code Dialog */}
      <Dialog open={showQRDialog} onOpenChange={setShowQRDialog}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>
              QR-код перевозки {shipment.fromFlag} {shipment.from} → {shipment.toFlag} {shipment.to}
            </DialogTitle>
            <DialogDescription>
              Единый паспорт перевозки (ЦПП) № SC/{shipment.registrationNumber}
            </DialogDescription>
          </DialogHeader>
          <QRCodeDisplay tripId={`SC/${shipment.registrationNumber}`} lastSync="2026-02-17 16:30" />
        </DialogContent>
      </Dialog>
    </div>
  );
}