import { RouterProvider, createBrowserRouter } from "react-router";
import { Toaster } from "./components/ui/sonner";
import LandingLayout from "./pages/landing/LandingLayout";
import Home from "./pages/landing/Home";
import AboutSmartCargo from "./pages/landing/AboutSmartCargo";
import DigitalPassport from "./pages/landing/DigitalPassport";
import Tracking from "./pages/landing/Tracking";
import Login from "./pages/Login";
import CarrierDashboard from "./pages/CarrierDashboard";
import DriverDashboard from "./pages/DriverDashboard";
import InspectorDashboard from "./pages/InspectorDashboard";
import NCMDashboard from "./pages/NCMDashboard";
import CarrierMobileDashboard from "./pages/CarrierMobileDashboard";

const router = createBrowserRouter([
  {
    path: "/",
    Component: LandingLayout,
    children: [
      {
        index: true,
        Component: Home,
      },
      {
        path: "smart-cargo",
        Component: AboutSmartCargo,
      },
      {
        path: "digital-passport",
        Component: DigitalPassport,
      },
      {
        path: "tracking",
        Component: Tracking,
      },
    ],
  },
  {
    path: "/login",
    Component: Login,
  },
  {
    path: "/carrier",
    Component: CarrierDashboard,
  },
  {
    path: "/carrier-mobile",
    Component: CarrierMobileDashboard,
  },
  {
    path: "/driver",
    Component: DriverDashboard,
  },
  {
    path: "/inspector",
    Component: InspectorDashboard,
  },
  {
    path: "/ncm",
    Component: NCMDashboard,
  },
  {
    path: "/management",
    Component: NCMDashboard,
  },
]);

export default function App() {
  return (
    <>
      <RouterProvider router={router} />
      <Toaster />
    </>
  );
}