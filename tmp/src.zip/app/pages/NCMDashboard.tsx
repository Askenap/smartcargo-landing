import { useState } from "react";
import { useNavigate } from "react-router";
import { Button } from "../components/ui/button";
import { Card } from "../components/ui/card";
import { Truck, BarChart3, MapPin, TrendingUp, Users, Package, LogOut, Globe } from "lucide-react";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "../components/ui/select";
import logo from "figma:asset/98e4a2aeb6ac2e19acbf98d0f7495391570dae6b.png";

export default function NCMDashboard() {
  const navigate = useNavigate();
  const [timeRange, setTimeRange] = useState("today");

  const stats = [
    { label: "Активные перевозки", value: "1,245", change: "+12%", icon: Truck, color: "bg-blue-500" },
    { label: "На КПП сейчас", value: "89", change: "+5", icon: MapPin, color: "bg-green-500" },
    { label: "Пройдено за сутки", value: "3,421", change: "+8%", icon: TrendingUp, color: "bg-purple-500" },
    { label: "Задержано", value: "12", change: "-3", icon: Package, color: "bg-red-500" },
  ];

  const checkpoints = [
    { name: "КПП Хоргос", active: 45, queue: 12, avgTime: "45 мин" },
    { name: "КПП Достык", active: 23, queue: 5, avgTime: "30 мин" },
    { name: "КПП Кайрак", active: 15, queue: 3, avgTime: "25 мин" },
    { name: "КПП Кордай", active: 6, queue: 1, avgTime: "20 мин" },
  ];

  const transportTypes = [
    { type: "Автомобильный", count: 856, percentage: 68 },
    { type: "Железнодорожный", count: 234, percentage: 19 },
    { type: "Морской", count: 98, percentage: 8 },
    { type: "Воздушный", count: 57, percentage: 5 },
  ];

  return (
    <div className="min-h-screen bg-slate-50">
      {/* Header */}
      <header className="bg-white border-b border-slate-200">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <img src={logo} alt="Smart Cargo" className="h-10" />
              <div>
                <h1 className="font-semibold text-slate-900">Единый центр мониторинга логистики</h1>
                <p className="text-xs text-slate-500">Аналитика и мониторинг грузопотоков</p>
              </div>
            </div>
            <div className="flex items-center gap-3">
              <Select value={timeRange} onValueChange={setTimeRange}>
                <SelectTrigger className="w-40">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="today">Сегодня</SelectItem>
                  <SelectItem value="week">Неделя</SelectItem>
                  <SelectItem value="month">Месяц</SelectItem>
                  <SelectItem value="year">Год</SelectItem>
                </SelectContent>
              </Select>
              <Button onClick={() => navigate("/")} variant="ghost">
                <LogOut className="w-4 h-4 mr-2" />
                Выход
              </Button>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-8">
        <div className="space-y-6">
          {/* Stats Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {stats.map((stat, idx) => (
              <Card key={idx} className="p-6">
                <div className="flex items-start justify-between mb-4">
                  <div className={`w-12 h-12 ${stat.color} rounded-lg flex items-center justify-center`}>
                    <stat.icon className="w-6 h-6 text-white" />
                  </div>
                  <span className={`text-sm font-medium ${
                    stat.change.startsWith("+") ? "text-green-600" : "text-red-600"
                  }`}>
                    {stat.change}
                  </span>
                </div>
                <div className="text-3xl font-semibold text-slate-900 mb-1">{stat.value}</div>
                <div className="text-sm text-slate-600">{stat.label}</div>
              </Card>
            ))}
          </div>

          {/* Map Placeholder */}
          <Card className="p-6">
            <h3 className="font-semibold text-lg mb-4 text-slate-900">Карта грузопотоков</h3>
            <div className="bg-slate-100 rounded-lg h-96 flex items-center justify-center">
              <div className="text-center text-slate-500">
                <Globe className="w-16 h-16 mx-auto mb-2" />
                <p>Интерактивная карта с грузопотоками в реальном времени</p>
              </div>
            </div>
          </Card>

          <div className="grid md:grid-cols-2 gap-6">
            {/* Checkpoints Status */}
            <Card className="p-6">
              <h3 className="font-semibold text-lg mb-4 text-slate-900">Статус КПП</h3>
              <div className="space-y-4">
                {checkpoints.map((cp, idx) => (
                  <div key={idx} className="border-b border-slate-100 pb-4 last:border-0 last:pb-0">
                    <div className="flex items-center justify-between mb-2">
                      <div className="font-medium text-slate-900">{cp.name}</div>
                      <div className="text-sm text-slate-600">⌀ {cp.avgTime}</div>
                    </div>
                    <div className="grid grid-cols-2 gap-2 text-sm">
                      <div className="bg-blue-50 rounded p-2">
                        <div className="text-blue-600 font-medium">{cp.active}</div>
                        <div className="text-xs text-slate-600">На проверке</div>
                      </div>
                      <div className="bg-amber-50 rounded p-2">
                        <div className="text-amber-600 font-medium">{cp.queue}</div>
                        <div className="text-xs text-slate-600">В очереди</div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </Card>

            {/* Transport Types */}
            <Card className="p-6">
              <h3 className="font-semibold text-lg mb-4 text-slate-900">Виды транспорта</h3>
              <div className="space-y-4">
                {transportTypes.map((transport, idx) => (
                  <div key={idx}>
                    <div className="flex items-center justify-between mb-2">
                      <div className="text-sm text-slate-900">{transport.type}</div>
                      <div className="text-sm font-medium text-slate-900">{transport.count}</div>
                    </div>
                    <div className="w-full bg-slate-100 rounded-full h-2">
                      <div
                        className="bg-sky-500 h-2 rounded-full"
                        style={{ width: `${transport.percentage}%` }}
                      />
                    </div>
                    <div className="text-xs text-slate-500 mt-1">{transport.percentage}%</div>
                  </div>
                ))}
              </div>
            </Card>
          </div>

          {/* Recent Issues */}
          <Card className="p-6">
            <h3 className="font-semibold text-lg mb-4 text-slate-900">Текущие инциденты и задержки</h3>
            <div className="space-y-3">
              {[
                { id: "INC-001", type: "Задержка", location: "КПП Хоргс", description: "Превышение габаритов", time: "30 ин назад" },
                { id: "INC-002", type: "Проверка", location: "КПП Достык", description: "Дополнительная проверка документов", time: "1 час назад" },
                { id: "INC-003", type: "Очередь", location: "КПП Хоргос", description: "Увеличенная очередь (>15 ТС)", time: "2 часа назад" },
              ].map((incident, idx) => (
                <div key={idx} className="flex items-start justify-between p-3 bg-amber-50 rounded-lg">
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-1">
                      <span className="font-medium text-slate-900 text-sm">{incident.id}</span>
                      <span className="px-2 py-0.5 bg-amber-200 text-amber-800 text-xs rounded">{incident.type}</span>
                    </div>
                    <div className="text-sm text-slate-700">{incident.description}</div>
                    <div className="text-xs text-slate-600 mt-1">{incident.location}</div>
                  </div>
                  <div className="text-xs text-slate-500 whitespace-nowrap ml-4">{incident.time}</div>
                </div>
              ))}
            </div>
          </Card>
        </div>
      </main>
    </div>
  );
}