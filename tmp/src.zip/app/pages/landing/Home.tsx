import { useNavigate } from "react-router";
import { useState } from "react";
import { Button } from "../../components/ui/button";
import { Card } from "../../components/ui/card";
import { 
  FileCheck, MapPin, CheckCircle2, Ship, Zap, Globe, 
  Mail, Phone, Handshake, Headphones, QrCode, ArrowRight,
  Copy, Check
} from "lucide-react";
import { motion } from "motion/react";
import { InteractiveJourney } from "../../components/ui/interactive-journey";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "../../components/ui/dialog";
import { toast } from "sonner";

export default function Home() {
  const navigate = useNavigate();
  const [showQRModal, setShowQRModal] = useState(false);
  const [showShareModal, setShowShareModal] = useState(false);
  const [copiedLink, setCopiedLink] = useState(false);
  const [notifications, setNotifications] = useState({
    kpp: false,
    station: false,
    event: false,
    release: false,
  });

  const shareUrl = "https://smartcargo.kz/tracking/SC-2026-001";

  const handleCopyLink = () => {
    navigator.clipboard.writeText(shareUrl);
    setCopiedLink(true);
    toast.success("Ссылка скопирована ✓");
    setTimeout(() => setCopiedLink(false), 2000);
  };

  const handleEnableNotifications = () => {
    toast.success("Уведомления включены ✓");
  };

  return (
    <div className="bg-gradient-to-b from-slate-50 via-white to-slate-50">
      {/* Hero Section - "О платформе" */}
      <section id="about" className="relative overflow-hidden bg-gradient-to-b from-white via-blue-50/30 to-blue-900">
        <div className="absolute top-0 left-0 w-[800px] h-[800px] bg-gradient-radial from-blue-300/20 via-blue-200/10 to-transparent blur-3xl" />
        <div className="absolute bottom-0 right-0 w-[900px] h-[900px] bg-gradient-radial from-blue-800/30 via-blue-600/15 to-transparent blur-3xl" />
        
        <div className="relative container mx-auto px-8 lg:px-12 py-20 lg:py-16">
          <div className="max-w-7xl mx-auto">
            {/* Content */}
            <motion.div 
              className="text-center space-y-8 mb-4 relative"
              initial={{ opacity: 0, y: -30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8 }}
            >
              <div className="absolute inset-0 -inset-x-20 -inset-y-10 bg-gradient-to-br from-white/80 via-blue-50/60 to-white/80 backdrop-blur-xl rounded-3xl shadow-xl border border-white/50 -z-10" />
              
              <div className="space-y-6 relative">
                <h1 className="font-bold tracking-tight leading-tight text-[#1E2A3A] text-[32px]">
                  Smart Cargo — цифровая платформа управления грузоперевозками
                </h1>
              </div>
              <div className="flex gap-4 justify-center relative">
                <Button 
                  onClick={() => navigate("/digital-passport")} 
                  className="h-12 px-8 text-base font-semibold bg-[#2563EB] hover:bg-[#1d4ed8] text-white rounded-lg"
                >
                  О ЦПП
                </Button>
                <Button 
                  onClick={() => navigate("/tracking")}
                  variant="outline"
                  className="h-12 px-8 text-base font-semibold border-2 border-[#2563EB] text-[#2563EB] hover:bg-[#EFF6FF] rounded-lg"
                >
                  О трекинге
                </Button>
              </div>
            </motion.div>
          </div>

          {/* Interactive Map */}
          <div className="mt-12">
            <p className="text-center text-[13px] text-[#94A3B8] mb-3">
              Интерактивный маршрут — нажмите на точку
            </p>
            <motion.div 
              className="w-full h-[520px]"
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 0.3 }}
            >
              <InteractiveJourney />
            </motion.div>
          </div>
        </div>
      </section>

      {/* Section: Модули платформы */}
      <section id="modules" className="relative py-28 bg-white">
        <div className="container mx-auto px-8 lg:px-12">
          <motion.div 
            className="text-center mb-20"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
          >
            <h2 className="text-4xl font-bold text-[#1E2A3A]">Модули платформы</h2>
          </motion.div>
          
          <div className="grid md:grid-cols-2 gap-8 max-w-6xl mx-auto">
            {/* Карточка 1: ЦПП */}
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5 }}
            >
              <Card className="p-8 h-full bg-white border border-[#E2E8F0] rounded-xl shadow-md hover:shadow-xl hover:border-[#2563EB] transition-all">
                <div className="w-12 h-12 bg-[#10B981] rounded-xl flex items-center justify-center mb-6">
                  <FileCheck className="w-6 h-6 text-white" strokeWidth={2} />
                </div>
                <h3 className="text-[22px] font-bold mb-4 text-[#1E2A3A]">
                  Цифровой паспорт перевозки (ЦПП)
                </h3>
                <p className="text-[#64748B] leading-relaxed mb-6">
                  Единая карточка рейса: все документы и статусы перевозки
                </p>
                
                <div className="space-y-3 mb-6">
                  <div className="flex items-start gap-3">
                    <CheckCircle2 className="w-5 h-5 text-[#10B981] flex-shrink-0 mt-0.5" />
                    <span className="text-[#475569] text-sm">Замена папки бумажных документов и ручного поиска статусов</span>
                  </div>
                  <div className="flex items-start gap-3">
                    <CheckCircle2 className="w-5 h-5 text-[#10B981] flex-shrink-0 mt-0.5" />
                    <span className="text-[#475569] text-sm">Предъявление на таможне по единому QR-коду</span>
                  </div>
                  <div className="flex items-start gap-3">
                    <CheckCircle2 className="w-5 h-5 text-[#10B981] flex-shrink-0 mt-0.5" />
                    <span className="text-[#475569] text-sm">Данные подтягиваются автоматически из госсистем</span>
                  </div>
                </div>

                <div className="flex items-center gap-4">
                  <Button 
                    variant="outline"
                    onClick={() => {
                      const el = document.getElementById("how-it-works");
                      el?.scrollIntoView({ behavior: "smooth" });
                    }}
                    className="border-[#E2E8F0] hover:bg-[#F5F7FA]"
                  >
                    Подробнее
                  </Button>
                  <button
                    onClick={() => navigate("/digital-passport")}
                    className="text-[#2563EB] text-sm font-medium flex items-center gap-1 hover:gap-2 transition-all"
                  >
                    О ЦПП <ArrowRight className="w-4 h-4" />
                  </button>
                </div>
              </Card>
            </motion.div>

            {/* Карточка 2: Трекинг */}
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: 0.1 }}
            >
              <Card className="p-8 h-full bg-white border border-[#E2E8F0] rounded-xl shadow-md hover:shadow-xl hover:border-[#2563EB] transition-all">
                <div className="w-12 h-12 bg-[#2563EB] rounded-xl flex items-center justify-center mb-6">
                  <MapPin className="w-6 h-6 text-white" strokeWidth={2} />
                </div>
                <h3 className="text-[22px] font-bold mb-4 text-[#1E2A3A]">
                  Трекинг Smart Cargo
                </h3>
                <p className="text-[#64748B] leading-relaxed mb-6">
                  Цепочка статусов и фактического движения рейса в одном интерфейсе
                </p>
                
                <div className="mb-6">
                  <p className="text-sm font-semibold text-[#475569] mb-3">Источники данных:</p>
                  <div className="flex flex-wrap gap-2">
                    <span className="px-3 py-1 bg-[#F1F5F9] text-[#475569] text-sm rounded-full">Кеден + СИК</span>
                    <span className="px-3 py-1 bg-[#F1F5F9] text-[#475569] text-sm rounded-full">KazToll</span>
                    <span className="px-3 py-1 bg-[#F1F5F9] text-[#475569] text-sm rounded-full">i-service (ЖД)</span>
                    <span className="px-3 py-1 bg-[#F1F5F9] text-[#475569] text-sm rounded-full">Cargo Ruqsat</span>
                  </div>
                </div>

                <div className="flex items-center gap-4">
                  <Button 
                    variant="outline"
                    onClick={() => {
                      const el = document.getElementById("tracking-section");
                      el?.scrollIntoView({ behavior: "smooth" });
                    }}
                    className="border-[#E2E8F0] hover:bg-[#F5F7FA]"
                  >
                    Подробнее
                  </Button>
                  <button
                    onClick={() => navigate("/tracking")}
                    className="text-[#2563EB] text-sm font-medium flex items-center gap-1 hover:gap-2 transition-all"
                  >
                    О трекинге <ArrowRight className="w-4 h-4" />
                  </button>
                </div>
              </Card>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Section: Как работает (ЦПП) */}
      <section id="how-it-works" className="relative py-28 bg-[#F5F7FA]">
        <div className="container mx-auto px-8 lg:px-12">
          <motion.div 
            className="text-center mb-20"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
          >
            <h2 className="text-4xl font-bold text-[#1E2A3A]">Как работает ЦПП</h2>
          </motion.div>

          <div className="grid lg:grid-cols-2 gap-12 max-w-6xl mx-auto mb-8">
            {/* Left: Stepper */}
            <div className="space-y-8">
              {/* Step 1 */}
              <div className="flex gap-4">
                <div className="flex flex-col items-center">
                  <div className="w-10 h-10 rounded-full bg-[#2563EB] text-white flex items-center justify-center font-bold flex-shrink-0">
                    1
                  </div>
                  <div className="w-0.5 bg-[#E2E8F0] flex-1 my-2" />
                </div>
                <div className="pb-8">
                  <h4 className="font-semibold text-[#1E2A3A] mb-3">Идентификация водителя</h4>
                  <div className="space-y-2 text-sm text-[#64748B]">
                    <p>• Иностранец: доступ через QazETA</p>
                    <p>• Водитель РК: вход через eGov Mobile</p>
                    <p>• Перевозчик: прикрепляет водителя к рейсу</p>
                  </div>
                </div>
              </div>

              {/* Step 2 */}
              <div className="flex gap-4">
                <div className="flex flex-col items-center">
                  <div className="w-10 h-10 rounded-full bg-[#2563EB] text-white flex items-center justify-center font-bold flex-shrink-0">
                    2
                  </div>
                  <div className="w-0.5 bg-[#E2E8F0] flex-1 my-2" />
                </div>
                <div className="pb-8">
                  <h4 className="font-semibold text-[#1E2A3A] mb-3">Формирование документов</h4>
                  <p className="text-sm text-[#64748B]">
                    Документы подтягиваются автоматически из ИС Кеден, ИС ЭСФ, ЕСУТД по факту оформления деклараций и прохождения контролей.
                  </p>
                </div>
              </div>

              {/* Step 3 */}
              <div className="flex gap-4">
                <div className="flex flex-col items-center">
                  <div className="w-10 h-10 rounded-full bg-[#2563EB] text-white flex items-center justify-center font-bold flex-shrink-0">
                    3
                  </div>
                </div>
                <div>
                  <h4 className="font-semibold text-[#1E2A3A] mb-3">Предъявление по QR</h4>
                  <div className="space-y-2 text-sm text-[#64748B]">
                    <p>• На таможенном посту: отметки контролей и выезда</p>
                    <p>• Инспектору на дороге: пакет документов по QR</p>
                    <p>• При въезде в ЕАЭС: прохождение границы</p>
                  </div>
                </div>
              </div>
            </div>

            {/* Right: QR Card */}
            <div>
              <Card className="p-8 bg-white border border-[#E2E8F0] rounded-2xl shadow-lg">
                <p className="text-base font-bold text-[#1E2A3A] mb-6">Рейс SC-2026-001</p>
                <div className="flex items-center justify-center mb-6">
                  <div className="w-40 h-40 bg-[#F1F5F9] rounded-lg flex items-center justify-center">
                    <QrCode className="w-20 h-20 text-[#94A3B8]" />
                  </div>
                </div>
                <Button 
                  variant="ghost"
                  onClick={() => setShowQRModal(true)}
                  className="w-full"
                >
                  Показать QR крупно
                </Button>
              </Card>
            </div>
          </div>

          {/* Легитимизация */}
          <div className="max-w-6xl mx-auto">
            <div className="bg-[#F8FAFC] border border-[#E2E8F0] rounded-lg p-4 px-6">
              <span className="text-sm text-[#64748B]">
                Легитимизация:{" "}
                <a href="#" className="text-[#2563EB] hover:underline font-medium">
                  Приказ о ЦПП →
                </a>
              </span>
            </div>
          </div>
        </div>
      </section>

      {/* Section: Трекинг */}
      <section id="tracking-section" className="relative py-28 bg-white">
        <div className="container mx-auto px-8 lg:px-12">
          <motion.div 
            className="text-center mb-20"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
          >
            <h2 className="text-4xl font-bold text-[#1E2A3A]">Трекинг Smart Cargo</h2>
          </motion.div>

          <div className="grid lg:grid-cols-2 gap-12 max-w-6xl mx-auto">
            {/* Left: Timeline */}
            <div>
              <h3 className="text-lg font-semibold text-[#1E2A3A] mb-6">История событий рейса</h3>
              
              {/* Horizontal Progress */}
              <div className="mb-8 overflow-x-auto pb-4">
                <div className="flex gap-2 min-w-max">
                  {["Погран", "ПИ", "Фито/Вето", "СКК", "Вес/Рентген", "Выпуск", "СВХ/Оплата", "Выезд"].map((step, idx) => (
                    <div key={idx} className="flex flex-col items-center gap-2">
                      <div className={`w-10 h-10 rounded-full flex items-center justify-center text-xs font-medium ${
                        idx < 3 ? "bg-[#2563EB] text-white" : idx === 3 ? "bg-[#2563EB] text-white animate-pulse" : "bg-[#CBD5E1] text-[#64748B]"
                      }`}>
                        {idx + 1}
                      </div>
                      <span className="text-xs text-[#64748B] text-center max-w-[80px]">{step}</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Event Cards */}
              <div className="space-y-4">
                {[
                  { source: "КД", time: "19.02.2026, 14:30", status: "Груз прошел таможенный досмотр" },
                  { source: "KT", time: "19.02.2026, 12:15", status: "Проезд через КПП Хоргос" },
                  { source: "IS", time: "18.02.2026, 09:00", status: "Прибытие на станцию Алматы-2" },
                ].map((event, idx) => (
                  <Card key={idx} className="p-4 bg-white border border-[#E2E8F0]">
                    <div className="flex items-start gap-3">
                      <span className="px-2 py-1 bg-[#2563EB] text-white text-xs font-bold rounded">
                        {event.source}
                      </span>
                      <div className="flex-1">
                        <p className="text-xs text-[#94A3B8] mb-1">{event.time}</p>
                        <p className="font-medium text-[#1E2A3A] text-sm">{event.status}</p>
                        <button className="text-xs text-[#2563EB] mt-2 hover:underline">
                          Подробнее
                        </button>
                      </div>
                    </div>
                  </Card>
                ))}
              </div>
            </div>

            {/* Right: Map & Controls */}
            <div className="space-y-6">
              {/* Mode Switcher */}
              <div className="flex gap-2 p-1 bg-[#F1F5F9] rounded-lg w-fit">
                <button className="px-4 py-2 bg-white text-[#1E2A3A] font-medium text-sm rounded-md shadow-sm">
                  Авто
                </button>
                <button className="px-4 py-2 text-[#64748B] font-medium text-sm">
                  ЖД
                </button>
              </div>

              {/* Map Placeholder */}
              <div className="h-[220px] bg-[#EFF6FF] border border-[#E2E8F0] rounded-xl flex items-center justify-center">
                <p className="text-[#64748B]">Карта маршрута</p>
              </div>

              {/* Current Position */}
              <Card className="p-4 bg-white border border-[#E2E8F0]">
                <p className="text-sm text-[#64748B] mb-1">Где груз сейчас:</p>
                <p className="font-semibold text-[#1E2A3A] mb-3">КПП Хоргос, таможенный досмотр</p>
                <p className="text-sm text-[#64748B] mb-1">Следующий этап:</p>
                <p className="font-semibold text-[#1E2A3A]">СВХ — оплата сборов</p>
              </Card>

              {/* Notifications */}
              <Card className="p-4 bg-white border border-[#E2E8F0]">
                <p className="font-semibold text-[#1E2A3A] mb-4">Уведомления</p>
                <div className="space-y-3 mb-4">
                  {[
                    { key: "kpp", label: "КПП / очередь" },
                    { key: "station", label: "Станция" },
                    { key: "event", label: "Событие на трассе" },
                    { key: "release", label: "Выпуск груза" },
                  ].map((item) => (
                    <label key={item.key} className="flex items-center gap-2 cursor-pointer">
                      <input
                        type="checkbox"
                        checked={notifications[item.key as keyof typeof notifications]}
                        onChange={(e) => setNotifications({ ...notifications, [item.key]: e.target.checked })}
                        className="w-4 h-4"
                      />
                      <span className="text-sm text-[#475569]">{item.label}</span>
                    </label>
                  ))}
                </div>
                <Button 
                  onClick={handleEnableNotifications}
                  className="w-full bg-[#2563EB] hover:bg-[#1d4ed8]"
                >
                  Включить уведомления
                </Button>
              </Card>

              {/* Share Link */}
              <Button 
                variant="outline"
                onClick={() => setShowShareModal(true)}
                className="w-full border-[#E2E8F0] hover:bg-[#F5F7FA]"
              >
                Создать ссылку на просмотр трекинга
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Section: Скоро будет */}
      <section id="coming-soon" className="relative py-28 bg-[#F5F7FA]">
        <div className="container mx-auto px-8 lg:px-12">
          <motion.div 
            className="text-center mb-20"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
          >
            <h2 className="text-4xl font-bold text-[#1E2A3A]">Скоро будет</h2>
          </motion.div>
          
          <div className="grid md:grid-cols-3 gap-6 max-w-6xl mx-auto">
            {[
              { icon: Ship, title: "Бронирование морской перевозки", desc: "Бронирование места на судне и портовых услуг для портов Актау и Курык." },
              { icon: Zap, title: "Верифицированный проход госграницы", desc: "Ускоренное прохождение границы через подтверждение готовности перевозки." },
              { icon: Globe, title: "Новые виды трекинга", desc: "Трекинг по навигационным пломбам, СВХ и всем дорогам Казахстана." },
            ].map((feature, idx) => (
              <motion.div
                key={idx}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: idx * 0.1 }}
              >
                <Card className="p-8 h-full bg-white border border-[#E2E8F0] rounded-xl shadow-md hover:shadow-lg transition-all relative">
                  <span className="absolute top-4 right-4 px-3 py-1 bg-[#FEF9C3] text-[#92400E] text-xs font-medium rounded-full">
                    Скоро
                  </span>
                  <div className="w-12 h-12 bg-[#F1F5F9] rounded-xl flex items-center justify-center mb-6">
                    <feature.icon className="w-6 h-6 text-[#2563EB]" strokeWidth={2} />
                  </div>
                  <h3 className="text-lg font-bold mb-3 text-[#1E2A3A]">
                    {feature.title}
                  </h3>
                  <p className="text-[#64748B] text-sm leading-relaxed">
                    {feature.desc}
                  </p>
                </Card>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Section: Контакты */}
      <section id="contacts" className="relative py-28 bg-white">
        <div className="container mx-auto px-8 lg:px-12">
          <motion.div 
            className="text-center mb-20"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
          >
            <h2 className="text-4xl font-bold text-[#1E2A3A]">Контакты</h2>
          </motion.div>

          <div className="max-w-6xl mx-auto grid lg:grid-cols-[1fr_1.5fr] gap-8">
            {/* Left: Contact Cards */}
            <div className="space-y-6">
              {/* Partners Card */}
              <Card className="p-6 bg-white border border-[#E2E8F0] rounded-xl">
                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 bg-[#2563EB] rounded-xl flex items-center justify-center flex-shrink-0">
                    <Handshake className="w-6 h-6 text-white" />
                  </div>
                  <div>
                    <h4 className="text-lg font-bold text-[#1E2A3A] mb-2">Партнёрам и интеграциям</h4>
                    <p className="text-sm text-[#64748B] mb-3">
                      Обсудим API-интеграцию, совместные проекты и подключение к платформе
                    </p>
                    <p className="text-sm font-semibold text-[#2563EB]">partners@smartcargo.kz</p>
                  </div>
                </div>
              </Card>

              {/* Support Card */}
              <Card className="p-6 bg-white border border-[#E2E8F0] rounded-xl">
                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 bg-[#10B981] rounded-xl flex items-center justify-center flex-shrink-0">
                    <Headphones className="w-6 h-6 text-white" />
                  </div>
                  <div>
                    <h4 className="text-lg font-bold text-[#1E2A3A] mb-2">Техническая поддержка</h4>
                    <p className="text-sm text-[#64748B] mb-3">
                      Вопросы по работе платформы и личному кабинету
                    </p>
                    <p className="text-sm font-semibold text-[#2563EB] mb-1">support@smartcargo.kz</p>
                    <p className="text-sm font-semibold text-[#64748B]">+7 (727) 123-45-67</p>
                  </div>
                </div>
              </Card>
            </div>

            {/* Right: Form */}
            <Card className="p-8 bg-white border border-[#E2E8F0] rounded-xl shadow-lg">
              <form className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-[#475569] mb-2">Имя</label>
                  <input
                    type="text"
                    className="w-full px-4 py-2.5 border border-[#E2E8F0] rounded-lg focus:outline-none focus:ring-2 focus:ring-[#2563EB] focus:border-transparent"
                    placeholder="Ваше имя"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-[#475569] mb-2">Компания</label>
                  <input
                    type="text"
                    className="w-full px-4 py-2.5 border border-[#E2E8F0] rounded-lg focus:outline-none focus:ring-2 focus:ring-[#2563EB] focus:border-transparent"
                    placeholder="Название компании"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-[#475569] mb-2">Email</label>
                  <input
                    type="email"
                    className="w-full px-4 py-2.5 border border-[#E2E8F0] rounded-lg focus:outline-none focus:ring-2 focus:ring-[#2563EB] focus:border-transparent"
                    placeholder="your@email.com"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-[#475569] mb-2">Телефон</label>
                  <input
                    type="tel"
                    className="w-full px-4 py-2.5 border border-[#E2E8F0] rounded-lg focus:outline-none focus:ring-2 focus:ring-[#2563EB] focus:border-transparent"
                    placeholder="+7 (___) ___-__-__"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-[#475569] mb-2">Сообщение</label>
                  <textarea
                    rows={4}
                    className="w-full px-4 py-2.5 border border-[#E2E8F0] rounded-lg focus:outline-none focus:ring-2 focus:ring-[#2563EB] focus:border-transparent resize-none"
                    placeholder="Ваше сообщение..."
                  />
                </div>
                <Button 
                  type="submit"
                  className="w-full bg-[#2563EB] hover:bg-[#1d4ed8] text-white h-11 font-semibold rounded-lg"
                >
                  Отправить
                </Button>
              </form>
            </Card>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="relative py-28 overflow-hidden bg-gradient-to-br from-slate-900 via-blue-900 to-slate-900">
        <div className="absolute inset-0 bg-[linear-gradient(to_right,#1e293b_1px,transparent_1px),linear-gradient(to_bottom,#1e293b_1px,transparent_1px)] bg-[size:4rem_4rem] opacity-10" />
        <div className="absolute top-0 right-0 w-[600px] h-[600px] bg-gradient-radial from-blue-500/20 via-transparent to-transparent blur-3xl" />
        
        <div className="relative container mx-auto px-8 lg:px-12">
          <motion.div 
            className="max-w-3xl mx-auto text-center"
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
          >
            <h2 className="text-4xl lg:text-5xl font-bold mb-6 text-white">
              Готовы начать работу?
            </h2>
            <p className="text-lg text-slate-300 mb-10">
              Авторизуйтесь в системе через eGov Mobile или KazETA
            </p>
            <Button 
              onClick={() => navigate("/login")} 
              className="bg-[#2563EB] hover:bg-[#1d4ed8] text-white h-14 px-10 text-lg font-semibold rounded-lg shadow-2xl"
            >
              Войти в систему
            </Button>
          </motion.div>
        </div>
      </section>

      {/* QR Modal */}
      <Dialog open={showQRModal} onOpenChange={setShowQRModal}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>QR-код рейса SC-2026-001</DialogTitle>
          </DialogHeader>
          <div className="flex items-center justify-center py-8">
            <div className="w-[300px] h-[300px] bg-[#F1F5F9] rounded-lg flex items-center justify-center">
              <QrCode className="w-40 h-40 text-[#94A3B8]" />
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Share Link Modal */}
      <Dialog open={showShareModal} onOpenChange={setShowShareModal}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>Ссылка на трекинг рейса</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="flex gap-2">
              <input
                type="text"
                readOnly
                value={shareUrl}
                className="flex-1 px-4 py-2.5 bg-[#F1F5F9] border border-[#E2E8F0] rounded-lg text-sm text-[#64748B]"
              />
              <Button
                onClick={handleCopyLink}
                className={`${copiedLink ? "bg-[#10B981]" : "bg-[#2563EB]"} hover:bg-[#1d4ed8]`}
              >
                {copiedLink ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
              </Button>
            </div>
            <p className="text-xs text-[#64748B]">
              Для грузовладельца / экспедитора / брокера / получателя
            </p>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}