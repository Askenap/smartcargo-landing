import { Outlet, useNavigate, useLocation } from "react-router";
import { Button } from "../../components/ui/button";
import { Menu, X } from "lucide-react";
import { useState, useEffect } from "react";
import logo from "figma:asset/ffd7c6eb8b88f51a4c715194d7126b772f432827.png";

export default function LandingLayout() {
  const navigate = useNavigate();
  const location = useLocation();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [activeSection, setActiveSection] = useState("about");

  const menuItems = [
    { label: "О платформе", anchor: "about" },
    { label: "Модули", anchor: "modules" },
    { label: "Как работает", anchor: "how-it-works" },
    { label: "Трекинг", anchor: "tracking-section" },
    { label: "Скоро будет", anchor: "coming-soon" },
    { label: "Контакты", anchor: "contacts" },
  ];

  // Handle scroll to section
  const scrollToSection = (anchor: string) => {
    if (location.pathname !== "/") {
      navigate("/");
      setTimeout(() => {
        const element = document.getElementById(anchor);
        if (element) {
          element.scrollIntoView({ behavior: "smooth" });
        }
      }, 100);
    } else {
      const element = document.getElementById(anchor);
      if (element) {
        element.scrollIntoView({ behavior: "smooth" });
      }
    }
    setMobileMenuOpen(false);
  };

  // Update active section on scroll
  useEffect(() => {
    if (location.pathname !== "/") return;

    const handleScroll = () => {
      const sections = menuItems.map(item => item.anchor);
      const scrollPosition = window.scrollY + 100;

      for (let i = sections.length - 1; i >= 0; i--) {
        const element = document.getElementById(sections[i]);
        if (element && element.offsetTop <= scrollPosition) {
          setActiveSection(sections[i]);
          break;
        }
      }
    };

    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, [location.pathname]);

  return (
    <div className="min-h-screen">
      {/* Header - Transparent on dark */}
      <header className="bg-slate-900/80 backdrop-blur-lg border-b border-slate-700/50 sticky top-0 z-50 bg-[#717172cc] shadow-lg shadow-slate-900/30">
        <div className="container mx-auto px-8 lg:px-12">
          <div className="flex items-center justify-between h-20">
            {/* Logo */}
            <div 
              className="flex items-center gap-3 cursor-pointer group"
              onClick={() => navigate("/")}
            >
              <img src={logo} alt="Smart Cargo" className="h-9 transition-transform group-hover:scale-105" />
            </div>

            {/* Navigation Menu */}
            <nav className="hidden lg:flex items-center gap-2">
              {menuItems.map((item) => (
                <button
                  key={item.anchor}
                  onClick={() => scrollToSection(item.anchor)}
                  className={`px-4 py-2 text-sm font-medium transition-all relative ${
                    location.pathname === "/" && activeSection === item.anchor
                      ? "text-white"
                      : "text-slate-300 hover:text-white"
                  }`}
                >
                  {item.label}
                  {location.pathname === "/" && activeSection === item.anchor && (
                    <span className="absolute bottom-0 left-0 right-0 h-0.5 bg-[#2563EB]" />
                  )}
                </button>
              ))}
            </nav>

            {/* Login Button */}
            <Button 
              onClick={() => navigate("/login")} 
              className="bg-[#2563EB] hover:bg-[#1d4ed8] text-white text-sm font-semibold px-6 h-10 rounded-lg shadow-lg transition-all border-0"
            >
              Войти в систему
            </Button>
          </div>

          {/* Mobile Navigation */}
          <nav className="lg:hidden pb-4 flex gap-2 overflow-x-auto scrollbar-hide">
            {menuItems.map((item) => (
              <button
                key={item.anchor}
                onClick={() => scrollToSection(item.anchor)}
                className={`px-4 py-2 font-medium whitespace-nowrap rounded-lg transition-all ${ activeSection === item.anchor ? "text-white bg-slate-700" : "text-slate-300 hover:text-white hover:bg-slate-700/50" } text-[14px]`}
              >
                {item.label}
              </button>
            ))}
          </nav>
        </div>
      </header>

      {/* Page Content */}
      <Outlet />

      {/* Footer - Dark */}
      <footer className="bg-slate-900 border-t border-slate-800">
        <div className="container mx-auto px-8 lg:px-12 py-16">
          <div className="grid md:grid-cols-3 gap-12">
            <div>
              <img src={logo} alt="Smart Cargo" className="h-8 mb-4" />
              <p className="text-sm text-slate-400 leading-relaxed max-w-xs">
                Единая цифровая платформа управления грузоперевозками
              </p>
            </div>
            <div>
              <h3 className="text-sm font-semibold mb-4 text-white">Навигация</h3>
              <div className="space-y-2.5">
                {menuItems.map((item) => (
                  <button
                    key={item.anchor}
                    onClick={() => scrollToSection(item.anchor)}
                    className="block text-sm text-slate-400 hover:text-white transition-colors"
                  >
                    {item.label}
                  </button>
                ))}
              </div>
            </div>
            <div>
              <h3 className="text-sm font-semibold mb-4 text-white">Контакты</h3>
              <div className="space-y-2.5 text-sm text-slate-400">
                <p>support@smartcargo.kz</p>
                <p>+7 (7172) 00-00-00</p>
                <p>Республика Казахстан</p>
              </div>
            </div>
          </div>
          <div className="border-t border-slate-800 mt-12 pt-8 text-center text-sm text-slate-400">
            © 2026 Smart Cargo. Все права защищены.
          </div>
        </div>
      </footer>
    </div>
  );
}