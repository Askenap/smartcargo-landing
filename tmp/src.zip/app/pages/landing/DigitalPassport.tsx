import { Card } from "../../components/ui/card";
import { Button } from "../../components/ui/button";
import { Truck, MapPin, FileText, QrCode, CheckCircle2, XCircle, Shield, Smartphone, ExternalLink, ChevronDown, ChevronUp } from "lucide-react";
import { motion } from "motion/react";
import { useNavigate } from "react-router";
import { useState } from "react";

export default function DigitalPassport() {
  const navigate = useNavigate();
  const [expandedScenario, setExpandedScenario] = useState<number | null>(null);
  const [expandedRole, setExpandedRole] = useState<number | null>(null);
  const [expandedIntegration, setExpandedIntegration] = useState<number | null>(null);

  // Сценарии перевозки
  const scenarios = [
    {
      title: "Въезд в РК",
      documents: [
        "Транзитная декларация",
        "Товаросопроводительные документы",
        "СМР (если применимо)",
        "Путевой лист"
      ]
    },
    {
      title: "Транзит по РК",
      documents: [
        "Транзитная декларация",
        "Товаросопроводительные документы",
        "Разрешение транзит",
        "Маршрутная карта"
      ]
    },
    {
      title: "ЕАЭС",
      documents: [
        "СНТ (статистическая накладная товарная)",
        "Товаросопроводительные документы",
        "Путевой лист",
        "ТТН"
      ]
    },
    {
      title: "Внутренняя перевозка",
      documents: [
        "ЭТТН (электронная товарно-транспортная накладная)",
        "Путевой лист",
        "Сертификаты соответствия",
        "Разрешения (при необходимости)"
      ]
    }
  ];

  // Роли
  const roles = [
    {
      title: "Водитель",
      icon: Truck,
      color: "from-blue-500 to-blue-600",
      benefits: [
        "Показывает QR инспектору",
        "Не носит бумажные документы",
        "Видит статус перевозки",
        "Получает уведомления"
      ]
    },
    {
      title: "Логист",
      icon: MapPin,
      color: "from-emerald-500 to-emerald-600",
      benefits: [
        "Создает перевозки",
        "Отслеживает статусы",
        "Управляет документами",
        "Формирует отчеты"
      ]
    },
    {
      title: "Инспектор",
      icon: Shield,
      color: "from-violet-500 to-violet-600",
      benefits: [
        "Сканирует QR",
        "Видит документы онлайн",
        "Проверяет подлинность",
        "Фиксирует проверки"
      ]
    }
  ];

  // Интеграции
  const integrations = [
    { name: "КЕДЕН", description: "Таможенная информационная система" },
    { name: "ЭСФ", description: "Электронный счет-фактура" },
    { name: "ЕСУТД", description: "Единая система учета товарно-транспортных документов" },
    { name: "eGov", description: "Государственный портал электронных услуг" },
    { name: "KazETA", description: "Система авторизации для нерезидентов" },
    { name: "МВД", description: "Регистрация транспортных средств" }
  ];

  // Метрики
  const metrics = [
    { number: "1", label: "QR код", description: "Вместо стопки документов" },
    { number: "4", label: "сценария", description: "Все типы перевозок" },
    { number: "0", label: "бумаг", description: "Полная цифровизация" },
    { number: "6", label: "интеграций", description: "С гос. системами" }
  ];

  // Нормативная база
  const regulations = [
    { title: "СНТ", link: "#" },
    { title: "КПП правила", link: "#" },
    { title: "Транспортный контроль", link: "#" },
    { title: "НПА ЦПП", link: "#" }
  ];

  return (
    <div className="bg-gradient-to-b from-slate-50 via-white to-slate-50">
      {/* Section 1: Hero */}
      <section className="relative py-32 bg-gradient-to-b from-white via-blue-50/30 to-blue-900 overflow-hidden">
        {/* Static gradient overlays */}
        <div className="absolute top-0 left-0 w-[800px] h-[800px] bg-gradient-radial from-blue-300/20 via-blue-200/10 to-transparent blur-3xl" />
        <div className="absolute top-0 right-0 w-[600px] h-[600px] bg-gradient-radial from-violet-500/20 via-transparent to-transparent blur-3xl" />
        <div className="absolute bottom-0 right-0 w-[900px] h-[900px] bg-gradient-radial from-blue-800/30 via-blue-600/15 to-transparent blur-3xl" />
        <div className="absolute bottom-0 left-0 w-[700px] h-[700px] bg-gradient-radial from-indigo-700/20 via-transparent to-transparent blur-3xl" />
        
        <div className="relative container mx-auto px-8 lg:px-12">
          <div className="grid lg:grid-cols-2 gap-16 items-center max-w-7xl mx-auto">
            {/* Left: Content */}
            <motion.div 
              className=""
              initial={{ opacity: 0, x: -30 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8 }}
            >
              <motion.div
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ delay: 0.2, duration: 0.6 }}
                className="inline-block px-4 py-2 bg-violet-500/20 backdrop-blur-sm border border-violet-500/40 rounded-full text-sm font-medium text-violet-900 mb-8"
              >
                Цифровой документ
              </motion.div>
              <h1 className="text-5xl lg:text-6xl font-bold mb-6 tracking-tight text-slate-900">
                Один QR-код вместо стопки документов
              </h1>
              <p className="text-xl text-slate-600 leading-relaxed mb-10">
                ЦПП — цифровой паспорт перевозки. Проезжайте таможню и контроль без бумажных документов.
              </p>
              <div className="flex gap-4">
                <Button 
                  onClick={() => navigate("/login")}
                  size="lg"
                  className="bg-gradient-to-r from-emerald-500 to-emerald-600 hover:from-emerald-600 hover:to-emerald-700 text-white h-12 px-8 text-base font-semibold shadow-lg shadow-emerald-500/30 hover:shadow-xl hover:shadow-emerald-500/40 transition-all border-0"
                >
                  Подключиться
                </Button>
                <Button 
                  onClick={() => navigate("/digital-passport")}
                  size="lg"
                  variant="outline"
                  className="h-12 px-8 text-base font-semibold bg-white/10 backdrop-blur-sm border-white/20 text-white hover:bg-white/20 hover:border-white/30"
                >
                  Узнать больше
                </Button>
              </div>
            </motion.div>

            {/* Right: Smartphone with QR */}
            <motion.div 
              className="relative"
              initial={{ opacity: 0, x: 30 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8, delay: 0.3 }}
            >
              <div className="relative max-w-sm mx-auto">
                {/* Smartphone mockup */}
                <motion.div
                  className="relative bg-gradient-to-br from-slate-800 to-slate-900 rounded-3xl p-6 border-4 border-slate-700 shadow-2xl"
                  animate={{ y: [0, -10, 0] }}
                  transition={{ duration: 4, repeat: Infinity }}
                >
                  <div className="bg-white rounded-2xl p-8">
                    <div className="text-center mb-6">
                      <div className="text-sm font-semibold text-slate-900 mb-2">ПЕРЕВОЗКА</div>
                      <div className="text-2xl font-bold text-slate-900">SC-2024-12345</div>
                      <div className="inline-block px-3 py-1 bg-emerald-500 text-white text-xs font-semibold rounded-full mt-2">
                        Активна
                      </div>
                    </div>
                    <div className="flex items-center justify-center mb-6">
                      <div className="w-48 h-48 bg-slate-900 rounded-xl flex items-center justify-center">
                        <QrCode className="w-40 h-40 text-white" />
                      </div>
                    </div>
                    <div className="text-center text-xs text-slate-500">
                      Предъявите QR инспектору
                    </div>
                  </div>
                </motion.div>
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Section 2: Проблема и решение */}
      <section className="py-28">
        <div className="container mx-auto px-8 lg:px-12">
          <motion.div 
            className="text-center mb-20 max-w-3xl mx-auto"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
          >
            <h2 className="text-4xl lg:text-5xl font-bold mb-6 tracking-tight text-slate-900">
              Бумажный бегунок — в прошлом
            </h2>
          </motion.div>

          <div className="grid md:grid-cols-2 gap-12 max-w-6xl mx-auto">
            {/* Сейчас */}
            <motion.div
              initial={{ opacity: 0, x: -30 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6 }}
            >
              <Card className="p-8 bg-red-50 border border-red-200 h-full">
                <h3 className="text-2xl font-bold text-red-900 mb-8">Сейчас</h3>
                <div className="space-y-4">
                  {[
                    "Бумажные документы",
                    "Ручные проверки",
                    "Задержки",
                    "Риск злоупотреблений"
                  ].map((item, idx) => (
                    <div key={idx} className="flex items-center gap-3">
                      <XCircle className="w-6 h-6 text-red-500 flex-shrink-0" />
                      <span className="text-lg text-slate-700">{item}</span>
                    </div>
                  ))}
                </div>
              </Card>
            </motion.div>

            {/* С ЦПП */}
            <motion.div
              initial={{ opacity: 0, x: 30 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6 }}
            >
              <Card className="p-8 bg-emerald-50 border border-emerald-200 h-full">
                <h3 className="text-2xl font-bold text-emerald-900 mb-8">С ЦПП</h3>
                <div className="space-y-4">
                  {[
                    "QR код вместо документов",
                    "Онлайн статусы",
                    "Мгновенная проверка",
                    "Audit trail"
                  ].map((item, idx) => (
                    <div key={idx} className="flex items-center gap-3">
                      <CheckCircle2 className="w-6 h-6 text-emerald-500 flex-shrink-0" />
                      <span className="text-lg text-slate-700">{item}</span>
                    </div>
                  ))}
                </div>
              </Card>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Section 3: Как это работает */}
      <section className="py-28 bg-white">
        <div className="container mx-auto px-8 lg:px-12">
          <motion.div 
            className="text-center mb-20 max-w-3xl mx-auto"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
          >
            <h2 className="text-4xl lg:text-5xl font-bold mb-6 tracking-tight text-slate-900">
              Как работает ЦПП
            </h2>
          </motion.div>

          <div className="grid md:grid-cols-3 gap-8 max-w-6xl mx-auto">
            {[
              {
                icon: FileText,
                title: "Создание перевозки и автоматическая загрузка данных",
                color: "from-blue-500 to-blue-600"
              },
              {
                icon: Smartphone,
                title: "Водитель показывает QR",
                color: "from-emerald-500 to-emerald-600"
              },
              {
                icon: Shield,
                title: "Инспектор сканирует QR и проверяет документы",
                color: "from-violet-500 to-violet-600"
              }
            ].map((step, idx) => (
              <motion.div
                key={idx}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: idx * 0.1 }}
              >
                <Card className={`p-8 h-full bg-gradient-to-br ${step.color} border-0 shadow-xl text-white`}>
                  <div className="w-14 h-14 bg-white/20 backdrop-blur-sm rounded-xl flex items-center justify-center mb-6">
                    <step.icon className="w-7 h-7 text-white" strokeWidth={2} />
                  </div>
                  <div className="text-xl font-bold mb-4 leading-snug">
                    {step.title}
                  </div>
                </Card>
              </motion.div>
            ))}
          </div>

          <motion.div 
            className="text-center mt-12"
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            viewport={{ once: true }}
            transition={{ delay: 0.5 }}
          >
            <p className="text-sm text-slate-600 font-medium">
              Все действия фиксируются в защищённом журнале.
            </p>
          </motion.div>
        </div>
      </section>

      {/* Section 4: Сценарии перевозки */}
      <section className="py-28 bg-slate-50">
        <div className="container mx-auto px-8 lg:px-12">
          <motion.div 
            className="text-center mb-20 max-w-3xl mx-auto"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
          >
            <h2 className="text-4xl lg:text-5xl font-bold mb-6 tracking-tight text-slate-900">
              ЦПП работает на всех маршрутах
            </h2>
          </motion.div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6 max-w-7xl mx-auto">
            {scenarios.map((scenario, idx) => (
              <motion.div
                key={idx}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: idx * 0.1 }}
              >
                <Card className="p-6 bg-white border border-slate-200 shadow-lg hover:shadow-xl transition-all">
                  <h3 className="text-lg font-bold text-slate-900 mb-4">{scenario.title}</h3>
                  <button
                    onClick={() => setExpandedScenario(expandedScenario === idx ? null : idx)}
                    className="flex items-center gap-2 text-sm font-semibold text-blue-600 hover:text-blue-700 transition-colors"
                  >
                    <span>Документы</span>
                    {expandedScenario === idx ? (
                      <ChevronUp className="w-4 h-4" />
                    ) : (
                      <ChevronDown className="w-4 h-4" />
                    )}
                  </button>
                  
                  {expandedScenario === idx && (
                    <motion.div
                      initial={{ opacity: 0, height: 0 }}
                      animate={{ opacity: 1, height: "auto" }}
                      exit={{ opacity: 0, height: 0 }}
                      className="mt-4 space-y-2"
                    >
                      <ul className="space-y-2">
                        {scenario.documents.map((doc, docIdx) => (
                          <li key={docIdx} className="flex items-start gap-2 text-sm text-slate-600">
                            <CheckCircle2 className="w-4 h-4 text-emerald-500 flex-shrink-0 mt-0.5" />
                            <span>{doc}</span>
                          </li>
                        ))}
                      </ul>
                    </motion.div>
                  )}
                </Card>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Section 5: Роли */}
      <section className="py-28 bg-white">
        <div className="container mx-auto px-8 lg:px-12">
          <motion.div 
            className="text-center mb-20 max-w-3xl mx-auto"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
          >
            <h2 className="text-4xl lg:text-5xl font-bold mb-6 tracking-tight text-slate-900">
              Для водителя, логиста и инспектора
            </h2>
          </motion.div>

          <div className="grid md:grid-cols-3 gap-6 max-w-6xl mx-auto">
            {roles.map((role, idx) => (
              <motion.div
                key={idx}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: idx * 0.1 }}
                whileHover={{ scale: 1.05, y: -5 }}
              >
                <Card className={`p-8 h-full bg-gradient-to-br ${role.color} border-0 shadow-xl hover:shadow-2xl transition-all text-white`}>
                  <div className="w-14 h-14 bg-white/20 backdrop-blur-sm rounded-xl flex items-center justify-center mb-6">
                    <role.icon className="w-7 h-7 text-white" strokeWidth={2} />
                  </div>
                  <h3 className="text-2xl font-bold mb-6">{role.title}</h3>
                  <ul className="space-y-3">
                    {role.benefits.map((benefit, benefitIdx) => (
                      <li key={benefitIdx} className="flex items-start gap-2 text-sm text-white/90">
                        <CheckCircle2 className="w-5 h-5 flex-shrink-0 mt-0.5" />
                        <span>{benefit}</span>
                      </li>
                    ))}
                  </ul>
                </Card>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Section 6: Интеграции */}
      <section className="py-28 bg-slate-50">
        <div className="container mx-auto px-8 lg:px-12">
          <motion.div 
            className="text-center mb-20 max-w-3xl mx-auto"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
          >
            <h2 className="text-4xl lg:text-5xl font-bold mb-6 tracking-tight text-slate-900">
              Интегрировано с государственными системами
            </h2>
          </motion.div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6 max-w-5xl mx-auto">
            {integrations.map((integration, idx) => (
              <motion.div
                key={idx}
                initial={{ opacity: 0, scale: 0.9 }}
                whileInView={{ opacity: 1, scale: 1 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: idx * 0.1 }}
              >
                <Card className="p-6 bg-white border border-slate-200 shadow-lg hover:shadow-xl transition-all">
                  <h3 className="text-xl font-bold text-slate-900 mb-2">{integration.name}</h3>
                  <p className="text-sm text-slate-600">{integration.description}</p>
                </Card>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Section 7: Преимущества */}
      <section className="py-28 bg-white">
        <div className="container mx-auto px-8 lg:px-12">
          <motion.div 
            className="text-center mb-20 max-w-3xl mx-auto"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
          >
            <h2 className="text-4xl lg:text-5xl font-bold mb-6 tracking-tight text-slate-900">
              Почему ЦПП меняет правила игры
            </h2>
          </motion.div>

          <div className="grid md:grid-cols-4 gap-8 max-w-6xl mx-auto">
            {metrics.map((metric, idx) => (
              <motion.div
                key={idx}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: idx * 0.1 }}
              >
                <Card className="p-8 bg-gradient-to-br from-blue-50 to-blue-100 border border-blue-200 text-center shadow-lg hover:shadow-xl transition-all">
                  <div className="text-5xl font-black text-blue-600 mb-2">{metric.number}</div>
                  <div className="text-xl font-bold text-slate-900 mb-1">{metric.label}</div>
                  <div className="text-sm text-slate-600">{metric.description}</div>
                </Card>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Section 8: Нормативная база */}
      <section className="py-28 bg-slate-50">
        <div className="container mx-auto px-8 lg:px-12">
          <motion.div 
            className="text-center mb-20 max-w-3xl mx-auto"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
          >
            <h2 className="text-4xl lg:text-5xl font-bold mb-6 tracking-tight text-slate-900">
              Нормативная база
            </h2>
          </motion.div>

          <div className="max-w-3xl mx-auto space-y-4">
            {regulations.map((regulation, idx) => (
              <motion.div
                key={idx}
                initial={{ opacity: 0, x: -30 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: idx * 0.1 }}
              >
                <Card className="p-6 bg-white border border-slate-200 shadow-lg hover:shadow-xl transition-all">
                  <a 
                    href={regulation.link}
                    className="flex items-center justify-between group"
                  >
                    <span className="text-lg font-semibold text-slate-900 group-hover:text-blue-600 transition-colors">
                      {regulation.title}
                    </span>
                    <ExternalLink className="w-5 h-5 text-slate-400 group-hover:text-blue-600 transition-colors" />
                  </a>
                </Card>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Section 9: Final CTA */}
      <section className="relative py-28 overflow-hidden bg-gradient-to-br from-slate-900 via-blue-900 to-slate-900">
        <div className="absolute inset-0 bg-[linear-gradient(to_right,#1e293b_1px,transparent_1px),linear-gradient(to_bottom,#1e293b_1px,transparent_1px)] bg-[size:4rem_4rem] opacity-10" />
        <div className="absolute top-0 right-0 w-[600px] h-[600px] bg-gradient-radial from-blue-500/20 via-transparent to-transparent blur-3xl" />
        
        <div className="relative container mx-auto px-8 lg:px-12">
          <motion.div 
            className="max-w-3xl mx-auto text-center"
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
          >
            <h2 className="text-4xl lg:text-5xl font-bold mb-6 tracking-tight text-white">
              Готовы ехать без бумаг?
            </h2>
            <div className="flex gap-4 justify-center mt-10">
              <Button 
                onClick={() => navigate("/login")}
                size="lg"
                className="bg-gradient-to-r from-emerald-500 to-emerald-600 hover:from-emerald-600 hover:to-emerald-700 text-white h-14 px-10 text-lg font-semibold shadow-2xl shadow-emerald-500/50 hover:shadow-emerald-500/60 transition-all border-0"
              >
                Подключиться
              </Button>
              <Button 
                onClick={() => navigate("/")}
                size="lg"
                variant="outline"
                className="h-14 px-10 text-lg font-semibold bg-white/10 backdrop-blur-sm border-white/20 text-white hover:bg-white/20 hover:border-white/30"
              >
                На главную
              </Button>
            </div>
          </motion.div>
        </div>
      </section>
    </div>
  );
}