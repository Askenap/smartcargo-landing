import { Card } from "../../components/ui/card";
import { FileCheck, MapPin, Shield, BarChart3, FileText, Ship } from "lucide-react";
import { motion } from "motion/react";

export default function AboutSmartCargo() {
  const modules = [
    {
      icon: FileCheck,
      title: "Цифровой паспорт перевозки",
      description: "Единая цифровая карточка перевозки с документами, статусами и QR-кодом",
      color: "from-blue-500 to-blue-600",
    },
    {
      icon: MapPin,
      title: "Трекинг перевозок",
      description: "Мониторинг движения груза в реальном времени из всех источников данных",
      color: "from-emerald-500 to-emerald-600",
    },
    {
      icon: Shield,
      title: "Верифицированный проход",
      description: "Цифровой контроль и ускоренное прохождение КПП без бумажных документов",
      color: "from-violet-500 to-violet-600",
    },
    {
      icon: BarChart3,
      title: "Единый центр мониторинга",
      description: "Аналитика и мониторинг грузопотоков на едином уровне",
      color: "from-cyan-500 to-cyan-600",
    },
    {
      icon: FileText,
      title: "Таможенные сервисы",
      description: "Интеграция с таможенными системами для автоматизации оформления",
      color: "from-amber-500 to-amber-600",
    },
    {
      icon: Ship,
      title: "Морпорт",
      description: "Управление морскими перевозками и портовыми операциями",
      color: "from-teal-500 to-teal-600",
    },
  ];

  const benefits = [
    "Цифровизацию перевозок",
    "Прозрачность перевозок",
    "Снижение бумажного документооборота",
    "Интеграцию с государственными системами",
    "Повышение безопасности",
  ];

  return (
    <div className="bg-gradient-to-b from-slate-50 via-white to-slate-50">
      {/* Hero Section */}
      <section className="relative py-28 bg-gradient-to-b from-white via-blue-50/30 to-blue-900 overflow-hidden">
        {/* Static gradient overlays */}
        <div className="absolute top-0 left-0 w-[800px] h-[800px] bg-gradient-radial from-blue-300/20 via-blue-200/10 to-transparent blur-3xl" />
        <div className="absolute bottom-0 right-0 w-[900px] h-[900px] bg-gradient-radial from-blue-800/30 via-blue-600/15 to-transparent blur-3xl" />
        <div className="absolute bottom-0 left-0 w-[700px] h-[700px] bg-gradient-radial from-indigo-700/20 via-transparent to-transparent blur-3xl" />
        
        <div className="relative container mx-auto px-8 lg:px-12">
          <motion.div 
            className="max-w-4xl mx-auto text-center text-white"
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
          >
            <motion.div
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: 0.2, duration: 0.6 }}
              className="inline-block px-4 py-2 bg-blue-500/20 backdrop-blur-sm border border-blue-400/30 rounded-full text-sm font-medium mb-8 text-[#034696]"
            >
              О платформе
            </motion.div>
            <h1 className="text-5xl lg:text-6xl font-bold mb-6 tracking-tight text-[#141313]">
              О системе Smart Cargo
            </h1>
            <p className="text-xl leading-relaxed text-[#282829]">
              Единая цифровая платформа управления грузоперевозками 
              всеми видами транспорта.
            </p>
          </motion.div>
        </div>
      </section>

      {/* About Section */}
      <section className="py-28">
        <div className="container mx-auto px-8 lg:px-12">
          <div className="max-w-4xl mx-auto">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6 }}
            >
              <Card className="p-10 bg-gradient-to-br from-blue-50/80 via-violet-50/60 to-indigo-50/80 backdrop-blur-sm border border-blue-200/50 shadow-xl">
                <h3 className="text-2xl font-bold mb-8 text-slate-900">Система обеспечивает:</h3>
                <ul className="space-y-5">
                  {benefits.map((benefit, idx) => (
                    <motion.li 
                      key={idx}
                      className="flex items-start gap-4"
                      initial={{ opacity: 0, x: -20 }}
                      whileInView={{ opacity: 1, x: 0 }}
                      viewport={{ once: true }}
                      transition={{ delay: idx * 0.1, duration: 0.5 }}
                    >
                      <div className="w-6 h-6 bg-blue-500/20 backdrop-blur-sm rounded-full flex items-center justify-center flex-shrink-0 mt-0.5 border border-blue-400/30">
                        <div className="w-2 h-2 bg-blue-600 rounded-full"></div>
                      </div>
                      <span className="text-xl leading-relaxed text-slate-600">{benefit}</span>
                    </motion.li>
                  ))}
                </ul>
              </Card>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Modules Section */}
      <section className="py-28 bg-white">
        <div className="container mx-auto px-8 lg:px-12">
          <motion.div 
            className="text-center mb-20 max-w-3xl mx-auto"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
          >
            <h2 className="text-4xl lg:text-5xl font-bold mb-6 tracking-tight text-slate-900">
              Модули системы
            </h2>
            <p className="text-lg text-slate-600 leading-relaxed">
              Комплексное решение для всех участников логистического процесса
            </p>
          </motion.div>
          
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6 max-w-6xl mx-auto">
            {modules.map((module, idx) => (
              <motion.div
                key={idx}
                initial={{ opacity: 0, scale: 0.9 }}
                whileInView={{ opacity: 1, scale: 1 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: idx * 0.1 }}
                whileHover={{ scale: 1.05, y: -5 }}
              >
                <Card className={`p-8 h-full bg-gradient-to-br ${module.color} border-0 shadow-xl hover:shadow-2xl transition-all duration-300 text-white`}>
                  <div className="w-14 h-14 bg-white/20 backdrop-blur-sm rounded-xl flex items-center justify-center mb-6">
                    <module.icon className="w-7 h-7 text-white" strokeWidth={2} />
                  </div>
                  <h3 className="text-lg font-bold mb-3 tracking-tight">
                    {module.title}
                  </h3>
                  <p className="text-sm text-white/90 leading-relaxed">
                    {module.description}
                  </p>
                </Card>
              </motion.div>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
}