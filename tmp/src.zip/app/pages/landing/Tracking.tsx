import { Card } from "../../components/ui/card";
import { Satellite, Radio, MapPin, Smartphone, Globe, CheckCircle } from "lucide-react";
import { motion } from "motion/react";

export default function Tracking() {
  const dataSources = [
    {
      icon: Satellite,
      title: "GPS/ГЛОНАСС трекеры",
      description: "Точное определение местоположения транспорта в режиме реального времени",
      color: "from-blue-500 to-blue-600",
    },
    {
      icon: Radio,
      title: "NCM (Единый центр мониторинга)",
      description: "Данные от государственной системы мониторинга транспорта",
      color: "from-emerald-500 to-emerald-600",
    },
    {
      icon: Smartphone,
      title: "Мобильное приложение водителя",
      description: "Обновление статусов и геолокация от водителя через приложение",
      color: "from-violet-500 to-violet-600",
    },
    {
      icon: MapPin,
      title: "Контрольные пункты",
      description: "Автоматическая фиксация прохождения через КПП и границы",
      color: "from-cyan-500 to-cyan-600",
    },
  ];

  const timelineSteps = [
    { status: "Перевозка создана", location: "Астана, Казахстан", time: "15 фев 2026, 09:00", active: false },
    { status: "Погрузка завершена", location: "Китай, Урумчи", time: "15 фев 2026, 14:30", active: false },
    { status: "В пути", location: "Хоргос (граница)", time: "16 фев 2026, 08:15", active: true },
    { status: "Ожидание проверки", location: "КПП Хоргос", time: "—", active: false },
    { status: "Прибытие", location: "Астана, Казахстан", time: "—", active: false },
  ];

  return (
    <div className="bg-gradient-to-b from-slate-50 via-white to-slate-50">
      {/* Hero Section */}
      <section className="relative py-28 bg-gradient-to-b from-white via-blue-50/30 to-blue-900 overflow-hidden">
        {/* Static gradient overlays */}
        <div className="absolute top-0 left-0 w-[800px] h-[800px] bg-gradient-radial from-blue-300/20 via-blue-200/10 to-transparent blur-3xl" />
        <div className="absolute top-0 left-0 w-[600px] h-[600px] bg-gradient-radial from-emerald-500/20 via-transparent to-transparent blur-3xl" />
        <div className="absolute bottom-0 right-0 w-[900px] h-[900px] bg-gradient-radial from-blue-800/30 via-blue-600/15 to-transparent blur-3xl" />
        <div className="absolute bottom-0 left-0 w-[700px] h-[700px] bg-gradient-radial from-indigo-700/20 via-transparent to-transparent blur-3xl" />
        
        <div className="relative container mx-auto px-8 lg:px-12">
          <motion.div 
            className="max-w-4xl mx-auto text-center"
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
          >
            <motion.div
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: 0.2, duration: 0.6 }}
              className="inline-block px-4 py-2 bg-emerald-500/20 backdrop-blur-sm border border-emerald-500/40 rounded-full text-sm font-medium text-emerald-900 mb-8"
            >
              Мониторинг в реальном времени
            </motion.div>
            <h1 className="text-5xl lg:text-6xl font-bold mb-6 tracking-tight text-slate-900">
              Трекинг перевозок
            </h1>
            <p className="text-xl text-slate-600 leading-relaxed">
              Отображение движения и статусов перевозки в одном интерфейсе.
            </p>
          </motion.div>
        </div>
      </section>

      {/* Data Sources Section */}
      <section className="py-28">
        <div className="container mx-auto px-8 lg:px-12">
          <motion.div 
            className="text-center mb-20 max-w-3xl mx-auto"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
          >
            <h2 className="text-4xl lg:text-5xl font-bold mb-6 tracking-tight text-slate-900">
              Источники данных
            </h2>
            <p className="text-lg text-slate-600 leading-relaxed">
              Агрегация информации из всех ключевых систем
            </p>
          </motion.div>
          
          <div className="grid md:grid-cols-2 gap-6 max-w-5xl mx-auto">
            {dataSources.map((source, idx) => (
              <motion.div
                key={idx}
                initial={{ opacity: 0, scale: 0.9 }}
                whileInView={{ opacity: 1, scale: 1 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: idx * 0.1 }}
                whileHover={{ scale: 1.03 }}
              >
                <Card className={`p-8 h-full bg-gradient-to-br ${source.color} border-0 shadow-xl hover:shadow-2xl transition-all duration-300 text-white`}>
                  <div className="w-14 h-14 bg-white/20 backdrop-blur-sm rounded-xl flex items-center justify-center mb-6">
                    <source.icon className="w-7 h-7 text-white" strokeWidth={2} />
                  </div>
                  <h3 className="text-xl font-bold mb-4 tracking-tight">
                    {source.title}
                  </h3>
                  <p className="text-sm text-white/90 leading-relaxed">
                    {source.description}
                  </p>
                </Card>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Interface Section */}
      <section className="py-28 bg-white">
        <div className="container mx-auto px-8 lg:px-12">
          <motion.div 
            className="text-center mb-20 max-w-3xl mx-auto"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
          >
            <h2 className="text-4xl lg:text-5xl font-bold mb-6 tracking-tight text-slate-900">
              Интерфейс трекинга
            </h2>
            <p className="text-lg text-slate-600 leading-relaxed">
              Визуализация маршрута и статусов в реальном времени
            </p>
          </motion.div>
          
          <div className="max-w-6xl mx-auto grid lg:grid-cols-2 gap-6 mb-6">
            {/* Map Placeholder */}
            <motion.div
              initial={{ opacity: 0, x: -30 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6 }}
            >
              <Card className="p-8 bg-gradient-to-br from-blue-500 to-blue-600 border-0 shadow-2xl text-white h-full">
                <h3 className="font-bold text-lg mb-6 flex items-center gap-2">
                  <Globe className="w-5 h-5" strokeWidth={2} />
                  Карта перемещения
                </h3>
                <div className="bg-white/10 backdrop-blur-sm rounded-2xl h-96 flex items-center justify-center border-2 border-white/20">
                  <div className="text-center">
                    <motion.div
                      animate={{ 
                        scale: [1, 1.1, 1],
                        opacity: [0.5, 1, 0.5]
                      }}
                      transition={{ duration: 2, repeat: Infinity }}
                    >
                      <MapPin className="w-16 h-16 mx-auto mb-4 text-white" strokeWidth={1.5} />
                    </motion.div>
                    <p className="text-sm font-semibold">Интерактивная карта маршрута</p>
                    <p className="text-xs mt-2 text-white/70">Отображение текущего местоположения груза</p>
                  </div>
                </div>
              </Card>
            </motion.div>

            {/* Timeline */}
            <motion.div
              initial={{ opacity: 0, x: 30 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6 }}
            >
              <Card className="p-8 bg-slate-50 border-2 border-slate-200 shadow-xl h-full">
                <h3 className="font-bold text-lg mb-6 flex items-center gap-2 text-slate-900">
                  <CheckCircle className="w-5 h-5 text-emerald-500" strokeWidth={2} />
                  Таймлайн статусов
                </h3>
                <div className="space-y-6">
                  {timelineSteps.map((step, idx) => (
                    <motion.div 
                      key={idx} 
                      className="flex gap-4"
                      initial={{ opacity: 0, x: -20 }}
                      whileInView={{ opacity: 1, x: 0 }}
                      viewport={{ once: true }}
                      transition={{ delay: idx * 0.1, duration: 0.5 }}
                    >
                      <div className="flex flex-col items-center">
                        <motion.div 
                          className={`w-3 h-3 rounded-full ${
                            step.active ? "bg-emerald-500 ring-4 ring-emerald-200" : "bg-slate-300"
                          }`}
                          animate={step.active ? {
                            scale: [1, 1.2, 1],
                          } : {}}
                          transition={step.active ? {
                            duration: 2,
                            repeat: Infinity
                          } : {}}
                        />
                        {idx < timelineSteps.length - 1 && (
                          <div className={`w-px h-16 ${
                            step.active ? "bg-emerald-300" : "bg-slate-200"
                          }`} />
                        )}
                      </div>
                      <div className="flex-1 pb-4">
                        <div className={`font-semibold text-sm mb-1.5 ${
                          step.active ? "text-slate-900" : "text-slate-500"
                        }`}>
                          {step.status}
                        </div>
                        <div className="text-xs text-slate-500">{step.location}</div>
                        <div className="text-xs text-slate-400 mt-1">{step.time}</div>
                      </div>
                    </motion.div>
                  ))}
                </div>
              </Card>
            </motion.div>
          </div>

          {/* Status Legend */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
          >
            <Card className="max-w-6xl mx-auto p-8 bg-gradient-to-br from-slate-800 to-slate-900 border-0 shadow-2xl text-white">
              <h3 className="font-bold text-base mb-6">
                Типы статусов
              </h3>
              <div className="grid md:grid-cols-3 gap-8">
                <div>
                  <div className="flex items-center gap-3 mb-2.5">
                    <div className="w-3 h-3 bg-emerald-500 rounded-full ring-4 ring-emerald-200" />
                    <span className="font-semibold text-sm">Завершено</span>
                  </div>
                  <p className="text-xs text-slate-300 leading-relaxed">Этап успешно пройден</p>
                </div>
                <div>
                  <div className="flex items-center gap-3 mb-2.5">
                    <motion.div 
                      className="w-3 h-3 bg-emerald-500 rounded-full ring-4 ring-emerald-200"
                      animate={{ scale: [1, 1.2, 1] }}
                      transition={{ duration: 2, repeat: Infinity }}
                    />
                    <span className="font-semibold text-sm">В процессе</span>
                  </div>
                  <p className="text-xs text-slate-300 leading-relaxed">Выполняется в данный момент</p>
                </div>
                <div>
                  <div className="flex items-center gap-3 mb-2.5">
                    <div className="w-3 h-3 bg-slate-500 rounded-full" />
                    <span className="font-semibold text-sm">Ожидается</span>
                  </div>
                  <p className="text-xs text-slate-300 leading-relaxed">Еще не начат</p>
                </div>
              </div>
            </Card>
          </motion.div>
        </div>
      </section>
    </div>
  );
}