import { useState } from "react";
import { useNavigate } from "react-router";
import { Button } from "../components/ui/button";
import { Card } from "../components/ui/card";
import { Shield, ArrowLeft } from "lucide-react";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "../components/ui/select";
import logo from "figma:asset/98e4a2aeb6ac2e19acbf98d0f7495391570dae6b.png";

export default function Login() {
  const navigate = useNavigate();
  const [userType, setUserType] = useState<"resident" | "non-resident">("resident");
  const [role, setRole] = useState<string>("");
  const [showRoleSelection, setShowRoleSelection] = useState(false);

  const roles = [
    { value: "carrier", label: "Собственник ТС / Логист", access: "Web+Mobile" },
    { value: "carrier-mobile", label: "Собственник ТС / Логист (Мобильная)", access: "Mobile App" },
    { value: "driver", label: "Водитель", access: "Mobile" },
    { value: "knb", label: "ПС КНБ", access: "Mobile (служебный)" },
    { value: "customs", label: "Таможенный инспектор КГД", access: "Mobile (служебный)" },
    { value: "svh", label: "Контроль СВХ", access: "Mobile (служебный)" },
    { value: "transport-control", label: "Инспектор транспортного контроля", access: "Mobile (служебный)" },
    { value: "vat-inspector", label: "КГД НДС/СНТ", access: "Web (служебный)" },
    { value: "management", label: "Руководство органов", access: "Web (АРМ)" },
    { value: "ncm", label: "Единый центр мониторинга", access: "Web (dashboard)" },
  ];

  const handleAuthClick = () => {
    setShowRoleSelection(true);
  };

  const handleLogin = () => {
    if (role === "carrier") {
      navigate("/carrier");
    } else if (role === "carrier-mobile") {
      navigate("/carrier-mobile");
    } else if (role === "driver") {
      navigate("/driver");
    } else if (["knb", "customs", "svh", "transport-control"].includes(role)) {
      navigate("/inspector");
    } else if (role === "ncm") {
      navigate("/ncm");
    } else if (role === "management") {
      navigate("/management");
    } else {
      navigate("/carrier");
    }
  };

  return (
    <div className="min-h-screen bg-background flex items-center justify-center p-6">
      <div className="w-full max-w-md">
        {/* Logo */}
        <div className="text-center mb-10">
          <img src={logo} alt="Smart Cargo" className="h-12 mx-auto mb-6" />
          <h1 className="text-2xl font-semibold mb-2 tracking-tight">Вход в систему</h1>
          <p className="text-sm text-muted-foreground">
            Цифровая платформа управления грузоперевозками
          </p>
        </div>

        {/* Back to Home */}
        <button
          onClick={() => navigate("/")}
          className="flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground mb-6 transition-colors"
        >
          <ArrowLeft className="w-4 h-4" strokeWidth={1.5} />
          <span>Вернуться на главную</span>
        </button>

        {!showRoleSelection ? (
          <Card className="p-8 border border-border">
            {/* Tabs */}
            <div className="flex gap-2 mb-8 bg-muted/50 p-1 rounded-lg">
              <button
                onClick={() => setUserType("resident")}
                className={`flex-1 py-2 px-4 rounded-md text-sm font-medium transition-all ${
                  userType === "resident"
                    ? "bg-card text-foreground shadow-sm"
                    : "text-muted-foreground hover:text-foreground"
                }`}
              >
                Резидент
              </button>
              <button
                onClick={() => setUserType("non-resident")}
                className={`flex-1 py-2 px-4 rounded-md text-sm font-medium transition-all ${
                  userType === "non-resident"
                    ? "bg-card text-foreground shadow-sm"
                    : "text-muted-foreground hover:text-foreground"
                }`}
              >
                Нерезидент
              </button>
            </div>

            {/* Auth Content */}
            <div className="space-y-6">
              {userType === "resident" ? (
                <div>
                  <div className="mb-6 text-center">
                    <div className="w-16 h-16 bg-primary/10 rounded-2xl flex items-center justify-center mx-auto mb-4">
                      <Shield className="w-8 h-8 text-primary" strokeWidth={1.5} />
                    </div>
                    <h3 className="font-semibold text-base mb-2">Авторизация для резидентов</h3>
                    <p className="text-sm text-muted-foreground leading-relaxed">
                      Войдите в систему используя электронную цифровую подпись через eGov Mobile
                    </p>
                  </div>
                  <Button
                    onClick={handleAuthClick}
                    className="w-full bg-primary hover:bg-primary/90 h-11 shadow-sm"
                  >
                    Войти через eGov Mobile
                  </Button>
                </div>
              ) : (
                <div>
                  <div className="mb-6 text-center">
                    <div className="w-16 h-16 bg-violet-500/10 rounded-2xl flex items-center justify-center mx-auto mb-4">
                      <Shield className="w-8 h-8 text-violet-500" strokeWidth={1.5} />
                    </div>
                    <h3 className="font-semibold text-base mb-2">Авторизация для нерезидентов</h3>
                    <p className="text-sm text-muted-foreground leading-relaxed">
                      Войдите в систему используя сервис KazETA
                    </p>
                  </div>
                  <Button
                    onClick={handleAuthClick}
                    className="w-full bg-violet-500 hover:bg-violet-600 h-11 shadow-sm"
                  >
                    Войти через KazETA
                  </Button>
                </div>
              )}
            </div>

            {/* Info */}
            <div className="mt-6 p-4 bg-muted/30 rounded-lg border border-border">
              <p className="text-xs text-muted-foreground text-center leading-relaxed">
                Для доступа к системе необходима авторизация через государственные сервисы 
                идентификации. Все данные передаются по защищенному каналу.
              </p>
            </div>
          </Card>
        ) : (
          <Card className="p-8 border border-border">
            <div className="mb-8 text-center">
              <h3 className="font-semibold text-base mb-2">
                Выберите роль
              </h3>
              <p className="text-sm text-muted-foreground">
                {userType === "resident" ? "Авторизация через eGov Mobile" : "Авторизация через KazETA"}
              </p>
            </div>

            <div className="space-y-6">
              <div>
                <label className="text-sm font-medium mb-2 block">
                  Роль в системе
                </label>
                <Select value={role} onValueChange={setRole}>
                  <SelectTrigger className="h-11">
                    <SelectValue placeholder="Выберите роль" />
                  </SelectTrigger>
                  <SelectContent>
                    {roles.map((r) => (
                      <SelectItem key={r.value} value={r.value}>
                        <div className="flex items-center justify-between gap-4">
                          <span className="text-sm">{r.label}</span>
                          <span className="text-xs text-muted-foreground">{r.access}</span>
                        </div>
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <Button
                onClick={handleLogin}
                disabled={!role}
                className="w-full bg-primary hover:bg-primary/90 h-11 shadow-sm disabled:opacity-50"
              >
                Войти
              </Button>

              <button
                onClick={() => setShowRoleSelection(false)}
                className="w-full text-sm text-muted-foreground hover:text-foreground transition-colors"
              >
                Назад к выбору метода авторизации
              </button>
            </div>
          </Card>
        )}
      </div>
    </div>
  );
}