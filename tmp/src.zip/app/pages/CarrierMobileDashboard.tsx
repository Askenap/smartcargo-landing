import { useState } from "react";
import { useNavigate } from "react-router";
import { Button } from "../components/ui/button";
import { 
  Truck, 
  Car, 
  Users, 
  FileText, 
  Menu as MenuIcon, 
  X, 
  Shield, 
  Brain, 
  Ship, 
  UserCircle, 
  LogOut,
  ChevronRight
} from "lucide-react";
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetTrigger } from "../components/ui/sheet";
import ShipmentsTab from "../components/ShipmentsTab";
import TransportTab from "../components/TransportTab";
import DriversTab from "../components/DriversTab";
import DocumentsTab from "../components/DocumentsTab";
import VerifiedPassTab from "../components/VerifiedPassTab";
import AIAssistantTab from "../components/AIAssistantTab";
import MaritimePortTab from "../components/MaritimePortTab";
import ProfileTab from "../components/ProfileTab";
import logo from "figma:asset/98e4a2aeb6ac2e19acbf98d0f7495391570dae6b.png";

type TabValue = "shipments" | "transport" | "drivers" | "documents" | "verified-pass" | "ai-assistant" | "maritime" | "profile";

export default function CarrierMobileDashboard() {
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState<TabValue>("shipments");
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  const handleLogout = () => {
    navigate("/");
  };

  const menuItems = [
    { value: "verified-pass" as TabValue, label: "Верифицированный проход", icon: Shield },
    { value: "ai-assistant" as TabValue, label: "AI-ассистент", icon: Brain },
    { value: "maritime" as TabValue, label: "Морпорт", icon: Ship },
    { value: "profile" as TabValue, label: "Профиль", icon: UserCircle },
  ];

  const bottomNavItems = [
    { value: "shipments" as TabValue, label: "Грузы", icon: Truck },
    { value: "transport" as TabValue, label: "Транспорт", icon: Car },
    { value: "drivers" as TabValue, label: "Водители", icon: Users },
    { value: "documents" as TabValue, label: "Документы", icon: FileText },
  ];

  const getHeaderTitle = () => {
    switch (activeTab) {
      case "shipments": return "Мои перевозки";
      case "transport": return "Транспорт";
      case "drivers": return "Водители";
      case "documents": return "Документы";
      case "verified-pass": return "Верификация";
      case "ai-assistant": return "AI-ассистент";
      case "maritime": return "Морпорт";
      case "profile": return "Профиль";
      default: return "Smart Cargo";
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col pb-20">
      {/* Mobile Header */}
      <header className="bg-white border-b border-slate-200 sticky top-0 z-50 px-4 h-14 flex items-center justify-between shadow-sm">
        <div className="flex items-center gap-3">
          <img src={logo} alt="Smart Cargo" className="h-6 w-auto" />
          <h1 className="text-base font-semibold text-slate-900">{getHeaderTitle()}</h1>
        </div>
        
        {/* User Avatar / Profile Shortcut */}
        <button 
          onClick={() => setActiveTab("profile")}
          className="w-8 h-8 rounded-full bg-slate-100 flex items-center justify-center border border-slate-200"
        >
          <UserCircle className="w-5 h-5 text-slate-600" />
        </button>
      </header>

      {/* Main Content */}
      <main className="flex-1 p-4 overflow-y-auto">
        {activeTab === "shipments" && <ShipmentsTab />}
        {activeTab === "transport" && <TransportTab />}
        {activeTab === "drivers" && <DriversTab />}
        {activeTab === "documents" && <DocumentsTab />}
        {activeTab === "verified-pass" && <VerifiedPassTab />}
        {activeTab === "ai-assistant" && <AIAssistantTab />}
        {activeTab === "maritime" && <MaritimePortTab />}
        {activeTab === "profile" && <ProfileTab />}
      </main>

      {/* Bottom Navigation Bar */}
      <nav className="fixed bottom-0 left-0 right-0 bg-white border-t border-slate-200 flex justify-around items-center h-16 z-50 safe-area-pb">
        {bottomNavItems.map((item) => {
          const Icon = item.icon;
          const isActive = activeTab === item.value;
          return (
            <button
              key={item.value}
              onClick={() => setActiveTab(item.value)}
              className={`flex flex-col items-center justify-center w-full h-full space-y-1 ${
                isActive ? "text-primary" : "text-slate-500 hover:text-slate-900"
              }`}
            >
              <Icon className={`w-5 h-5 ${isActive ? "stroke-[2.5px]" : "stroke-[1.5px]"}`} />
              <span className="text-[10px] font-medium">{item.label}</span>
            </button>
          );
        })}

        {/* Menu Item */}
        <Sheet open={isMenuOpen} onOpenChange={setIsMenuOpen}>
          <SheetTrigger asChild>
            <button
              className={`flex flex-col items-center justify-center w-full h-full space-y-1 ${
                menuItems.some(i => i.value === activeTab) ? "text-primary" : "text-slate-500 hover:text-slate-900"
              }`}
            >
              <MenuIcon className={`w-5 h-5 ${menuItems.some(i => i.value === activeTab) ? "stroke-[2.5px]" : "stroke-[1.5px]"}`} />
              <span className="text-[10px] font-medium">Меню</span>
            </button>
          </SheetTrigger>
          <SheetContent side="bottom" className="rounded-t-xl h-[80vh] flex flex-col p-0 gap-0">
            <SheetHeader className="p-6 border-b border-slate-100 text-left">
              <SheetTitle>Меню кабинета</SheetTitle>
              <div className="mt-2">
                <div className="font-medium text-slate-900">ТОО "Транс Логистик"</div>
                <div className="text-sm text-slate-500">БИН: 123456789012</div>
              </div>
            </SheetHeader>
            
            <div className="flex-1 overflow-y-auto p-4 space-y-2">
              <div className="text-xs font-semibold text-slate-400 uppercase tracking-wider mb-2 px-2">
                Сервисы
              </div>
              {menuItems.map((item) => {
                const Icon = item.icon;
                const isActive = activeTab === item.value;
                return (
                  <button
                    key={item.value}
                    onClick={() => {
                      setActiveTab(item.value);
                      setIsMenuOpen(false);
                    }}
                    className={`w-full flex items-center justify-between p-3 rounded-lg transition-colors ${
                      isActive ? "bg-primary/5 text-primary" : "text-slate-700 hover:bg-slate-50"
                    }`}
                  >
                    <div className="flex items-center gap-3">
                      <Icon className="w-5 h-5" />
                      <span className="font-medium">{item.label}</span>
                    </div>
                    <ChevronRight className="w-4 h-4 text-slate-400" />
                  </button>
                );
              })}

              <div className="border-t border-slate-100 my-4"></div>

              <button
                onClick={handleLogout}
                className="w-full flex items-center gap-3 p-3 rounded-lg text-red-600 hover:bg-red-50 transition-colors"
              >
                <LogOut className="w-5 h-5" />
                <span className="font-medium">Выйти из системы</span>
              </button>
            </div>
          </SheetContent>
        </Sheet>
      </nav>
    </div>
  );
}