import { useState } from "react";
import { useNavigate } from "react-router";
import { Button } from "../components/ui/button";
import { Truck, Car, Users, FileText, LogOut, Menu, X, LayoutDashboard, Shield, UserCircle, Brain, Ship, FileCheck } from "lucide-react";
import ShipmentsTab from "../components/ShipmentsTab";
import DashboardTab from "../components/DashboardTab";
import TransportTab from "../components/TransportTab";
import DriversTab from "../components/DriversTab";
import DocumentsTab from "../components/DocumentsTab";
import VerifiedPassTab from "../components/VerifiedPassTab";
import ProfileTab from "../components/ProfileTab";
import AIAssistantTab from "../components/AIAssistantTab";
import MaritimePortTab from "../components/MaritimePortTab";
import CustomsServicesTab from "../components/CustomsServicesTab";
import logo from "figma:asset/98e4a2aeb6ac2e19acbf98d0f7495391570dae6b.png";

type TabValue = "dashboard" | "shipments" | "transport" | "drivers" | "documents" | "verified-pass" | "ai-assistant" | "maritime" | "customs" | "profile";

export default function CarrierDashboard() {
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState<TabValue>("shipments");
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const handleLogout = () => {
    navigate("/");
  };

  const tabs = [
    { value: "shipments" as TabValue, label: "Перевозки", icon: Truck },
    { value: "transport" as TabValue, label: "Транспорт", icon: Car },
    { value: "drivers" as TabValue, label: "Водители", icon: Users },
    { value: "documents" as TabValue, label: "Документы", icon: FileText },
    { value: "verified-pass" as TabValue, label: "Верифицированный проход", icon: Shield },
    { value: "ai-assistant" as TabValue, label: "AI-ассистент", icon: Brain },
    { value: "maritime" as TabValue, label: "Морпорт", icon: Ship },
    { value: "profile" as TabValue, label: "Профиль", icon: UserCircle },
  ];

  return (
    <div className="min-h-screen bg-background flex flex-col">
      {/* Header - Desktop & Mobile */}
      <header className="bg-white/80 backdrop-blur-md border-b border-border sticky top-0 z-50">
        <div className="container mx-auto px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            {/* Logo */}
            <div className="flex items-center gap-3">
              <img src={logo} alt="Smart Cargo" className="h-8" />
              <div className="hidden sm:block">
                <h1 className="text-sm font-semibold tracking-tight">Кабинет перевозчика</h1>
                <p className="text-xs text-muted-foreground">Smart Cargo</p>
              </div>
            </div>

            {/* Desktop Menu */}
            <div className="hidden md:flex items-center gap-4">
              <div className="text-right">
                <div className="text-sm font-medium">ТОО "Транс Логистик"</div>
                <div className="text-xs text-muted-foreground">БИН: 123456789012</div>
              </div>
              <Button onClick={handleLogout} variant="ghost" className="text-muted-foreground hover:text-foreground h-9">
                <LogOut className="w-4 h-4 mr-2" strokeWidth={1.5} />
                Выход
              </Button>
            </div>

            {/* Mobile Menu Button */}
            <button onClick={() => setMobileMenuOpen(!mobileMenuOpen)} className="md:hidden p-2">
              {mobileMenuOpen ? <X className="w-5 h-5 text-muted-foreground" strokeWidth={1.5} /> : <Menu className="w-5 h-5 text-muted-foreground" strokeWidth={1.5} />}
            </button>
          </div>

          {/* Mobile Menu */}
          {mobileMenuOpen && (
            <div className="md:hidden py-4 border-t border-border">
              <div className="mb-4 pb-4 border-b border-border">
                <div className="text-sm font-medium">ТОО "Транс Логистик"</div>
                <div className="text-xs text-muted-foreground">БИН: 123456789012</div>
              </div>
              <Button onClick={handleLogout} variant="ghost" className="w-full justify-start text-slate-600">
                <LogOut className="w-4 h-4 mr-2" />
                Выход
              </Button>
            </div>
          )}
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-6 lg:px-8 py-8 flex-1">
        <div className="flex flex-col md:flex-row gap-6">
          {/* Desktop Sidebar - Left 20% */}
          <aside className="hidden md:block md:w-1/5 md:min-w-[240px]">
            <nav className="bg-card rounded-lg border border-border overflow-hidden sticky top-24">
              {tabs.map((tab) => {
                const Icon = tab.icon;
                const isActive = activeTab === tab.value;
                return (
                  <button
                    key={tab.value}
                    onClick={() => setActiveTab(tab.value)}
                    className={`w-full flex items-center gap-3 px-4 py-3.5 text-left transition-all border-b border-border last:border-b-0 ${
                      isActive ? "bg-primary text-white" : "text-foreground hover:bg-muted"
                    }`}
                  >
                    <Icon className="w-4 h-4 flex-shrink-0" strokeWidth={1.5} />
                    <span className="font-medium text-sm">{tab.label}</span>
                  </button>
                );
              })}
            </nav>
          </aside>

      {/* Mobile Tabs - Scrollable and Sticky */}
      <div className="md:hidden sticky top-16 z-40 bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60 border-b border-border -mx-0 px-4 py-2 overflow-x-auto scrollbar-hide mb-4">
        <div className="flex gap-2">
          {tabs.map((tab) => {
            const Icon = tab.icon;
            const isActive = activeTab === tab.value;
            return (
              <button
                key={tab.value}
                onClick={() => setActiveTab(tab.value)}
                className={`flex items-center gap-2 px-3 py-2 whitespace-nowrap rounded-full transition-all text-sm font-medium border ${
                  isActive ? "bg-primary text-primary-foreground border-primary" : "bg-card text-muted-foreground border-border hover:bg-muted"
                }`}
              >
                <Icon className="w-4 h-4" strokeWidth={1.5} />
                <span>{tab.label}</span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Content Area - Right 80% */}
      <div className="flex-1 md:w-4/5">
            {activeTab === "dashboard" && (
              <div className="bg-card rounded-lg border border-border p-8">
                <DashboardTab />
              </div>
            )}

            {activeTab === "shipments" && (
              <div className="bg-card rounded-lg border border-border p-8">
                <ShipmentsTab />
              </div>
            )}

            {activeTab === "transport" && (
              <div className="bg-card rounded-lg border border-border p-8">
                <TransportTab />
              </div>
            )}

            {activeTab === "drivers" && (
              <div className="bg-card rounded-lg border border-border p-8">
                <DriversTab />
              </div>
            )}

            {activeTab === "documents" && (
              <div className="bg-card rounded-lg border border-border p-8">
                <DocumentsTab />
              </div>
            )}

            {activeTab === "verified-pass" && (
              <div className="bg-card rounded-lg border border-border p-8">
                <VerifiedPassTab />
              </div>
            )}

            {activeTab === "ai-assistant" && (
              <div className="bg-card rounded-lg border border-border p-8">
                <AIAssistantTab />
              </div>
            )}

            {activeTab === "maritime" && (
              <div className="bg-card rounded-lg border border-border p-8">
                <MaritimePortTab />
              </div>
            )}

            {activeTab === "profile" && (
              <div className="bg-card rounded-lg border border-border p-8">
                <ProfileTab />
              </div>
            )}
          </div>
        </div>
      </main>

      {/* Footer */}
      <footer className="py-8 border-t border-border bg-white mt-auto">
        <div className="container mx-auto px-6 lg:px-8 text-center text-sm text-muted-foreground">
          <p>© 2026 Smart Cargo - Республика Казахстан</p>
        </div>
      </footer>
    </div>
  );
}