import { useState, useEffect } from "react";
import { useNavigate } from "react-router";
import { Button } from "../components/ui/button";
import { Card } from "../components/ui/card";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "../components/ui/dialog";
import { 
  Truck, 
  MapPin, 
  FileText, 
  CheckCircle, 
  LogOut, 
  QrCode, 
  User, 
  RefreshCw, 
  ChevronRight, 
  ChevronDown,
  Shield, 
  AlertCircle,
  FlaskConical,
  Scale,
  Thermometer,
  FileCheck,
  AlertTriangle,
  Ban,
  ScanBarcode,
  ArrowRight,
  Clock,
  HelpCircle
} from "lucide-react";
import QRCode from "react-qr-code";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "../components/ui/accordion";
import logo from "figma:asset/98e4a2aeb6ac2e19acbf98d0f7495391570dae6b.png";

export default function DriverDashboard() {
  const navigate = useNavigate();
  const [showQR, setShowQR] = useState(false);
  const [showOTP, setShowOTP] = useState(false);
  const [otpCode, setOtpCode] = useState("");
  const [otpTimer, setOtpTimer] = useState(0);

  const handleLogout = () => {
    navigate("/");
  };

  const handleGenerateOTP = () => {
    setShowQR(false);
    const code = Math.floor(100000 + Math.random() * 900000).toString();
    setOtpCode(code);
    setOtpTimer(300); // 5 minutes
    setShowOTP(true);
  };

  useEffect(() => {
    let interval: NodeJS.Timeout;
    if (otpTimer > 0) {
      interval = setInterval(() => {
        setOtpTimer((prev) => prev - 1);
      }, 1000);
    }
    return () => clearInterval(interval);
  }, [otpTimer]);

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  const currentShipment = {
    id: "TR-2026-000125",
    route: "Китайская Народная Республика → Российская Федерация",
    vehicle: "898UJY01",
    vehicleType: "Седельный тягач",
    status: "blocked",
    cargo: {
      weight: "18500.00",
      places: "43",
      quantity: "1",
      value: "98000.00"
    }
  };

  const steps = [
    { id: 1, title: "Транзитная декларация", status: "pending", icon: FileText },
    { id: 2, title: "Санитарный контроль", status: "pending", icon: Shield },
    { id: 3, title: "Ветеринарный контроль", status: "pending", icon: Thermometer },
    { id: 4, title: "Фито-санитарный контроль", subtitle: "На проверке", status: "processing", icon: FlaskConical },
    { id: 5, title: "Транспортный контроль", status: "completed", icon: CheckCircle },
    { id: 6, title: "ИДК сканирование", status: "completed", icon: ScanBarcode },
    { id: 7, title: "Предварительное информирование", subtitle: "Прибыл", status: "processing", icon: Shield },
  ];

  const documents = [
    { title: "Транзитная декларация", status: "valid" },
    { title: "Ветеринарный сертификат", status: "valid" },
    { title: "Фитосанитарный сертификат", status: "valid" },
    { title: "Книжка МДП", status: "valid" },
    { title: "Инвойс к договору", status: "missing" },
    { title: "Страховой полис", status: "missing" },
    { title: "Страховой полис", status: "missing" },
  ];

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 pb-10 font-sans">
      {/* Header */}
      <header className="bg-white px-4 py-3 sticky top-0 z-50 flex items-center justify-between border-b border-slate-100">
        <div className="flex items-center gap-3">
          <button onClick={() => navigate(-1)} className="p-1 -ml-1">
             <ChevronRight className="w-6 h-6 rotate-180 text-slate-800" />
          </button>
          <div className="flex items-center gap-3">
             <div className="w-8 h-8 rounded-full bg-slate-100 flex items-center justify-center text-slate-500">
                <User className="w-5 h-5" />
             </div>
             <div>
                <h1 className="text-sm font-bold leading-tight">Алпаков Т.Б.</h1>
                <p className="text-[10px] text-slate-400 font-medium">Водитель • 123 ABC 01</p>
             </div>
          </div>
        </div>
        <button className="text-slate-400">
            <LogOut className="w-5 h-5" onClick={handleLogout} />
        </button>
      </header>

      <main className="p-4 space-y-6">
        {/* QR Button */}
        <div className="space-y-2">
            <Button 
                onClick={() => setShowQR(true)}
                className="w-full h-12 bg-blue-600 hover:bg-blue-700 text-white rounded-lg shadow-sm text-sm font-semibold flex items-center justify-center gap-2"
            >
                <QrCode className="w-5 h-5" />
                QR текущего рейса
            </Button>
            <p className="text-[10px] text-center text-slate-500 max-w-[250px] mx-auto leading-tight">
                Активный рейс: {currentShipment.route}
            </p>
        </div>

        {/* Trip Details */}
        <div>
            <div className="flex items-center justify-between mb-2">
                <h2 className="text-xs font-bold uppercase tracking-wider text-slate-500">Детали рейса</h2>
                <button className="text-[10px] text-blue-600 font-medium flex items-center gap-1">
                    <RefreshCw className="w-3 h-3" />
                    Обновить
                </button>
            </div>
            
            <Card className="p-5 border-none shadow-sm rounded-2xl">
                <div className="flex items-center justify-between mb-4">
                    <div className="text-sm font-bold text-slate-900 w-[45%] leading-tight">
                        Китайская Народная Республика
                    </div>
                    <ArrowRight className="w-4 h-4 text-slate-400 flex-shrink-0" />
                    <div className="text-sm font-bold text-slate-900 w-[45%] text-right leading-tight">
                        Российская Федерация
                    </div>
                </div>

                <div className="bg-blue-600 rounded-xl p-4 text-white flex items-center gap-4">
                    <div className="w-10 h-10 rounded-full bg-white/20 flex items-center justify-center flex-shrink-0">
                        <Truck className="w-5 h-5 text-white" />
                    </div>
                    <div>
                        <div className="text-[10px] opacity-70 uppercase tracking-wide font-medium">Транспортное средство</div>
                        <div className="text-lg font-bold tracking-wide">{currentShipment.vehicle}</div>
                        <div className="text-[10px] opacity-70 mt-0.5">{currentShipment.vehicleType} •</div>
                    </div>
                </div>
            </Card>
        </div>

        {/* Statuses */}
        <div>
             <h2 className="text-xs font-bold uppercase tracking-wider text-slate-500 mb-3">Статусы прохождения</h2>
             
             <Card className="p-5 border-none shadow-sm rounded-2xl space-y-6">
                {/* Alert Box */}
                <div className="bg-red-50 border border-red-100 rounded-xl p-4 flex items-center gap-4">
                    <div className="w-10 h-10 rounded-full bg-red-500 flex items-center justify-center flex-shrink-0 shadow-sm shadow-red-200">
                        <Ban className="w-6 h-6 text-white" />
                    </div>
                    <div>
                        <div className="text-red-600 font-bold text-sm">Пропуск запрещен</div>
                        <div className="text-red-500 text-xs font-medium">Требуется проверка</div>
                    </div>
                </div>

                {/* Stepper */}
                <div className="relative pl-2 space-y-0">
                    {/* Vertical Line */}
                    <div className="absolute left-[27px] top-4 bottom-4 w-[2px] bg-slate-100 z-0"></div>

                    {steps.map((step, index) => (
                        <div key={step.id} className="relative z-10 flex items-start gap-4 py-3 first:pt-0 last:pb-0">
                             <div className={`w-10 h-10 rounded-full flex items-center justify-center flex-shrink-0 border-2 bg-white
                                ${step.status === 'completed' ? 'border-green-500 text-green-500' : 
                                  step.status === 'processing' ? 'border-blue-500 text-blue-500' : 
                                  'border-slate-200 text-slate-300'}`}>
                                {step.status === 'completed' ? <CheckCircle className="w-5 h-5" /> : <step.icon className="w-5 h-5" />}
                             </div>
                             <div className="flex-1 pt-2">
                                <div className="flex items-start justify-between gap-2">
                                    <div className={`font-medium leading-tight ${step.status === 'pending' ? 'text-slate-500' : step.status === 'processing' ? 'text-blue-600' : 'text-green-600'} text-[11px]`}>
                                        {step.title}
                                    </div>
                                    {step.status === 'processing' && (
                                        <span className="bg-blue-500 text-white px-2 py-0.5 rounded-full font-medium whitespace-nowrap flex-shrink-0 text-[8px]">
                                            В процессе
                                        </span>
                                    )}
                                </div>
                                {step.subtitle && (
                                    <div className="text-blue-400 mt-1 text-[10px]">{step.subtitle}</div>
                                )}
                             </div>
                        </div>
                    ))}
                </div>
             </Card>
        </div>

        {/* Cargo Info */}
        <div>
            <h2 className="text-xs font-bold uppercase tracking-wider text-slate-500 mb-3 text-slate-500">Информация о грузе</h2>
            <div className="grid grid-cols-2 gap-2">
                <Card className="p-3 border-none shadow-sm rounded-xl">
                    <div className="text-[10px] text-slate-400 mb-1">Вес</div>
                    <div className="text-sm font-bold text-slate-900">{currentShipment.cargo.weight} кг</div>
                </Card>
                <Card className="p-3 border-none shadow-sm rounded-xl">
                    <div className="text-[10px] text-slate-400 mb-1">Мест</div>
                    <div className="text-sm font-bold text-slate-900">{currentShipment.cargo.places}</div>
                </Card>
                <Card className="p-3 border-none shadow-sm rounded-xl">
                    <div className="text-[10px] text-slate-400 mb-1">Количество</div>
                    <div className="text-sm font-bold text-slate-900">{currentShipment.cargo.quantity}</div>
                </Card>
                <Card className="p-3 border-none shadow-sm rounded-xl">
                    <div className="text-[10px] text-slate-400 mb-1">Стоимость</div>
                    <div className="text-sm font-bold text-slate-900">${currentShipment.cargo.value}</div>
                </Card>
            </div>
        </div>

        {/* Documents */}
        <div>
             <h2 className="text-xs font-bold uppercase tracking-wider text-slate-500 mb-3">Документы</h2>
             <div className="space-y-2">
                {documents.map((doc, idx) => (
                    <Card key={idx} className="p-3 flex items-center gap-3 border-none shadow-sm rounded-xl">
                        <div className="flex-1 flex items-center gap-3 overflow-hidden text-left">
                            <div className={`w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0 
                                ${doc.status === 'valid' ? 'bg-green-100 text-green-600' : 'bg-slate-100 text-slate-400'}`}>
                                {doc.status === 'valid' ? <CheckCircle className="w-5 h-5" /> : <AlertTriangle className="w-5 h-5" />}
                            </div>
                            <span className="text-xs font-bold text-slate-900 truncate">{doc.title}</span>
                        </div>
                        <div className="flex items-center gap-2 flex-shrink-0">
                            <span className={`text-[10px] px-2 py-1 rounded-full font-medium
                                ${doc.status === 'valid' ? 'bg-green-100 text-green-700' : 'bg-slate-100 text-slate-500'}`}>
                                {doc.status === 'valid' ? 'Действителен' : 'Отсутствует'}
                            </span>
                            <ChevronRight className="w-4 h-4 text-slate-300" />
                        </div>
                    </Card>
                ))}

                <Card className="border-none shadow-sm rounded-xl overflow-hidden">
                    <Accordion type="single" collapsible className="w-full">
                        <AccordionItem value="item-1" className="border-none">
                            <AccordionTrigger className="px-3 py-3 hover:no-underline hover:bg-slate-50">
                                <div className="flex items-center gap-3">
                                    <div className="w-8 h-8 rounded-lg bg-blue-100 flex items-center justify-center text-blue-600">
                                        <FileText className="w-4 h-4" />
                                    </div>
                                    <div className="text-left">
                                        <div className="text-xs font-bold text-slate-900">Прочие виды документов</div>
                                        <div className="text-[10px] text-slate-400">5 документ(ов)</div>
                                    </div>
                                </div>
                            </AccordionTrigger>
                            <AccordionContent className="px-3 pb-3 pt-0">
                                <div className="pl-11 space-y-2 pt-2">
                                    <div className="text-xs text-slate-600">Дополнительный сертификат</div>
                                    <div className="text-xs text-slate-600">Копия инвойса</div>
                                </div>
                            </AccordionContent>
                        </AccordionItem>
                    </Accordion>
                </Card>
             </div>
        </div>
      </main>

      {/* QR Dialog */}
      <Dialog open={showQR} onOpenChange={setShowQR}>
        <DialogContent className="max-w-[320px] rounded-2xl p-0 overflow-hidden">
          <div className="p-6 pb-4 text-center">
            <h3 className="text-lg font-bold text-slate-900 mb-1">Цифровой паспорт</h3>
            <p className="text-xs text-slate-500">Предъявите QR-код инспектору</p>
          </div>
          
          <div className="flex flex-col items-center gap-6 px-6 pb-6">
            <div className="relative">
                <div className="absolute -inset-1 bg-gradient-to-r from-blue-400 to-sky-400 rounded-2xl opacity-20 blur-sm"></div>
                <div className="relative bg-white p-4 rounded-xl border border-slate-200 shadow-sm">
                    <QRCode
                        value={JSON.stringify({
                        type: "SMART_CARGO_SHIPMENT",
                        id: currentShipment.id,
                        })}
                        size={200}
                    />
                </div>
            </div>
            
            <div className="text-center w-full">
               <div className="text-lg font-bold text-blue-600 tracking-tight">{currentShipment.id}</div>
               <div className="text-xs text-slate-400 font-medium uppercase tracking-wider mt-0.5">{currentShipment.vehicle}</div>
            </div>

            <div className="w-full space-y-3">
                <Button onClick={() => setShowQR(false)} className="w-full h-11 bg-slate-900 hover:bg-slate-800 text-white rounded-xl font-medium">
                    Закрыть
                </Button>
                
                <button 
                    onClick={handleGenerateOTP}
                    className="w-full flex items-center justify-center gap-2 text-xs font-medium text-slate-500 hover:text-blue-600 transition-colors py-1"
                >
                    <HelpCircle className="w-3.5 h-3.5" />
                    Проблема со сканированием?
                </button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* OTP Dialog */}
      <Dialog open={showOTP} onOpenChange={setShowOTP}>
        <DialogContent className="max-w-[320px] rounded-2xl p-0 overflow-hidden">
           <div className="bg-slate-900 p-6 text-center text-white">
              <h3 className="text-lg font-bold mb-1">Альтернативный код</h3>
              <p className="text-xs text-slate-400 opacity-80">
                 Сообщите этот код сотруднику пункта пропуска для ручной верификации
              </p>
           </div>
           
           <div className="p-6 flex flex-col items-center">
               <div className="mb-6 w-full bg-slate-50 border border-slate-100 rounded-xl p-6 text-center">
                  <div className="text-4xl font-mono font-bold tracking-[0.2em] text-slate-900 pl-2">
                     {otpCode.slice(0, 3)} {otpCode.slice(3)}
                  </div>
               </div>

               <div className="flex items-center gap-2 text-sm font-medium text-blue-600 bg-blue-50 px-3 py-1.5 rounded-full mb-6">
                  <Clock className="w-4 h-4" />
                  <span>{formatTime(otpTimer)}</span>
               </div>

               <Button onClick={() => setShowOTP(false)} variant="outline" className="w-full h-11 rounded-xl border-slate-200 text-slate-700 font-medium">
                  Закрыть
               </Button>
           </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}