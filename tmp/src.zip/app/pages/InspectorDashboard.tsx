import { useState } from "react";
import { useNavigate } from "react-router";
import { Button } from "../components/ui/button";
import { Input } from "../components/ui/input";
import { Card } from "../components/ui/card";
import { Truck, QrCode, Camera, CheckCircle, XCircle, LogOut, Upload } from "lucide-react";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "../components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from "../components/ui/dialog";
import logo from "figma:asset/98e4a2aeb6ac2e19acbf98d0f7495391570dae6b.png";

interface ChecklistItem {
  id: string;
  label: string;
  status: "ok" | "fail" | "pending";
  comment?: string;
}

export default function InspectorDashboard() {
  const navigate = useNavigate();
  const [scannedTripId, setScannedTripId] = useState<string | null>(null);
  const [showCheckCard, setShowCheckCard] = useState(false);
  const [checklistItems, setChecklistItems] = useState<ChecklistItem[]>([
    { id: "1", label: "Водительское удостоверение", status: "pending" },
    { id: "2", label: "Путевой лист", status: "pending" },
    { id: "3", label: "Регистрация ТС", status: "pending" },
    { id: "4", label: "Груз соответствует документам", status: "pending" },
    { id: "5", label: "Весогабаритные параметры", status: "pending" },
  ]);
  const [inspectionComment, setInspectionComment] = useState("");
  const [inspectionResult, setInspectionResult] = useState<"approved" | "rejected" | null>(null);
  const [photos, setPhotos] = useState<string[]>([]);

  const handleScanQR = () => {
    // Simulate QR scan
    const mockTripId = "TR-2026-000125";
    setScannedTripId(mockTripId);
    setShowCheckCard(true);
  };

  const handleChecklistChange = (id: string, status: "ok" | "fail") => {
    setChecklistItems((items) =>
      items.map((item) => (item.id === id ? { ...item, status } : item))
    );
  };

  const handleAddPhoto = () => {
    // Simulate photo upload
    setPhotos([...photos, `photo_${Date.now()}.jpg`]);
  };

  const handleSubmitInspection = () => {
    const allOk = checklistItems.every((item) => item.status === "ok");
    setInspectionResult(allOk ? "approved" : "rejected");
  };

  const handleLogout = () => {
    navigate("/");
  };

  return (
    <div className="min-h-screen bg-slate-50">
      {/* Header */}
      <header className="bg-white border-b border-slate-200 sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <img src={logo} alt="Smart Cargo" className="h-10" />
              <div>
                <h1 className="font-semibold text-slate-900">Служебный интерфейс</h1>
                <p className="text-xs text-slate-500">Инспектор КПП</p>
              </div>
            </div>
            <Button onClick={handleLogout} variant="ghost" size="sm">
              <LogOut className="w-4 h-4 mr-2" />
              Выход
            </Button>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-8">
        <div className="max-w-4xl mx-auto space-y-6">
          {/* Scan QR Section */}
          <Card className="p-8">
            <div className="text-center">
              <QrCode className="w-24 h-24 mx-auto mb-4 text-sky-500" />
              <h2 className="text-xl font-semibold mb-2 text-slate-900">Сканировать QR-код перевозки</h2>
              <p className="text-slate-600 mb-6">
                Наведите камеру на QR-код для получения данных о перевозке
              </p>
              <Button onClick={handleScanQR} size="lg" className="bg-sky-500 hover:bg-sky-600">
                <QrCode className="w-5 h-5 mr-2" />
                Сканировать QR
              </Button>
            </div>
          </Card>

          {/* Recent Inspections */}
          <Card className="p-6">
            <h3 className="font-semibold text-lg mb-4 text-slate-900">Последние проверки</h3>
            <div className="space-y-3">
              {[
                { id: "TR-2026-000124", time: "2 часа назад", result: "approved" },
                { id: "TR-2026-000123", time: "5 часов назад", result: "approved" },
                { id: "TR-2026-000122", time: "1 день назад", result: "rejected" },
              ].map((inspection, idx) => (
                <div
                  key={idx}
                  className="flex items-center justify-between p-3 bg-slate-50 rounded-lg"
                >
                  <div>
                    <div className="font-medium text-slate-900">{inspection.id}</div>
                    <div className="text-sm text-slate-500">{inspection.time}</div>
                  </div>
                  <div>
                    {inspection.result === "approved" ? (
                      <CheckCircle className="w-5 h-5 text-green-600" />
                    ) : (
                      <XCircle className="w-5 h-5 text-red-600" />
                    )}
                  </div>
                </div>
              ))}
            </div>
          </Card>
        </div>
      </main>

      {/* Check Card Dialog */}
      <Dialog open={showCheckCard} onOpenChange={setShowCheckCard}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Карточка проверки</DialogTitle>
            <DialogDescription className="sr-only">
              Проверка перевозки с чек-листом документов и параметров
            </DialogDescription>
          </DialogHeader>

          {scannedTripId && (
            <div className="space-y-6">
              {/* Trip Info */}
              <div className="bg-sky-50 border border-sky-200 rounded-lg p-4">
                <div className="text-sm text-slate-600 mb-1">ID перевозки</div>
                <div className="font-semibold text-lg text-slate-900">{scannedTripId}</div>
                <div className="text-sm text-slate-600 mt-2">
                  Маршрут: Китай, г. Урумчи → Кыргызстан, г. Бишкек
                </div>
                <div className="text-sm text-slate-600">ТС: KZ 123 AB 01</div>
                <div className="text-sm text-slate-600">Водитель: Иванов Иван Иванович</div>
              </div>

              {/* Checklist */}
              <div>
                <h4 className="font-medium text-slate-900 mb-3">Чек-лист документов</h4>
                <div className="space-y-2">
                  {checklistItems.map((item) => (
                    <div key={item.id} className="flex items-center justify-between p-3 bg-slate-50 rounded-lg">
                      <span className="text-sm text-slate-900">{item.label}</span>
                      <div className="flex gap-2">
                        <Button
                          size="sm"
                          variant={item.status === "ok" ? "default" : "outline"}
                          className={item.status === "ok" ? "bg-green-600 hover:bg-green-700" : ""}
                          onClick={() => handleChecklistChange(item.id, "ok")}
                        >
                          <CheckCircle className="w-4 h-4" />
                        </Button>
                        <Button
                          size="sm"
                          variant={item.status === "fail" ? "default" : "outline"}
                          className={item.status === "fail" ? "bg-red-600 hover:bg-red-700" : ""}
                          onClick={() => handleChecklistChange(item.id, "fail")}
                        >
                          <XCircle className="w-4 h-4" />
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Photos */}
              <div>
                <h4 className="font-medium text-slate-900 mb-3">Фотоматериалы</h4>
                <div className="flex flex-wrap gap-2 mb-3">
                  {photos.map((photo, idx) => (
                    <div key={idx} className="w-20 h-20 bg-slate-200 rounded flex items-center justify-center">
                      <Camera className="w-6 h-6 text-slate-400" />
                    </div>
                  ))}
                </div>
                <Button onClick={handleAddPhoto} variant="outline" size="sm">
                  <Upload className="w-4 h-4 mr-2" />
                  Добавить фото
                </Button>
              </div>

              {/* Comment */}
              <div>
                <label className="text-sm font-medium text-slate-900 mb-2 block">Комментарий</label>
                <textarea
                  value={inspectionComment}
                  onChange={(e) => setInspectionComment(e.target.value)}
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-sky-500 min-h-[100px]"
                  placeholder="Введите комментарий к проверке..."
                />
              </div>

              {/* Result */}
              {inspectionResult && (
                <div className={`p-4 rounded-lg ${
                  inspectionResult === "approved"
                    ? "bg-green-50 border border-green-200"
                    : "bg-red-50 border border-red-200"
                }`}>
                  <div className="flex items-center gap-2">
                    {inspectionResult === "approved" ? (
                      <CheckCircle className="w-6 h-6 text-green-600" />
                    ) : (
                      <XCircle className="w-6 h-6 text-red-600" />
                    )}
                    <div>
                      <div className="font-medium text-slate-900">
                        {inspectionResult === "approved" ? "Проверка пройдена" : "Проверка не пройдена"}
                      </div>
                      <div className="text-sm text-slate-600 mt-1">
                        {inspectionResult === "approved"
                          ? "Все документы в порядке, можно продолжать маршрут"
                          : "Обнаружены несоответствия, требуется устранение"}
                      </div>
                    </div>
                  </div>
                </div>
              )}
            </div>
          )}

          <DialogFooter>
            <Button variant="outline" onClick={() => setShowCheckCard(false)}>
              Отменить
            </Button>
            <Button
              onClick={handleSubmitInspection}
              className="bg-sky-500 hover:bg-sky-600"
            >
              Завершить проверку
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}