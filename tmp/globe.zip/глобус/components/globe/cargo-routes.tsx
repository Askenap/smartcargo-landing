"use client"

import { useRef, useMemo } from "react"
import { useFrame } from "@react-three/fiber"
import * as THREE from "three"

interface RouteData {
  from: [number, number]
  to: [number, number]
  color: string
}

const ROUTES: RouteData[] = [
  { from: [40.7, -74.0], to: [51.5, -0.1], color: "#e8833a" },
  { from: [31.2, 121.5], to: [35.7, 139.7], color: "#4db8ff" },
  { from: [1.3, 103.8], to: [55.8, 37.6], color: "#e8833a" },
  { from: [22.3, 114.2], to: [-33.9, 18.4], color: "#4db8ff" },
  { from: [51.5, -0.1], to: [25.3, 55.3], color: "#e8833a" },
  { from: [35.7, 139.7], to: [-23.5, -46.6], color: "#4db8ff" },
  { from: [48.9, 2.4], to: [40.7, -74.0], color: "#e8833a" },
  { from: [55.8, 37.6], to: [39.9, 116.4], color: "#4db8ff" },
  { from: [25.3, 55.3], to: [19.1, 72.9], color: "#e8833a" },
  { from: [-33.9, 151.2], to: [1.3, 103.8], color: "#4db8ff" },
]

function latLonToVector3(lat: number, lon: number, radius: number): THREE.Vector3 {
  const phi = (90 - lat) * (Math.PI / 180)
  const theta = (lon + 180) * (Math.PI / 180)
  return new THREE.Vector3(
    -radius * Math.sin(phi) * Math.cos(theta),
    radius * Math.cos(phi),
    radius * Math.sin(phi) * Math.sin(theta)
  )
}

function createArcCurve(from: [number, number], to: [number, number], radius: number) {
  const start = latLonToVector3(from[0], from[1], radius)
  const end = latLonToVector3(to[0], to[1], radius)
  const mid = start.clone().add(end).multiplyScalar(0.5)
  const dist = start.distanceTo(end)
  mid.normalize().multiplyScalar(radius + dist * 0.35)
  return new THREE.QuadraticBezierCurve3(start, mid, end)
}

function ArcLine({ route }: { route: RouteData }) {
  const lineObj = useMemo(() => {
    const curve = createArcCurve(route.from, route.to, 1.005)
    const points = curve.getPoints(80)
    const geometry = new THREE.BufferGeometry().setFromPoints(points)
    const material = new THREE.LineBasicMaterial({
      color: route.color,
      transparent: true,
      opacity: 0.35,
    })
    return new THREE.Line(geometry, material)
  }, [route])

  return <primitive object={lineObj} />
}

function MovingCargo({ route, speed, offset }: { route: RouteData; speed: number; offset: number }) {
  const meshRef = useRef<THREE.Mesh>(null)
  const glowRef = useRef<THREE.Mesh>(null)
  const curve = useMemo(() => createArcCurve(route.from, route.to, 1.005), [route])

  useFrame(({ clock }) => {
    const t = (clock.getElapsedTime() * speed + offset) % 1
    const point = curve.getPoint(t)
    if (meshRef.current) {
      meshRef.current.position.copy(point)
    }
    if (glowRef.current) {
      glowRef.current.position.copy(point)
    }
  })

  return (
    <>
      <mesh ref={meshRef}>
        <sphereGeometry args={[0.015, 10, 10]} />
        <meshBasicMaterial color={route.color} />
      </mesh>
      <mesh ref={glowRef}>
        <sphereGeometry args={[0.028, 10, 10]} />
        <meshBasicMaterial color={route.color} transparent opacity={0.2} />
      </mesh>
    </>
  )
}

function PulsingDot({ position, color }: { position: THREE.Vector3; color: string }) {
  const meshRef = useRef<THREE.Mesh>(null)

  useFrame(({ clock }) => {
    if (meshRef.current) {
      const scale = 1 + Math.sin(clock.getElapsedTime() * 3) * 0.3
      meshRef.current.scale.setScalar(scale)
    }
  })

  return (
    <mesh ref={meshRef} position={position}>
      <sphereGeometry args={[0.018, 10, 10]} />
      <meshBasicMaterial color={color} />
    </mesh>
  )
}

export function CargoRoutes() {
  const cityPositions = useMemo(() => {
    const seen = new Set<string>()
    const positions: { pos: THREE.Vector3; color: string }[] = []
    ROUTES.forEach((route) => {
      const keyFrom = `${route.from[0]},${route.from[1]}`
      const keyTo = `${route.to[0]},${route.to[1]}`
      if (!seen.has(keyFrom)) {
        seen.add(keyFrom)
        positions.push({
          pos: latLonToVector3(route.from[0], route.from[1], 1.008),
          color: route.color,
        })
      }
      if (!seen.has(keyTo)) {
        seen.add(keyTo)
        positions.push({
          pos: latLonToVector3(route.to[0], route.to[1], 1.008),
          color: route.color,
        })
      }
    })
    return positions
  }, [])

  return (
    <group>
      {ROUTES.map((route, i) => (
        <group key={i}>
          <ArcLine route={route} />
          <MovingCargo route={route} speed={0.15 + i * 0.02} offset={i * 0.1} />
          <MovingCargo route={route} speed={0.12 + i * 0.015} offset={i * 0.1 + 0.5} />
        </group>
      ))}
      {cityPositions.map((city, i) => (
        <PulsingDot key={`city-${i}`} position={city.pos} color={city.color} />
      ))}
    </group>
  )
}
