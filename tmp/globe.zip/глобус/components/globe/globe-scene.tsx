"use client"

import { Canvas, useFrame } from "@react-three/fiber"
import { Suspense, useRef } from "react"
import { Earth } from "./earth"
import { CargoRoutes } from "./cargo-routes"
import { GlobeAtmosphere } from "./atmosphere"
import { TransportIcons } from "./transport-icons"
import * as THREE from "three"

function RotatingGroup({ children }: { children: React.ReactNode }) {
  const groupRef = useRef<THREE.Group>(null)
  const isDragging = useRef(false)
  const prevPointer = useRef({ x: 0, y: 0 })
  const velocity = useRef({ x: 0, y: 0 })
  const rotation = useRef({ x: 0.3, y: 0 })

  useFrame(() => {
    if (!isDragging.current) {
      rotation.current.y += 0.003
      velocity.current.x *= 0.95
      velocity.current.y *= 0.95
      rotation.current.x += velocity.current.x
      rotation.current.y += velocity.current.y
    }
    rotation.current.x = Math.max(-1.2, Math.min(1.2, rotation.current.x))
    if (groupRef.current) {
      groupRef.current.rotation.x = rotation.current.x
      groupRef.current.rotation.y = rotation.current.y
    }
  })

  return (
    <group
      ref={groupRef}
      onPointerDown={(e) => {
        isDragging.current = true
        prevPointer.current = { x: e.clientX, y: e.clientY }
        ;(e.target as HTMLElement)?.setPointerCapture?.(e.pointerId)
      }}
      onPointerMove={(e) => {
        if (!isDragging.current) return
        const dx = (e.clientX - prevPointer.current.x) * 0.005
        const dy = (e.clientY - prevPointer.current.y) * 0.005
        rotation.current.y += dx
        rotation.current.x += dy
        velocity.current.x = dy
        velocity.current.y = dx
        prevPointer.current = { x: e.clientX, y: e.clientY }
      }}
      onPointerUp={() => {
        isDragging.current = false
      }}
      onPointerLeave={() => {
        isDragging.current = false
      }}
    >
      {children}
    </group>
  )
}

export function GlobeScene() {
  return (
    <div className="w-full h-full cursor-grab active:cursor-grabbing">
      <Canvas
        camera={{ position: [0, 0, 2.8], fov: 45 }}
        gl={{ antialias: true, alpha: true }}
        style={{ background: "transparent" }}
      >
        <Suspense fallback={null}>
          <ambientLight intensity={0.4} />
          <directionalLight position={[5, 3, 5]} intensity={1.4} color="#ffffff" />
          <directionalLight position={[-5, -3, -5]} intensity={0.3} color="#4db8ff" />
          <pointLight position={[0, 0, 5]} intensity={0.5} color="#e8833a" />
          <RotatingGroup>
            <Earth />
            <GlobeAtmosphere />
            <CargoRoutes />
            <TransportIcons />
          </RotatingGroup>
        </Suspense>
      </Canvas>
    </div>
  )
}
