"use client"

import { useRef, useMemo } from "react"
import { useFrame } from "@react-three/fiber"
import * as THREE from "three"

function latLonToVector3(lat: number, lon: number, radius: number): THREE.Vector3 {
  const phi = (90 - lat) * (Math.PI / 180)
  const theta = (lon + 180) * (Math.PI / 180)
  return new THREE.Vector3(
    -radius * Math.sin(phi) * Math.cos(theta),
    radius * Math.cos(phi),
    radius * Math.sin(phi) * Math.sin(theta)
  )
}

// SVG path to Three.js shape helper
function createShapeFromSVGLike(points: [number, number][], scale: number = 1): THREE.Shape {
  const shape = new THREE.Shape()
  points.forEach(([x, y], i) => {
    const sx = x * scale
    const sy = y * scale
    if (i === 0) shape.moveTo(sx, sy)
    else shape.lineTo(sx, sy)
  })
  shape.closePath()
  return shape
}

// Airplane icon shape
function createAirplaneShape(size: number): THREE.Shape {
  const s = size
  const shape = new THREE.Shape()
  shape.moveTo(0, s * 0.5)
  shape.lineTo(s * 0.08, s * 0.35)
  shape.lineTo(s * 0.4, s * 0.15)
  shape.lineTo(s * 0.1, s * 0.05)
  shape.lineTo(s * 0.1, -s * 0.1)
  shape.lineTo(s * 0.2, -s * 0.25)
  shape.lineTo(s * 0.05, -s * 0.35)
  shape.lineTo(0, -s * 0.3)
  shape.lineTo(-s * 0.05, -s * 0.35)
  shape.lineTo(-s * 0.2, -s * 0.25)
  shape.lineTo(-s * 0.1, -s * 0.1)
  shape.lineTo(-s * 0.1, s * 0.05)
  shape.lineTo(-s * 0.4, s * 0.15)
  shape.lineTo(-s * 0.08, s * 0.35)
  shape.closePath()
  return shape
}

// Ship icon shape
function createShipShape(size: number): THREE.Shape {
  const s = size
  const shape = new THREE.Shape()
  shape.moveTo(-s * 0.3, -s * 0.15)
  shape.lineTo(-s * 0.2, -s * 0.35)
  shape.lineTo(s * 0.2, -s * 0.35)
  shape.lineTo(s * 0.3, -s * 0.15)
  shape.lineTo(s * 0.15, -s * 0.15)
  shape.lineTo(s * 0.15, s * 0.1)
  shape.lineTo(s * 0.25, s * 0.1)
  shape.lineTo(s * 0.05, s * 0.35)
  shape.lineTo(-s * 0.05, s * 0.35)
  shape.lineTo(-s * 0.15, s * 0.15)
  shape.lineTo(-s * 0.15, -s * 0.15)
  shape.closePath()
  return shape
}

// Truck icon shape
function createTruckShape(size: number): THREE.Shape {
  const s = size
  const shape = new THREE.Shape()
  shape.moveTo(-s * 0.35, -s * 0.2)
  shape.lineTo(-s * 0.35, s * 0.15)
  shape.lineTo(s * 0.1, s * 0.15)
  shape.lineTo(s * 0.1, s * 0.05)
  shape.lineTo(s * 0.35, s * 0.05)
  shape.lineTo(s * 0.35, -s * 0.2)
  shape.closePath()
  return shape
}

// Train icon shape
function createTrainShape(size: number): THREE.Shape {
  const s = size
  const shape = new THREE.Shape()
  shape.moveTo(-s * 0.15, -s * 0.35)
  shape.lineTo(-s * 0.15, s * 0.25)
  shape.lineTo(-s * 0.1, s * 0.35)
  shape.lineTo(s * 0.1, s * 0.35)
  shape.lineTo(s * 0.15, s * 0.25)
  shape.lineTo(s * 0.15, -s * 0.35)
  shape.closePath()
  return shape
}

interface TransportMarker {
  lat: number
  lon: number
  type: "air" | "sea" | "truck" | "train"
  color: string
  label: string
}

const MARKERS: TransportMarker[] = [
  { lat: 48.8, lon: 2.3, type: "air", color: "#e8833a", label: "Air" },
  { lat: -15, lon: -50, type: "sea", color: "#4db8ff", label: "Sea" },
  { lat: 35, lon: -100, type: "truck", color: "#22c55e", label: "Ground" },
  { lat: 55, lon: 80, type: "train", color: "#f59e0b", label: "Rail" },
]

function TransportMarkerMesh({ marker }: { marker: TransportMarker }) {
  const groupRef = useRef<THREE.Group>(null)
  const ringRef = useRef<THREE.Mesh>(null)
  const iconSize = 0.045

  const position = useMemo(
    () => latLonToVector3(marker.lat, marker.lon, 1.02),
    [marker.lat, marker.lon]
  )

  const normal = useMemo(() => position.clone().normalize(), [position])

  const shape = useMemo(() => {
    switch (marker.type) {
      case "air": return createAirplaneShape(iconSize)
      case "sea": return createShipShape(iconSize)
      case "truck": return createTruckShape(iconSize)
      case "train": return createTrainShape(iconSize)
    }
  }, [marker.type])

  useFrame(({ clock }) => {
    if (ringRef.current) {
      const s = 1 + Math.sin(clock.getElapsedTime() * 2.5) * 0.2
      ringRef.current.scale.setScalar(s)
    }
  })

  const quaternion = useMemo(() => {
    const q = new THREE.Quaternion()
    q.setFromUnitVectors(new THREE.Vector3(0, 0, 1), normal)
    return q
  }, [normal])

  return (
    <group ref={groupRef} position={position} quaternion={quaternion}>
      {/* Pulsing ring */}
      <mesh ref={ringRef}>
        <ringGeometry args={[0.055, 0.065, 32]} />
        <meshBasicMaterial color={marker.color} transparent opacity={0.5} side={THREE.DoubleSide} />
      </mesh>

      {/* Background circle */}
      <mesh position={[0, 0, 0.001]}>
        <circleGeometry args={[0.05, 32]} />
        <meshBasicMaterial color="#0f172a" transparent opacity={0.85} side={THREE.DoubleSide} />
      </mesh>

      {/* Icon shape */}
      <mesh position={[0, 0, 0.002]}>
        <shapeGeometry args={[shape]} />
        <meshBasicMaterial color={marker.color} side={THREE.DoubleSide} />
      </mesh>

      {/* Outer glow ring */}
      <mesh position={[0, 0, -0.001]}>
        <ringGeometry args={[0.06, 0.085, 32]} />
        <meshBasicMaterial color={marker.color} transparent opacity={0.15} side={THREE.DoubleSide} />
      </mesh>
    </group>
  )
}

export function TransportIcons() {
  return (
    <group>
      {MARKERS.map((marker, i) => (
        <TransportMarkerMesh key={i} marker={marker} />
      ))}
    </group>
  )
}
