"use client"

import { Globe, Shield, Clock, Zap } from "lucide-react"

const FEATURES = [
  {
    icon: Globe,
    title: "150+ Countries",
    description: "Our network spans across every major trade route and emerging market on the planet.",
  },
  {
    icon: Shield,
    title: "Insured Cargo",
    description: "Every shipment is fully insured with real-time risk assessment and mitigation.",
  },
  {
    icon: Clock,
    title: "Express Delivery",
    description: "Priority handling with guaranteed delivery windows for time-sensitive freight.",
  },
  {
    icon: Zap,
    title: "Smart Routing",
    description: "AI-powered route optimization that reduces transit times and costs automatically.",
  },
]

export function NetworkSection() {
  return (
    <section id="network" className="bg-card py-24">
      <div className="mx-auto max-w-7xl px-6">
        <div className="grid gap-16 lg:grid-cols-2 items-center">
          <div>
            <p className="text-sm font-semibold uppercase tracking-wider text-primary">
              Global Network
            </p>
            <h2 className="mt-3 text-3xl font-bold text-foreground sm:text-4xl font-mono text-balance">
              Built for Scale, Designed for Speed
            </h2>
            <p className="mt-4 text-muted-foreground leading-relaxed text-pretty">
              Our intelligent logistics platform connects thousands of carriers,
              ports, and warehouses into a single seamless network.
            </p>
            <div className="mt-10 grid gap-6 sm:grid-cols-2">
              {FEATURES.map((feature) => (
                <div key={feature.title} className="flex items-start gap-3">
                  <div className="mt-0.5 rounded-lg bg-primary/10 p-2">
                    <feature.icon className="h-4 w-4 text-primary" />
                  </div>
                  <div>
                    <h3 className="text-sm font-semibold text-foreground">
                      {feature.title}
                    </h3>
                    <p className="mt-1 text-xs leading-relaxed text-muted-foreground">
                      {feature.description}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="relative">
            <div className="rounded-2xl border border-border bg-secondary p-8 md:p-12">
              <div className="flex flex-col gap-6">
                <div className="flex items-center justify-between">
                  <span className="text-sm text-muted-foreground">Active Shipments</span>
                  <span className="text-2xl font-bold text-primary font-mono">12,847</span>
                </div>
                <div className="h-px bg-border" />
                <div className="flex flex-col gap-4">
                  {[
                    { route: "Shanghai — Rotterdam", status: "In Transit", progress: 72 },
                    { route: "Dubai — New York", status: "At Port", progress: 45 },
                    { route: "Mumbai — London", status: "In Transit", progress: 88 },
                    { route: "Tokyo — Sydney", status: "Customs", progress: 60 },
                  ].map((shipment) => (
                    <div key={shipment.route} className="flex flex-col gap-2">
                      <div className="flex items-center justify-between">
                        <span className="text-sm text-foreground">{shipment.route}</span>
                        <span className="text-xs text-muted-foreground">{shipment.status}</span>
                      </div>
                      <div className="h-1.5 rounded-full bg-muted overflow-hidden">
                        <div
                          className="h-full rounded-full bg-primary transition-all"
                          style={{ width: `${shipment.progress}%` }}
                        />
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
