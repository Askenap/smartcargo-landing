import { Ship, Plane, Truck, BarChart3 } from "lucide-react"

const STATS = [
  { value: "150+", label: "Countries Covered" },
  { value: "24/7", label: "Support Available" },
  { value: "10M+", label: "Shipments Annually" },
  { value: "99.2%", label: "On-Time Delivery" },
]

const SERVICES = [
  {
    icon: Ship,
    title: "Ocean Freight",
    description:
      "Full container load and less-than-container load services across major trade lanes worldwide.",
  },
  {
    icon: Plane,
    title: "Air Freight",
    description:
      "Express and standard air cargo solutions with priority handling and customs clearance.",
  },
  {
    icon: Truck,
    title: "Ground Transport",
    description:
      "Door-to-door land transportation with real-time GPS tracking and temperature control.",
  },
  {
    icon: BarChart3,
    title: "Supply Chain",
    description:
      "Integrated logistics management, warehousing, and inventory optimization services.",
  },
]

export function StatsSection() {
  return (
    <section className="border-y border-border bg-secondary">
      <div className="mx-auto max-w-7xl px-6 py-12">
        <div className="grid grid-cols-2 gap-8 md:grid-cols-4">
          {STATS.map((stat) => (
            <div key={stat.label} className="text-center">
              <p className="text-3xl font-bold text-primary font-mono lg:text-4xl">
                {stat.value}
              </p>
              <p className="mt-1 text-sm text-muted-foreground">{stat.label}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}

export function ServicesSection() {
  return (
    <section id="services" className="bg-background py-24">
      <div className="mx-auto max-w-7xl px-6">
        <div className="text-center">
          <p className="text-sm font-semibold uppercase tracking-wider text-primary">
            Our Services
          </p>
          <h2 className="mt-3 text-3xl font-bold text-foreground sm:text-4xl font-mono text-balance">
            Comprehensive Logistics Solutions
          </h2>
          <p className="mx-auto mt-4 max-w-2xl text-muted-foreground text-pretty">
            From port to port or door to door, we engineer the fastest and most
            reliable routes for your cargo.
          </p>
        </div>

        <div className="mt-16 grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
          {SERVICES.map((service) => (
            <div
              key={service.title}
              className="group rounded-xl border border-border bg-card p-6 transition-all hover:border-primary/40 hover:bg-secondary"
            >
              <div className="mb-4 inline-flex rounded-lg bg-primary/10 p-3">
                <service.icon className="h-6 w-6 text-primary" />
              </div>
              <h3 className="text-lg font-semibold text-card-foreground font-mono">
                {service.title}
              </h3>
              <p className="mt-2 text-sm leading-relaxed text-muted-foreground">
                {service.description}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
