"use client"

import dynamic from "next/dynamic"
import { ArrowRight, Plane, Ship, Truck, TrainFront } from "lucide-react"

const GlobeScene = dynamic(
  () =>
    import("@/components/globe/globe-scene").then((mod) => ({
      default: mod.GlobeScene,
    })),
  { ssr: false }
)

const TRANSPORT_MODES = [
  { icon: Plane, label: "Air Freight", color: "#e8833a" },
  { icon: Ship, label: "Sea Freight", color: "#4db8ff" },
  { icon: Truck, label: "Ground", color: "#22c55e" },
  { icon: TrainFront, label: "Railway", color: "#f59e0b" },
]

export function HeroSection() {
  return (
    <section className="relative min-h-screen bg-background overflow-hidden">
      {/* Subtle grid background */}
      <div
        className="absolute inset-0 opacity-[0.03]"
        style={{
          backgroundImage:
            "linear-gradient(rgba(255,255,255,.1) 1px, transparent 1px), linear-gradient(90deg, rgba(255,255,255,.1) 1px, transparent 1px)",
          backgroundSize: "60px 60px",
        }}
      />

      <div className="relative z-10 mx-auto max-w-7xl px-6 pt-28 pb-16 lg:pt-36">
        {/* Two-column layout: text left, globe right */}
        <div className="flex flex-col lg:flex-row items-center gap-8 lg:gap-4">
          {/* Left: Text content */}
          <div className="flex-1 max-w-xl lg:max-w-lg text-center lg:text-left">
            <div className="mb-6 inline-flex items-center gap-2 rounded-full border border-border bg-secondary px-4 py-1.5">
              <span className="h-2 w-2 rounded-full bg-primary animate-pulse" />
              <span className="text-xs font-medium text-muted-foreground">
                Real-time global tracking
              </span>
            </div>

            <h1 className="text-4xl font-bold leading-tight tracking-tight text-foreground sm:text-5xl lg:text-6xl text-balance font-mono">
              Delivering Across{" "}
              <span className="text-primary">Every Border</span>
            </h1>

            <p className="mt-6 text-base leading-relaxed text-muted-foreground sm:text-lg max-w-md mx-auto lg:mx-0 text-pretty">
              End-to-end global freight solutions powered by real-time
              intelligence. Air, sea, rail and ground — we move the world.
            </p>

            <div className="mt-10 flex flex-col gap-4 sm:flex-row sm:justify-center lg:justify-start">
              <a
                href="#services"
                className="inline-flex items-center justify-center gap-2 rounded-lg bg-primary px-6 py-3 text-sm font-semibold text-primary-foreground hover:opacity-90 transition-opacity"
              >
                Explore Services
                <ArrowRight className="h-4 w-4" />
              </a>
              <a
                href="#network"
                className="inline-flex items-center justify-center gap-2 rounded-lg border border-border bg-secondary px-6 py-3 text-sm font-semibold text-secondary-foreground hover:bg-muted transition-colors"
              >
                View Network
              </a>
            </div>

            {/* Transport mode legend */}
            <div className="mt-12 flex flex-wrap justify-center lg:justify-start gap-6">
              {TRANSPORT_MODES.map((mode) => (
                <div key={mode.label} className="flex items-center gap-2">
                  <div
                    className="flex h-8 w-8 items-center justify-center rounded-lg"
                    style={{ backgroundColor: `${mode.color}20` }}
                  >
                    <mode.icon
                      className="h-4 w-4"
                      style={{ color: mode.color }}
                    />
                  </div>
                  <span className="text-xs font-medium text-muted-foreground">
                    {mode.label}
                  </span>
                </div>
              ))}
            </div>
          </div>

          {/* Right: Globe — prominent and interactive */}
          <div className="flex-1 w-full max-w-[650px] aspect-square relative">
            {/* Glow behind globe */}
            <div className="absolute inset-0 rounded-full opacity-20 blur-3xl" style={{ background: "radial-gradient(circle, #4db8ff 0%, #e8833a 40%, transparent 70%)" }} />
            <GlobeScene />
            {/* Drag hint */}
            <div className="absolute bottom-4 left-1/2 -translate-x-1/2 text-xs text-muted-foreground opacity-60 select-none pointer-events-none">
              Drag to rotate
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
