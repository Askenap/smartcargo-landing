import { ArrowRight, MapPin, Phone, Mail } from "lucide-react"

export function CtaSection() {
  return (
    <section id="contact" className="bg-background py-24">
      <div className="mx-auto max-w-7xl px-6">
        <div className="overflow-hidden rounded-2xl border border-border bg-card">
          <div className="grid lg:grid-cols-2">
            <div className="p-8 md:p-12 lg:p-16">
              <p className="text-sm font-semibold uppercase tracking-wider text-primary">
                Get Started
              </p>
              <h2 className="mt-3 text-3xl font-bold text-foreground sm:text-4xl font-mono text-balance">
                Ready to Ship Worldwide?
              </h2>
              <p className="mt-4 text-muted-foreground leading-relaxed text-pretty">
                Get a custom quote in minutes. Our logistics experts will design
                the optimal route for your cargo.
              </p>
              <a
                href="#"
                className="mt-8 inline-flex items-center gap-2 rounded-lg bg-primary px-8 py-3.5 text-sm font-semibold text-primary-foreground hover:opacity-90 transition-opacity"
              >
                Request a Quote
                <ArrowRight className="h-4 w-4" />
              </a>
            </div>
            <div className="flex flex-col justify-center gap-6 border-t border-border p-8 md:p-12 lg:border-t-0 lg:border-l lg:p-16">
              <div className="flex items-start gap-4">
                <div className="rounded-lg bg-primary/10 p-2.5">
                  <MapPin className="h-5 w-5 text-primary" />
                </div>
                <div>
                  <p className="text-sm font-semibold text-foreground">
                    Headquarters
                  </p>
                  <p className="mt-1 text-sm text-muted-foreground">
                    Rotterdam, Netherlands
                  </p>
                </div>
              </div>
              <div className="flex items-start gap-4">
                <div className="rounded-lg bg-primary/10 p-2.5">
                  <Phone className="h-5 w-5 text-primary" />
                </div>
                <div>
                  <p className="text-sm font-semibold text-foreground">
                    Phone
                  </p>
                  <p className="mt-1 text-sm text-muted-foreground">
                    +31 10 123 4567
                  </p>
                </div>
              </div>
              <div className="flex items-start gap-4">
                <div className="rounded-lg bg-primary/10 p-2.5">
                  <Mail className="h-5 w-5 text-primary" />
                </div>
                <div>
                  <p className="text-sm font-semibold text-foreground">
                    Email
                  </p>
                  <p className="mt-1 text-sm text-muted-foreground">
                    info@globalfreight.com
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
