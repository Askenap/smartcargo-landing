import { Header } from "@/components/header"
import { HeroSection } from "@/components/hero-section"
import { StatsSection, ServicesSection } from "@/components/sections"
import { NetworkSection } from "@/components/network-section"
import { CtaSection } from "@/components/cta-section"
import { Footer } from "@/components/footer"

export default function Home() {
  return (
    <main>
      <Header />
      <HeroSection />
      <StatsSection />
      <ServicesSection />
      <NetworkSection />
      <CtaSection />
      <Footer />
    </main>
  )
}
